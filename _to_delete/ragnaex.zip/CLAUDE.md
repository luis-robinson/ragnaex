# RagnaEx — guia para o Claude Code

Protótipo de "MMO" 2.5D single-player com bots. **Godot 4.7.2 + GDScript**, sem addons.
Arte: Tree of Savior (chibi, pastel, toon 2 bandas + outline) · câmera Ragnarok (52°, yaw em 45°) ·
combate Drakantos (encara o cursor, LMB básico, skills com mira MOBA). Leia `README.md` e `docs/DESIGN.md`.

## Comandos

```powershell
# Windows (use o wrapper; ele acha o Godot em Program Files / Downloads / $env:GODOT)
.\tools\godot.ps1 --headless --path . --import                    # (re)gera cache de classes — rode após criar scripts com class_name
.\tools\godot.ps1 --headless --path . tools/tests/tests.tscn      # testes (559 checks) — OBRIGATÓRIO antes de terminar uma tarefa
.\tools\godot.ps1 --headless --path . -- --autostart=berserker    # smoke test: joga sozinho e sai; 0 "SCRIPT ERROR" é o critério
.\tools\godot.ps1 --path .                                        # abre o jogo com janela
```
Linux/mac: troque `.\tools\godot.ps1` por `godot` (binário 4.7.2 no PATH).

Scripts novos com `class_name` só são vistos pelos outros scripts depois de `--import`.

## Arquitetura (regra de ouro)

- `core/` = **simulação**. Nunca importe/instancie `Node3D`, `Control`, câmera, shaders ou `Input` aqui.
  Tudo que acontece no jogo passa por `core/sim/world_sim.gd` (autoload `Sim`) via `InputCommand`.
  Jogador e bots são a mesma coisa para a sim (só muda quem gera o comando). Isso é o futuro servidor.
- `game/` = **apresentação**. Lê o estado da sim, nunca muda HP/posição/inventário diretamente;
  chama métodos públicos de `Sim` (`equip`, `use_potion`, `upgrade_mastery`, `try_cast`…) ou os
  sistemas estáticos (`QuestSystem`, `CraftSystem`). Reage aos sinais de `core/events.gd` (autoload `Events`).
- `data/` = conteúdo. Schemas (Resources) em `data/schemas/`, dados em `data/catalog/*_catalog.gd`
  (dicionários → Resources em `GameData._ready`). Constantes de balanceamento SÓ em `data/balance.gd`.
- Autoloads (ordem): `Events`, `Balance`, `GameData`, `Sim`, `SaveSystem`.

## Como adicionar conteúdo

- **Skill**: `data/catalog/skills_catalog.gd` (6 por classe, ordem = slots 1-6, unlock 1/3/6/10/15/20).
  Campos em `data/schemas/skill_def.gd`; efeitos suportados por `WorldSim._apply_effects`
  (`dot, slow, stun, root, buff, shield, dash, summon, heal_pct_of_dmg`). Mira: SELF/DIRECTION/GROUND/CONE/TARGET.
- **Item/equipamento**: `items_catalog.gd` (atributos FOR/AGI/VIT/WILL/INT vêm SÓ de equipamento).
- **Monstro**: `monsters_catalog.gd` + loot table + spawner em `maps_catalog.gd` (+ modelo `mob_<id>` no Blender).
- **Quest**: `quests_catalog.gd` (KILL/COLLECT/TALK/CRAFT; NPC giver precisa existir em algum `MapDef.npcs`).
- **Mapa**: `maps_catalog.gd` — é 100% dados (obstáculos = colisão da sim + blockout visual).
- Sempre adicione um `check(...)` em `tools/tests/run_tests.gd` para conteúdo/regra nova.

## Estilo GDScript

- Tipagem estática; `var x := ...` só quando o tipo é inferível (valores vindos de `Array`/`Dictionary`
  untyped precisam de tipo explícito: `var d: float = e.position.distance_to(...)`).
- Lambdas de uma linha podem ter `a(); b()`, mas não `if`. Use métodos nomeados para sinais com lógica.
- `lerp`/`lerpf` em `_process`: sempre `minf(1.0, delta * k)` como peso.
- Texto do jogo em pt-BR; comentários curtos em pt-BR; nomes de código em inglês.
- Nada de `.tscn` grandes editados à mão: UI e mundo são construídos em código.

## Modelos (Blender)

`tools/blender/` gera personagens/monstros/props low-poly com rig e animações e exporta GLB para
`assets/models/`. O jogo usa placeholders até o `.glb` existir. Com o Blender MCP conectado
(`.mcp.json` → `uvx blender-mcp` + addon ligado no Blender), use `execute_blender_code`:
```python
import sys; sys.path.append(r"C:/Users/luisf/Desktop/projects/ragnaex/tools/blender")
import build_all; build_all.run(r"C:/Users/luisf/Desktop/projects/ragnaex/assets/models")
```
Nomes: `<class_id>.glb`, `npc_villager.glb`, `mob_<id>.glb`, `prop_<kind>.glb`. Animações: `idle run attack cast hit die block`.

## Definition of done

1. `--import` + testes passam (0 failed) + smoke sem `SCRIPT ERROR`.
2. Nenhum `Node`/`Input` dentro de `core/`.
3. Conteúdo novo tem check nos testes e está no README/`docs/DESIGN.md` se mudar regra.
