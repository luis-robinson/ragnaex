# RagnaEx

Protótipo de "MMO" 2.5D single-player com bots, feito em **Godot 4.7.2 + GDScript**.
Referências: Ragnarok Online (câmera alta, mundo 3D), Tree of Savior (arte pastel, chibi, toon) e
Drakantos (combate de ação: personagem encara o cursor, skillshots, mira estilo MOBA).

## Rodar

1. Instale o [Godot 4.7.2](https://godotengine.org/download) (versão padrão, sem .NET).
2. Abra o Godot → *Importar* → selecione `project.godot` desta pasta.
3. Pressione **F5**. Escolha uma classe, dê um nome e jogue.

Save automático a cada 60 s e ao fechar (`user://save.json`). "Continuar" aparece na tela inicial.

### Testes (sem janela)

```
godot --headless --path . tools/tests/tests.tscn          # 550+ checks de catálogo, fórmulas, quests, craft e 3000 ticks de simulação
godot --headless --path . -- --autostart=berserker        # smoke test: joga sozinho por alguns segundos e sai
```

## Controles

| Tecla | Ação |
|---|---|
| **W A S D** | mover (relativo à câmera) |
| **Botão esquerdo** | ataque básico (segurar = contínuo) |
| **Botão direito** (segurar) | bloquear (reduz dano; custa um pouco de MP) |
| **1 – 6** | skills (segure para ver a mira/alcance no chão) |
| **F1 F2 F3** | poções (configure na bolsa: Shift+clique no item) |
| **Shift** | dash (também cancela a recovery de uma skill) |
| **Espaço** | falar com NPC |
| **Q / E** | girar câmera em passos de 45° · scroll = zoom |
| **I / C / K / L** | bolsa · personagem · skills & maestria · quests |
| **Enter** | chat (os bots respondem) · **Esc** fecha janelas |

Mira é pelo mouse como num MOBA: skills `DIRECTION` vão para onde o cursor aponta, `GROUND` caem no
cursor (limitado ao alcance), `CONE` à frente, `TARGET` no inimigo sob o cursor, `SELF` em volta de você.

## Regras

* **Atributos vêm só do equipamento**: FOR (ATK físico, bloqueio), AGI (arco/adagas, crit), VIT (HP, DEF),
  WILL (cura, MP, DEF mágica), INT (dano/crit mágico). Fórmulas em `core/sim/stats.gd`; constantes em `data/balance.gd`.
* **8 classes** × 6 skills (desbloqueio nos níveis 1/3/6/10/15/20). **Maestria 0–5** por skill: gaste pontos
  (1 por nível, +1 nos níveis 10/20/30) ou use a skill 30× para subir de graça.
* **Nível máximo 30.** Morrer custa 3 % do XP e você renasce em Aldara.
* Cidade **Aldara** (NPCs: Ancião, Capitã, Ferreiro, Alquimista, Mercador, Quadro) + **Campina** (1–10),
  **Floresta** (10–20), **Ruínas** (20–30), cada uma com um mini-boss. 14 quests em cadeia, 48 receitas.
* **Bots** são jogadores falsos: caçam no campo do nível deles, voltam pra vender, conversam no chat, morrem e renascem.
  Eles usam exatamente o mesmo `InputCommand` que você — a simulação não sabe quem é humano.

## Arquitetura

```
core/            SIMULAÇÃO (sem nós 3D) — o futuro "servidor"
  sim/world_sim.gd   tick fixo 60 Hz, todos os mapas/entidades, combate, loot, portais, spawners
  sim/entity.gd      SimEntity (jogador, bot, monstro, NPC, invocação)
  sim/input_command.gd  pacote de input por tick (jogador e bots produzem isso)
  sim/combat.gd      dano/cura/bloqueio/crit + seleção de alvos (SELF/DIRECTION/GROUND/CONE/TARGET)
  sim/stats.gd       atributos → stats derivados
  sim/ai/            bot_brain.gd (FSM de "jogador"), monster_brain.gd
  systems/           quest_system.gd, craft_system.gd (também loja)
  events.gd          EventBus: a sim emite, a apresentação escuta
data/            dados do jogo (Resources construídos em data/catalog/*.gd; schemas em data/schemas/)
game/            APRESENTAÇÃO — só lê a sim e manda InputCommand
  main.gd            liga tudo, troca de mapa, fade de obstáculos
  player/            camera_rig.gd (pitch 52°, yaw em 45°), player_controller.gd
  entities/entity_view.gd  placeholder chibi procedural OU GLB de assets/models com animações
  world/map_builder.gd     blockout a partir do MapDef (ou props GLB quando existirem)
  fx/fx_manager.gd   dano flutuante, hit-stop, retículo de mira, projéteis, loot
  ui/                HUD, janelas, NPC/loja/craft, seleção de classe
shaders/         toon.gdshader (2 bandas), outline.gdshader (inverted hull), ground_reticle.gdshader
tools/blender/   scripts que geram os modelos low-poly e exportam GLB
tools/tests/     testes headless
```

Para virar online: `WorldSim` roda headless no servidor; clientes enviam `InputCommand` por RPC e recebem
o estado; a apresentação não muda.

## Modelos no Blender

Os modelos são gerados por script (chibi ToS-like, flat shading, rig simples e animações
`idle/run/attack/cast/hit/die/block`). O jogo roda com placeholders enquanto os GLB não existem;
assim que um `assets/models/<nome>.glb` aparecer, ele é usado automaticamente.

**Com Blender MCP** (addon [ahujasid/blender-mcp](https://github.com/ahujasid/blender-mcp) + `uvx blender-mcp`):
peça ao Claude para rodar, via `execute_blender_code`:

```python
import sys; sys.path.append(r"C:/Users/luisf/Desktop/projects/ragnaex/tools/blender")
import build_all; build_all.run(r"C:/Users/luisf/Desktop/projects/ragnaex/assets/models")
```

**Sem MCP (headless):**

```
blender -b --python tools/blender/build_all.py -- "C:/Users/luisf/Desktop/projects/ragnaex/assets/models"
```

Nomes esperados: `paladin.glb … necromancer.glb`, `npc_villager.glb`, `mob_slime.glb … mob_dragon.glb`,
`prop_house.glb … prop_fence.glb` (lista em `tools/blender/build_props.py`).

## Próximos passos sugeridos

* Modelos finais no Blender (os scripts são um ponto de partida; vale esculpir à mão por cima).
* Mapas em GLB (`MapDef.model`) com navmesh, em vez do blockout.
* Rede: `ENetMultiplayerPeer` + `WorldSim` headless (ver `core/sim`).
* Áudio e música.

## Trabalhando com o Claude Code

Abra um terminal na pasta e rode `claude`. O projeto já traz:

* `CLAUDE.md` — regras e comandos; `docs/DESIGN.md` — regras de jogo (fonte da verdade).
* `.mcp.json` — servidor `blender` (`uvx blender-mcp`; precisa do addon ligado no Blender e de `uv` instalado).
* Agentes (`.claude/agents/`): **blender-modeler** (modelos/animações via MCP), **class-designer** (classes, skills,
  atributos, bonecos, feel de combate), **world-builder** (monstros, mapas, cidades, quests, craft, bots),
  **qa-tester** (roda os testes) e **reviewer** (confere o trabalho e dá veredito).
* Skills: `/test`, `/build-models`, `/new-content <tipo> <descrição>`, `/review`.

Exemplo: `/new-content skill nova ultimate do Ranger que marca o chão e dispara uma rajada` → o `class-designer`
implementa com testes → `/review` confere.
