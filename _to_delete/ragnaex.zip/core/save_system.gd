extends Node
## SaveSystem (autoload): salva/carrega o jogador em user://save.json.

const PATH := "user://save.json"

func has_save() -> bool:
	return FileAccess.file_exists(PATH)

func save_player(p: SimEntity) -> void:
	if p == null:
		return
	var eq := {}
	for slot in p.equipment:
		if p.equipment[slot] != null:
			eq[str(int(slot))] = p.equipment[slot].id
	var data := {
		"name": p.name, "class": p.class_def.id, "level": p.level, "xp": p.xp, "gold": p.gold,
		"hp": p.hp, "mp": p.mp, "map": p.map_id, "pos": [p.position.x, p.position.z],
		"inventory": p.inventory, "equipment": eq, "mastery": p.mastery, "mastery_points": p.mastery_points,
		"skill_uses": p.skill_uses, "potion_slots": p.potion_slots,
		"quests_active": p.quests_active, "quests_completed": p.quests_completed,
	}
	var f := FileAccess.open(PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(data, "  "))
		f.close()
		Events.notification.emit("Jogo salvo")

func load_data() -> Dictionary:
	if not has_save():
		return {}
	var f := FileAccess.open(PATH, FileAccess.READ)
	if f == null:
		return {}
	var txt := f.get_as_text()
	f.close()
	var parsed = JSON.parse_string(txt)
	return parsed if parsed is Dictionary else {}

## Aplica o save numa entidade recém-criada (depois do spawn).
func apply_to(p: SimEntity, d: Dictionary) -> void:
	p.level = int(d.get("level", 1))
	p.xp = int(d.get("xp", 0))
	p.gold = int(d.get("gold", 0))
	p.inventory = {}
	for k in d.get("inventory", {}):
		p.inventory[k] = int(d["inventory"][k])
	p.equipment = {}
	for k in d.get("equipment", {}):
		var it: ItemDef = GameData.items.get(d["equipment"][k])
		if it:
			p.equipment[int(k)] = it
	p.mastery = {}
	for k in d.get("mastery", {}):
		p.mastery[k] = int(d["mastery"][k])
	p.mastery_points = int(d.get("mastery_points", 0))
	p.skill_uses = {}
	for k in d.get("skill_uses", {}):
		p.skill_uses[k] = int(d["skill_uses"][k])
	var ps: Array[String] = []
	for s in d.get("potion_slots", ["", "", ""]):
		ps.append(str(s))
	while ps.size() < 3:
		ps.append("")
	p.potion_slots = ps
	p.quests_active = {}
	for k in d.get("quests_active", {}):
		p.quests_active[k] = int(d["quests_active"][k])
	p.quests_completed.clear()
	for q in d.get("quests_completed", []):
		p.quests_completed.append(str(q))
	p.recompute_stats()
	p.hp = clampf(float(d.get("hp", p.stats.max_hp)), 1.0, p.stats.max_hp)
	p.mp = clampf(float(d.get("mp", p.stats.max_mp)), 0.0, p.stats.max_mp)

func delete_save() -> void:
	if has_save():
		DirAccess.remove_absolute(ProjectSettings.globalize_path(PATH))
