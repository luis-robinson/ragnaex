class_name BotBrain
extends RefCounted
## "Jogador falso". FSM utilitária: fica na cidade, conversa, vai caçar num campo do seu nível,
## usa skills/poções/bloqueio, volta pra cidade quando a bolsa enche ou o HP cai, vende, repete.
## Usa o MESMO InputCommand do jogador — a simulação não sabe que é bot.

enum S { TOWN_IDLE, TOWN_WALK, TRAVEL, HUNT, RETURN, SHOP }

var state: S = S.TOWN_IDLE
var timer: float = 0.0
var chat_timer: float = 0.0
var target_pos: Vector3 = Vector3.ZERO
var dest_map: String = ""
var rng: RandomNumberGenerator
var stuck_timer: float = 0.0
var last_pos: Vector3 = Vector3.ZERO
var detour: Vector2 = Vector2.ZERO
var detour_timer: float = 0.0
var hunt_target_id: int = -1
var block_timer: float = 0.0
var personality: float = 0.5   # 0 = cauteloso, 1 = agressivo

func setup(e: SimEntity, r: RandomNumberGenerator) -> void:
	rng = r
	personality = rng.randf()
	chat_timer = rng.randf_range(Balance.BOT_CHAT_MIN, Balance.BOT_CHAT_MAX)
	timer = rng.randf_range(2.0, 12.0)
	last_pos = e.position

func think(e: SimEntity, sim, m: Dictionary, dt: float) -> InputCommand:
	var cmd := InputCommand.new()
	timer -= dt
	chat_timer -= dt
	block_timer -= dt
	var def: MapDef = m["def"]
	cmd.aim = e.position + e.forward() * 2.0

	# --- chat ---
	if chat_timer <= 0.0:
		chat_timer = rng.randf_range(Balance.BOT_CHAT_MIN, Balance.BOT_CHAT_MAX)
		var ctx := "town" if def.is_town else "hunt"
		Events.chat_message.emit(e.name, GameData.random_bot_line(ctx), "global")

	# --- sobrevivência: poção ---
	if e.hp < e.stats.max_hp * 0.35 and e.potion_cd <= 0.0 and e.has_item("potion_hp_s"):
		cmd.potion_slot = 0
		return cmd
	if e.mp < e.stats.max_mp * 0.15 and e.potion_cd <= 0.0 and e.has_item("potion_mp_s"):
		cmd.potion_slot = 1
		return cmd

	# --- combate reativo: se um monstro me bate, luto mesmo fora do estado HUNT ---
	var threat := Combat.nearest_hostile(e, m["entities"], 9.0)
	if threat != null and not def.is_town and state != S.RETURN:
		return _fight(e, sim, m, threat, cmd)

	match state:
		S.TOWN_IDLE:
			if timer <= 0.0:
				if rng.randf() < 0.45 + personality * 0.3 and e.hp > e.stats.max_hp * 0.8:
					_plan_trip(e, sim)
				else:
					state = S.TOWN_WALK
					if def.bot_hangouts.size() > 0:
						target_pos = def.bot_hangouts[rng.randi() % def.bot_hangouts.size()] + Vector3(rng.randf_range(-1.5, 1.5), 0, rng.randf_range(-1.5, 1.5))
					else:
						target_pos = sim.random_walkable(def, Vector3.ZERO, 10.0)
					timer = 15.0
		S.TOWN_WALK:
			if e.position.distance_to(target_pos) < 0.8 or timer <= 0.0:
				state = S.TOWN_IDLE
				timer = rng.randf_range(4.0, 14.0)
			else:
				cmd.move = _steer(e, target_pos, dt) * 0.8
				cmd.aim = target_pos
		S.TRAVEL:
			# anda até o portal do mapa atual que leva a dest_map (ou à cidade)
			var portal := _find_portal(def, dest_map)
			if portal.is_empty():
				state = S.TOWN_IDLE if def.is_town else S.HUNT
				timer = 3.0
			else:
				cmd.move = _steer(e, portal["pos"], dt)
				cmd.aim = portal["pos"]
				if timer <= 0.0:
					state = S.TOWN_IDLE
		S.HUNT:
			if def.is_town:
				state = S.TOWN_IDLE
				timer = 2.0
			elif e.hp < e.stats.max_hp * 0.3 or e.inventory_weight() > 60 or timer <= 0.0:
				_go_home(e, sim, def)
			else:
				var mob := _pick_monster(e, m)
				if mob:
					return _fight(e, sim, m, mob, cmd)
				# procurar: anda até um spawner aleatório
				if target_pos == Vector3.ZERO or e.position.distance_to(target_pos) < 2.0:
					if def.spawners.size() > 0:
						var sp = def.spawners[rng.randi() % def.spawners.size()]
						target_pos = sim.random_walkable(def, sp["pos"], float(sp.get("radius", 6.0)))
					else:
						target_pos = sim.random_walkable(def, Vector3.ZERO, 20.0)
				cmd.move = _steer(e, target_pos, dt)
				cmd.aim = target_pos
		S.RETURN:
			if def.is_town:
				state = S.SHOP
				timer = rng.randf_range(4.0, 9.0)
				var npc := _find_npc(def, "merchant")
				target_pos = npc.get("pos", Vector3.ZERO) + Vector3(0, 0, 1.6)
			else:
				var portal := _find_portal(def, GameData.town_map_id())
				if not portal.is_empty():
					cmd.move = _steer(e, portal["pos"], dt)
					cmd.aim = portal["pos"]
		S.SHOP:
			if e.position.distance_to(target_pos) > 1.0 and timer > 2.0:
				cmd.move = _steer(e, target_pos, dt) * 0.8
				cmd.aim = target_pos
			elif timer <= 0.0:
				_sell_materials(e)
				_restock(e)
				e.hp = e.stats.max_hp
				e.mp = e.stats.max_mp
				state = S.TOWN_IDLE
				timer = rng.randf_range(5.0, 20.0)
	return cmd

# ---------------------------------------------------------------------------
func _fight(e: SimEntity, sim, m: Dictionary, mob: SimEntity, cmd: InputCommand) -> InputCommand:
	hunt_target_id = mob.id
	cmd.aim = mob.position
	var dist := e.position.distance_to(mob.position) - mob.radius - e.radius
	var cls := e.class_def
	# cura própria (bispo/druida/paladino com skill de cura)
	if e.hp < e.stats.max_hp * 0.5:
		for i in range(e.skills.size()):
			var s := e.skills[i]
			if s.kind == SkillDef.Kind.HEAL and e.level >= s.unlock_level and e.cooldowns.get(s.id, 0.0) <= 0.0 and e.mp >= s.mp_cost_at(e.mastery_of(s.id)):
				cmd.skill_slot = i
				cmd.aim = e.position
				return cmd
	# bloqueio reativo: monstro em startup de ataque e eu sou tank/melee
	if mob.state == SimEntity.State.CASTING and dist < 2.5 and cls.can_use_shield and block_timer <= 0.0 and rng.randf() < 0.6:
		block_timer = 1.2
	if block_timer > 0.0:
		cmd.block = true
	# skill ofensiva disponível e alvo no alcance
	if e.can_act():
		var order := range(e.skills.size())
		order.shuffle()
		for i in order:
			var s := e.skills[i]
			if e.level < s.unlock_level or s.kind == SkillDef.Kind.HEAL:
				continue
			if e.cooldowns.get(s.id, 0.0) > 0.0 or e.mp < s.mp_cost_at(e.mastery_of(s.id)):
				continue
			var reach := s.range if s.target != SkillDef.Target.SELF else 3.0
			if s.target == SkillDef.Target.CONE:
				reach = s.radius
			if dist <= reach + 0.3 and rng.randf() < 0.7:
				cmd.skill_slot = i
				return cmd
		# ataque básico
		var basic_reach := e.basic_skill.range if e.basic_skill else 1.8
		if dist <= basic_reach * 0.9:
			if e.basic_cd <= 0.0:
				cmd.attack = true
			# kiting para ranged
			if cls.basic_attack_is_ranged and dist < basic_reach * 0.4:
				cmd.move = -_steer(e, mob.position, 0.0)
			return cmd
	cmd.move = _steer(e, mob.position, 0.0)
	return cmd

func _pick_monster(e: SimEntity, m: Dictionary) -> SimEntity:
	var best: SimEntity = null
	var best_score := INF
	for o in m["entities"]:
		if o.kind != SimEntity.Kind.MONSTER or not o.is_alive():
			continue
		if o.monster_def.is_boss and e.level < o.level + 2 and personality < 0.7:
			continue
		var d: float = o.position.distance_to(e.position)
		if d > 18.0:
			continue
		var score: float = d + absf(o.level - e.level) * 1.5
		if o.aggro_target >= 0 and o.aggro_target != e.id:
			score += 6.0   # evita roubar monstro de outro
		if score < best_score:
			best_score = score
			best = o
	return best

func _plan_trip(e: SimEntity, sim) -> void:
	var fields: Array = []
	for mid in GameData.maps:
		var md: MapDef = GameData.maps[mid]
		if md.is_town:
			continue
		if e.level >= md.level_range.x - 1 and e.level <= md.level_range.y + 3:
			fields.append(mid)
	if fields.is_empty():
		for mid in GameData.maps:
			if not GameData.maps[mid].is_town:
				fields.append(mid)
	dest_map = fields[rng.randi() % fields.size()]
	state = S.TRAVEL
	timer = 60.0
	if rng.randf() < 0.3:
		Events.chat_message.emit(e.name, GameData.random_bot_line("leaving") % GameData.maps[dest_map].name, "global")

func _go_home(e: SimEntity, sim, def: MapDef) -> void:
	state = S.RETURN
	dest_map = GameData.town_map_id()
	timer = 90.0

func _find_portal(def: MapDef, target_map: String) -> Dictionary:
	for p in def.portals:
		if p["target_map"] == target_map:
			return p
	# fallback: qualquer portal
	return def.portals[0] if def.portals.size() > 0 else {}

func _find_npc(def: MapDef, role: String) -> Dictionary:
	for n in def.npcs:
		if n.get("role", "") == role:
			return n
	return {}

func _sell_materials(e: SimEntity) -> void:
	for item_id in e.inventory.keys():
		var it: ItemDef = GameData.items.get(item_id)
		if it and it.type == ItemDef.Type.MATERIAL:
			var n := int(e.inventory[item_id])
			e.remove_item(item_id, n)
			e.gold += it.price * n

func _restock(e: SimEntity) -> void:
	while int(e.inventory.get("potion_hp_s", 0)) < 5 and e.gold >= 15:
		e.gold -= 15
		e.add_item("potion_hp_s", 1)
	while int(e.inventory.get("potion_mp_s", 0)) < 3 and e.gold >= 18:
		e.gold -= 18
		e.add_item("potion_mp_s", 1)

## Direção até `p` com desvio simples quando preso.
func _steer(e: SimEntity, p: Vector3, dt: float) -> Vector2:
	var d := p - e.position
	var v := Vector2(d.x, d.z)
	if v.length() < 0.05:
		return Vector2.ZERO
	v = v.normalized()
	if dt > 0.0:
		if e.position.distance_to(last_pos) < 0.02 * (dt * 60.0):
			stuck_timer += dt
		else:
			stuck_timer = 0.0
		last_pos = e.position
		if stuck_timer > 0.5 and detour_timer <= 0.0:
			detour = v.rotated(PI * 0.5 * (1.0 if rng.randf() < 0.5 else -1.0))
			detour_timer = rng.randf_range(0.6, 1.4)
			stuck_timer = 0.0
		detour_timer -= dt
	if detour_timer > 0.0:
		return (v * 0.3 + detour).normalized()
	return v
