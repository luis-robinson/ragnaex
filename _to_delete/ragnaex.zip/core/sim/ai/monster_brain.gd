class_name MonsterBrain
extends RefCounted
## IA de monstro (e de invocações): idle → wander → chase → attack → leash.
## Produz InputCommand igual a um jogador.

enum S { IDLE, WANDER, CHASE, RETURN }

var state: S = S.IDLE
var timer: float = 0.0
var wander_target: Vector3 = Vector3.ZERO
var skill_timer: float = 0.0

func think(e: SimEntity, sim, m: Dictionary, dt: float) -> InputCommand:
	var cmd := InputCommand.new()
	timer -= dt
	skill_timer -= dt
	var def: MapDef = m["def"]
	var mdef := e.monster_def
	var is_summon := e.kind == SimEntity.Kind.SUMMON
	var owner: SimEntity = sim.entities.get(e.owner_id) if is_summon else null

	# --- escolher alvo ---
	var target: SimEntity = null
	if e.aggro_target >= 0:
		target = sim.entities.get(e.aggro_target)
		if target and (not target.is_alive() or target.map_id != e.map_id):
			target = null
			e.aggro_target = -1
	if target == null:
		var aggro := mdef.aggro_range if not is_summon else 9.0
		target = Combat.nearest_hostile(e, m["entities"], aggro)
		if target:
			e.aggro_target = target.id
			e.aggro_timer = Balance.AGGRO_LOSE_TIME
	# invocação volta pro dono se ele se afastar
	if is_summon and owner and target == null:
		var d := owner.position.distance_to(e.position)
		if d > 3.0:
			cmd.move = _dir_to(e, owner.position + Vector3(0.8, 0, 0.8))
			cmd.aim = owner.position
			return cmd
		cmd.aim = e.position + e.forward()
		return cmd

	# --- leash: longe demais de casa ---
	if not is_summon and e.position.distance_to(e.home_position) > mdef.leash_range:
		state = S.RETURN
		e.aggro_target = -1
		target = null

	if target != null:
		state = S.CHASE
		var dist := e.position.distance_to(target.position) - target.radius - e.radius
		cmd.aim = target.position
		# skill especial?
		if e.skills.size() > 0 and skill_timer <= 0.0 and dist <= e.skills[0].range + 0.5 and e.can_act():
			cmd.skill_slot = 0
			skill_timer = e.skills[0].cooldown + 1.0
			return cmd
		var reach := mdef.attack_range if not is_summon else 1.5
		if dist <= reach * 0.85:
			if e.basic_cd <= 0.0 and e.can_act():
				cmd.attack = true
			# ranged fica parado; melee empurra um pouquinho se longe
		else:
			cmd.move = _dir_to(e, target.position)
			if mdef.ranged and dist < reach * 0.5:
				cmd.move = -cmd.move
		return cmd

	match state:
		S.RETURN:
			if e.position.distance_to(e.home_position) < 1.0:
				state = S.IDLE
				timer = 1.0
				e.hp = minf(e.stats.max_hp, e.hp + e.stats.max_hp * 0.5)
			else:
				cmd.move = _dir_to(e, e.home_position)
				cmd.aim = e.home_position
		S.IDLE:
			if timer <= 0.0:
				state = S.WANDER
				wander_target = sim.random_walkable(def, e.home_position, 5.0)
				timer = 6.0
			cmd.aim = e.position + e.forward()
		S.WANDER:
			if timer <= 0.0 or e.position.distance_to(wander_target) < 0.6:
				state = S.IDLE
				timer = sim.rng.randf_range(1.5, 4.0)
			else:
				cmd.move = _dir_to(e, wander_target) * 0.5
				cmd.aim = wander_target
		_:
			state = S.IDLE
	return cmd

static func _dir_to(e: SimEntity, p: Vector3) -> Vector2:
	var d := p - e.position
	var v := Vector2(d.x, d.z)
	return v.normalized() if v.length() > 0.05 else Vector2.ZERO
