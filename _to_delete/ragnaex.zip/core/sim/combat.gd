class_name Combat
extends RefCounted
## Fórmulas de dano/cura/bloqueio e seleção de alvos. Funções puras sobre SimEntity.

## Calcula o dano de `attacker` em `target`.
## kind: SkillDef.Kind.PHYSICAL ou MAGICAL
static func calc_damage(attacker: SimEntity, target: SimEntity, power: float, kind: int, rng: RandomNumberGenerator) -> Dictionary:
	var magical := kind == SkillDef.Kind.MAGICAL
	var atk := attacker.stats.matk if magical else attacker.stats.patk
	var def := target.stats.mdef if magical else target.stats.pdef
	var crit_chance := attacker.stats.crit_mag if magical else attacker.stats.crit_phys
	var raw := atk * power - def * Balance.DEF_FACTOR
	raw = maxf(raw, atk * power * 0.15)   # piso: 15% do dano bruto
	var variance := 1.0 + rng.randf_range(-Balance.DMG_VARIANCE, Balance.DMG_VARIANCE)
	var crit := rng.randf() * 100.0 < crit_chance
	var amount := raw * variance * (Balance.CRIT_MULT if crit else 1.0)

	# bloqueio: passivo (escudo) ou ativo (segurando RMB)
	var blocked := false
	if target.is_character() or target.kind == SimEntity.Kind.SUMMON:
		var reduction := 0.0
		if target.is_blocking and target.state != SimEntity.State.STUNNED:
			# bloqueio ativo: sempre bloqueia, redução = redução base + bônus de guarda
			blocked = true
			reduction = target.stats.block_reduction + Balance.GUARD_HOLD_REDUCTION_BONUS
			if target.stats.has_shield:
				reduction += 10.0
		elif target.stats.block_chance > 0.0 and rng.randf() * 100.0 < target.stats.block_chance:
			blocked = true
			reduction = target.stats.block_reduction
		if blocked:
			reduction = minf(reduction, 85.0)
			amount *= 1.0 - reduction / 100.0
			crit = false
	return {"amount": maxi(1, int(round(amount))), "crit": crit, "blocked": blocked}


static func calc_heal(healer: SimEntity, power: float, rng: RandomNumberGenerator) -> int:
	var base := healer.stats.matk * power * healer.stats.heal_power
	var crit := rng.randf() * 100.0 < healer.stats.crit_mag
	return int(round(base * (1.0 + rng.randf_range(-0.08, 0.08)) * (Balance.CRIT_MULT if crit else 1.0)))


## Seleciona alvos de uma skill no mapa do caster. `entities` = todas as entidades do mapa.
static func select_targets(caster: SimEntity, skill: SkillDef, aim: Vector3, entities: Array) -> Array:
	var out: Array = []
	var friendly := skill.kind == SkillDef.Kind.HEAL or skill.kind == SkillDef.Kind.BUFF
	match skill.target:
		SkillDef.Target.SELF:
			out.append(caster)
			# cura/buff em área ao redor do caster atinge aliados próximos
			if friendly and skill.radius > 0.0:
				for e in entities:
					if e != caster and e.is_alive() and not caster.is_hostile_to(e) and e.kind != SimEntity.Kind.NPC:
						if e.position.distance_to(caster.position) <= skill.radius:
							out.append(e)
		SkillDef.Target.DIRECTION:
			var dir := caster.forward()
			for e in entities:
				if not _valid(caster, e, friendly):
					continue
				var rel: Vector3 = e.position - caster.position
				rel.y = 0.0
				var along: float = rel.dot(dir)
				if along < -e.radius or along > skill.range + e.radius:
					continue
				var side := absf(rel.cross(dir).y)
				if side <= skill.radius + e.radius:
					out.append(e)
			out.sort_custom(func(a, b): return a.position.distance_squared_to(caster.position) < b.position.distance_squared_to(caster.position))
		SkillDef.Target.GROUND:
			var center := clamp_aim(caster, aim, skill.range)
			for e in entities:
				if not _valid(caster, e, friendly):
					continue
				if Vector2(e.position.x, e.position.z).distance_to(Vector2(center.x, center.z)) <= skill.radius + e.radius:
					out.append(e)
		SkillDef.Target.CONE:
			var dir := caster.forward()
			var half_angle := deg_to_rad(skill.cone_angle_deg * 0.5)
			for e in entities:
				if not _valid(caster, e, friendly):
					continue
				var rel: Vector3 = e.position - caster.position
				rel.y = 0.0
				var dist: float = rel.length()
				if dist > skill.radius + e.radius:
					continue
				if dist < 0.01 or absf(dir.angle_to(rel.normalized())) <= half_angle + (e.radius / maxf(dist, 0.5)):
					out.append(e)
		SkillDef.Target.TARGET:
			var best: SimEntity = null
			var best_d := 1.6
			for e in entities:
				if not _valid(caster, e, friendly):
					continue
				if e.position.distance_to(caster.position) > skill.range + e.radius:
					continue
				var d: float = Vector2(e.position.x, e.position.z).distance_to(Vector2(aim.x, aim.z)) - e.radius
				if d < best_d:
					best_d = d
					best = e
			if best:
				out.append(best)
				if skill.radius > 0.0:
					for e in entities:
						if e != best and _valid(caster, e, friendly) and e.position.distance_to(best.position) <= skill.radius + e.radius:
							out.append(e)
	if out.size() > skill.max_targets:
		out.resize(skill.max_targets)
	return out


static func _valid(caster: SimEntity, e: SimEntity, friendly: bool) -> bool:
	if e == null or not e.is_alive() or e.kind == SimEntity.Kind.NPC:
		return false
	if friendly:
		return e == caster or (not caster.is_hostile_to(e))
	return caster.is_hostile_to(e)


static func clamp_aim(caster: SimEntity, aim: Vector3, range: float) -> Vector3:
	var rel := aim - caster.position
	rel.y = 0.0
	if rel.length() > range:
		rel = rel.normalized() * range
	return caster.position + rel


## Entidades hostis no raio (para ataque básico / IA)
static func nearest_hostile(from: SimEntity, entities: Array, max_dist: float) -> SimEntity:
	var best: SimEntity = null
	var best_d := max_dist
	for e in entities:
		if e == from or not e.is_alive() or not from.is_hostile_to(e):
			continue
		var d: float = e.position.distance_to(from.position) - e.radius
		if d < best_d:
			best_d = d
			best = e
	return best
