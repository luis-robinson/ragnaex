class_name SimEntity
extends RefCounted
## Entidade da simulação: jogador, bot, monstro, NPC ou invocação. Sem nós.

enum Kind { PLAYER, BOT, MONSTER, NPC, SUMMON }
enum State { IDLE, MOVING, ATTACKING, CASTING, BLOCKING, DASHING, STUNNED, DEAD }

var id: int = 0
var name: String = ""
var kind: Kind = Kind.PLAYER
var map_id: String = ""
var position: Vector3 = Vector3.ZERO
var facing: float = 0.0            # yaw em radianos (0 = +Z)
var velocity: Vector3 = Vector3.ZERO
var radius: float = 0.45
var scale: float = 1.0

# identidade
var class_def: ClassDef = null
var monster_def: MonsterDef = null
var level: int = 1
var xp: int = 0
var gold: int = 0
var owner_id: int = -1              # para invocações
var summon_expires: float = 0.0

# stats
var stats: Stats = Stats.new()
var hp: float = 100.0
var mp: float = 50.0
var shield_hp: float = 0.0           # escudo temporário
var buffs: Array = []                # [{id, duration, remaining, atk_pct, ...}]
var debuffs: Array = []              # [{id, remaining, kind:"dot|slow|stun|root", ...}]

# combate
var state: State = State.IDLE
var state_time: float = 0.0          # tempo dentro do estado atual
var state_duration: float = 0.0
var current_skill: SkillDef = null
var current_skill_slot: int = -1
var skill_phase: String = ""         # startup | active | recovery
var skill_applied: bool = false
var skill_aim: Vector3 = Vector3.ZERO
var basic_cd: float = 0.0
var basic_skill: SkillDef = null     # ataque básico (gerado por classe/monstro)
var combat_timer: float = 0.0        # >0 = "em combate" (sem regen)
var cooldowns: Dictionary = {}       # skill_id -> segundos restantes
var potion_cd: float = 0.0
var dash_cd: float = 0.0
var dash_dir: Vector3 = Vector3.ZERO
var is_blocking: bool = false
var buffered_cmd: InputCommand = null
var buffered_ticks: int = 0
var last_cmd: InputCommand = InputCommand.new()
var aggro_target: int = -1
var aggro_timer: float = 0.0
var last_damage_from: int = -1
var threat: Dictionary = {}          # attacker_id -> dano acumulado
var dead_time: float = 0.0
var home_position: Vector3 = Vector3.ZERO
var corpse_timer: float = 0.0
var hit_flash: float = 0.0

# progressão / itens (jogadores e bots)
var skills: Array[SkillDef] = []
var mastery: Dictionary = {}         # skill_id -> level 0..5
var skill_uses: Dictionary = {}      # skill_id -> usos desde última maestria grátis
var mastery_points: int = 0
var inventory: Dictionary = {}       # item_id -> count
var equipment: Dictionary = {}       # ItemDef.Slot -> ItemDef
var potion_slots: Array[String] = ["", "", ""]
var quests_active: Dictionary = {}   # quest_id -> progress
var quests_completed: Array[String] = []
var brain = null                     # BotBrain / MonsterBrain (produz InputCommand)
var brain_cmd: InputCommand = null   # último comando do cérebro (reutilizado entre pensamentos)
var npc_data: Dictionary = {}

func is_alive() -> bool:
	return state != State.DEAD

func is_character() -> bool:
	return kind == Kind.PLAYER or kind == Kind.BOT

func is_hostile_to(other: SimEntity) -> bool:
	if other == null or other == self:
		return false
	var a_mob := kind == Kind.MONSTER
	var b_mob := other.kind == Kind.MONSTER
	if other.kind == Kind.NPC or kind == Kind.NPC:
		return false
	if kind == Kind.SUMMON:
		return b_mob
	if other.kind == Kind.SUMMON:
		return a_mob
	return a_mob != b_mob

func can_act() -> bool:
	return state in [State.IDLE, State.MOVING, State.BLOCKING]

func forward() -> Vector3:
	return Vector3(sin(facing), 0.0, cos(facing))

func face_towards(point: Vector3) -> void:
	var d := point - position
	d.y = 0.0
	if d.length_squared() > 0.0001:
		facing = atan2(d.x, d.z)

func recompute_stats() -> void:
	if monster_def:
		stats = Stats.from_monster(monster_def)
		if kind == Kind.SUMMON:
			stats.max_hp *= 1.0 + 0.1 * level
	else:
		stats = Stats.compute(class_def, level, equipment, buffs)
	hp = minf(hp, stats.max_hp)
	mp = minf(mp, stats.max_mp)

func heal_full() -> void:
	hp = stats.max_hp
	mp = stats.max_mp

func set_state(s: State, duration: float = 0.0) -> void:
	state = s
	state_time = 0.0
	state_duration = duration

func has_debuff(kind: String) -> bool:
	for d in debuffs:
		if d.get("kind") == kind:
			return true
	return false

func slow_factor() -> float:
	var f := 1.0
	for d in debuffs:
		if d.get("kind") == "slow":
			f *= 1.0 - float(d.get("pct", 0)) / 100.0
	return maxf(f, 0.1)

func mastery_of(skill_id: String) -> int:
	return int(mastery.get(skill_id, 0))

func add_item(item_id: String, count: int = 1) -> void:
	inventory[item_id] = int(inventory.get(item_id, 0)) + count
	Events.item_gained.emit(id, item_id, count)

func remove_item(item_id: String, count: int = 1) -> bool:
	var have := int(inventory.get(item_id, 0))
	if have < count:
		return false
	if have == count:
		inventory.erase(item_id)
	else:
		inventory[item_id] = have - count
	Events.item_removed.emit(id, item_id, count)
	return true

func has_item(item_id: String, count: int = 1) -> bool:
	return int(inventory.get(item_id, 0)) >= count

func inventory_weight() -> int:
	var n := 0
	for k in inventory:
		n += int(inventory[k])
	return n

func unlocked_skill_count() -> int:
	var n := 0
	for s in skills:
		if level >= s.unlock_level:
			n += 1
	return n

func display_title() -> String:
	if class_def:
		return "%s Lv.%d" % [class_def.name, level]
	if monster_def:
		return "Lv.%d" % level
	return ""
