class_name Stats
extends RefCounted
## Stats derivados de atributos (FOR/AGI/VIT/WILL/INT) + equipamento + classe + nível.
## Pura função: `compute()` gera um Stats novo. Nunca toca nós.

var max_hp: float = 100.0
var max_mp: float = 50.0
var patk: float = 10.0
var matk: float = 10.0
var pdef: float = 0.0
var mdef: float = 0.0
var crit_phys: float = 5.0     # %
var crit_mag: float = 5.0      # %
var heal_power: float = 1.0
var block_chance: float = 0.0  # % (passivo, só com escudo)
var block_reduction: float = 0.0 # %
var move_speed: float = 5.5
var attrs := {"FOR": 0, "AGI": 0, "VIT": 0, "WILL": 0, "INT": 0}
var has_shield: bool = false
var weapon_type: String = ""
var is_ranged_weapon: bool = false
var is_magic_weapon: bool = false


static func compute(cls: ClassDef, level: int, equipment: Dictionary, buffs: Array) -> Stats:
	var s := Stats.new()
	# 1) atributos vêm SÓ de equipamento (+ buffs)
	for slot in equipment:
		var item: ItemDef = equipment[slot]
		if item == null:
			continue
		for a in Balance.ATTRS:
			s.attrs[a] += item.attr(a)
		if item.slot == ItemDef.Slot.WEAPON:
			s.weapon_type = item.weapon_type
		if item.weapon_type == "shield":
			s.has_shield = true
	for b in buffs:
		for a in Balance.ATTRS:
			s.attrs[a] += int(b.get("attr_" + a, 0))
	s.is_ranged_weapon = s.weapon_type == "bow"
	s.is_magic_weapon = s.weapon_type in ["staff", "wand", "scythe"]

	var FOR := float(s.attrs["FOR"]); var AGI := float(s.attrs["AGI"]); var VIT := float(s.attrs["VIT"])
	var WILL := float(s.attrs["WILL"]); var INT := float(s.attrs["INT"])

	# 2) equipamento: atk/def planos
	var eq_atk := 0.0; var eq_matk := 0.0; var eq_def := 0.0; var eq_mdef := 0.0
	for slot in equipment:
		var item: ItemDef = equipment[slot]
		if item == null:
			continue
		eq_atk += item.atk; eq_matk += item.matk; eq_def += item.def; eq_mdef += item.mdef

	# 3) base por classe e nível
	var base_hp := cls.base_hp + cls.hp_per_level * (level - 1) if cls else 100.0 + 10.0 * (level - 1)
	var base_mp := cls.base_mp + cls.mp_per_level * (level - 1) if cls else 50.0 + 5.0 * (level - 1)
	s.move_speed = cls.move_speed if cls else 5.0

	s.max_hp = base_hp + VIT * Balance.HP_PER_VIT
	s.max_mp = base_mp + WILL * Balance.MP_PER_WILL
	# ataque físico: arco usa AGI; adaga mistura; resto FOR
	if s.is_ranged_weapon:
		s.patk = eq_atk + AGI * Balance.PATK_PER_AGI_RANGED + FOR * 0.3
	elif s.weapon_type == "dagger":
		s.patk = eq_atk + FOR * Balance.PATK_PER_FOR * 0.6 + AGI * Balance.PATK_PER_AGI_DAGGER
	else:
		s.patk = eq_atk + FOR * Balance.PATK_PER_FOR + AGI * Balance.PATK_PER_AGI_OTHER
	s.patk += 4.0 + level * 0.8
	s.matk = eq_matk + INT * Balance.MATK_PER_INT + 4.0 + level * 0.8
	s.pdef = eq_def + VIT * Balance.PDEF_PER_VIT
	s.mdef = eq_mdef + WILL * Balance.MDEF_PER_WILL
	s.crit_phys = Balance.CRIT_BASE + AGI * Balance.CRIT_PER_AGI
	s.crit_mag = Balance.CRIT_BASE + INT * Balance.MCRIT_PER_INT
	s.heal_power = 1.0 + WILL * Balance.HEAL_PER_WILL
	if s.has_shield:
		s.block_chance = Balance.BLOCK_BASE_SHIELD + FOR * Balance.BLOCK_PER_FOR_SHIELD
	if s.is_magic_weapon:
		s.block_reduction = Balance.BLOCK_REDUCTION_MAGIC_WEAPON
	else:
		s.block_reduction = minf(Balance.BLOCK_REDUCTION_BASE + FOR * Balance.BLOCK_REDUCTION_PER_FOR, Balance.BLOCK_REDUCTION_CAP)

	# 4) buffs percentuais
	for b in buffs:
		s.patk *= 1.0 + float(b.get("atk_pct", 0)) / 100.0
		s.matk *= 1.0 + float(b.get("matk_pct", 0)) / 100.0
		s.pdef *= 1.0 + float(b.get("def_pct", 0)) / 100.0
		s.mdef *= 1.0 + float(b.get("def_pct", 0)) / 100.0
		s.move_speed *= 1.0 + float(b.get("speed_pct", 0)) / 100.0
		s.crit_phys += float(b.get("crit", 0))
		s.crit_mag += float(b.get("crit", 0))
	return s


static func from_monster(m: MonsterDef) -> Stats:
	var s := Stats.new()
	s.max_hp = m.hp; s.max_mp = 100.0
	s.patk = m.atk; s.matk = m.matk if m.matk > 0 else m.atk
	s.pdef = m.def; s.mdef = m.mdef
	s.move_speed = m.move_speed
	s.crit_phys = 3.0; s.crit_mag = 3.0
	return s
