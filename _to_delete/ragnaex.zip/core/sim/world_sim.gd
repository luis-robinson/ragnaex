extends Node
## WorldSim (autoload `Sim`): dona de TODAS as entidades de TODOS os mapas.
## Roda em tick fixo (physics). Não conhece nós 3D. Recebe InputCommands e emite Events.
## Este é o "servidor" — quando virar online, roda headless e recebe comandos por RPC.

const TICK_RATE := 60.0
const AI_EVERY := 3

var running: bool = false
var tick_count: int = 0
var time: float = 0.0
var rng := RandomNumberGenerator.new()

var maps: Dictionary = {}          # map_id -> MapState (Dictionary)
var entities: Dictionary = {}      # id -> SimEntity
var _next_id: int = 1
var _next_proj_id: int = 1
var player: SimEntity = null
var player_cmd: InputCommand = InputCommand.new()
var _pending_map_changes: Array = []

func _ready() -> void:
	rng.seed = 1337
	set_physics_process(true)

func _physics_process(delta: float) -> void:
	if running:
		tick(delta)

# ----------------------------------------------------------------------------
# MAPAS
# ----------------------------------------------------------------------------
func load_map(def: MapDef) -> Dictionary:
	if maps.has(def.id):
		return maps[def.id]
	var m := {"def": def, "entities": [], "projectiles": [], "loot": [], "spawners": [], "grid": {}, "colliders": []}
	maps[def.id] = m
	_build_collider_grid(m)
	for sp in def.spawners:
		m["spawners"].append({"def": sp, "alive": [], "timer": 0.0})
	for n in def.npcs:
		_spawn_npc(n, def.id)
	return m

func map_entities(map_id: String) -> Array:
	return maps[map_id]["entities"] if maps.has(map_id) else []

func map_def(map_id: String) -> MapDef:
	return maps[map_id]["def"] if maps.has(map_id) else null

func get_entity(id: int) -> SimEntity:
	return entities.get(id)

# ----------------------------------------------------------------------------
# SPAWN
# ----------------------------------------------------------------------------
func _register(e: SimEntity, map_id: String) -> SimEntity:
	e.id = _next_id
	_next_id += 1
	e.map_id = map_id
	entities[e.id] = e
	maps[map_id]["entities"].append(e)
	Events.entity_spawned.emit(e)
	return e

func spawn_character(kind: SimEntity.Kind, cls: ClassDef, char_name: String, map_id: String, pos: Vector3, level: int = 1) -> SimEntity:
	var e := SimEntity.new()
	e.kind = kind
	e.name = char_name
	e.class_def = cls
	e.level = level
	e.position = pos
	e.home_position = pos
	e.radius = Balance.ENTITY_RADIUS
	for sid in cls.skill_ids:
		var s: SkillDef = GameData.skills.get(sid)
		if s:
			e.skills.append(s)
			e.mastery[sid] = 0
	for item_id in cls.starting_equipment:
		var item: ItemDef = GameData.items.get(item_id)
		if item:
			e.equipment[item.slot] = item
	e.basic_skill = GameData.basic_skill_for_class(cls)
	e.potion_slots = ["potion_hp_s", "potion_mp_s", ""]
	e.add_item("potion_hp_s", 5)
	e.add_item("potion_mp_s", 3)
	e.gold = 50
	# bots começam com nível coerente: ganham maestria/equipamento proporcional
	if kind == SimEntity.Kind.BOT:
		e.mastery_points = level
		for s in e.skills:
			e.mastery[s.id] = clampi(level / 6, 0, 5)
	e.recompute_stats()
	e.heal_full()
	return _register(e, map_id)

func spawn_monster(mdef: MonsterDef, map_id: String, pos: Vector3, spawner = null) -> SimEntity:
	var e := SimEntity.new()
	e.kind = SimEntity.Kind.MONSTER
	e.name = mdef.name
	e.monster_def = mdef
	e.level = mdef.level
	e.position = pos
	e.home_position = pos
	e.radius = mdef.radius
	e.scale = mdef.scale
	e.basic_skill = GameData.basic_skill_for_monster(mdef)
	for sid in mdef.skill_ids:
		var s: SkillDef = GameData.skills.get(sid)
		if s:
			e.skills.append(s)
	e.brain = MonsterBrain.new()
	e.recompute_stats()
	e.heal_full()
	_register(e, map_id)
	if spawner != null:
		spawner["alive"].append(e.id)
	return e

func spawn_summon(owner: SimEntity, mdef: MonsterDef, pos: Vector3, duration: float) -> SimEntity:
	var e := SimEntity.new()
	e.kind = SimEntity.Kind.SUMMON
	e.name = mdef.name
	e.monster_def = mdef
	e.level = owner.level
	e.owner_id = owner.id
	e.position = pos
	e.home_position = pos
	e.radius = mdef.radius
	e.scale = mdef.scale
	e.summon_expires = time + duration
	e.basic_skill = GameData.basic_skill_for_monster(mdef)
	e.brain = MonsterBrain.new()
	e.recompute_stats()
	e.stats.patk = owner.stats.matk * 0.6
	e.heal_full()
	return _register(e, owner.map_id)

func _spawn_npc(n: Dictionary, map_id: String) -> SimEntity:
	var e := SimEntity.new()
	e.kind = SimEntity.Kind.NPC
	e.name = n.get("name", "NPC")
	e.position = n.get("pos", Vector3.ZERO)
	e.facing = deg_to_rad(float(n.get("facing", 180.0)))
	e.npc_data = n
	e.radius = 0.45
	e.hp = 1.0
	return _register(e, map_id)

func spawn_player(cls: ClassDef, char_name: String, map_id: String) -> SimEntity:
	var def := map_def(map_id)
	player = spawn_character(SimEntity.Kind.PLAYER, cls, char_name, map_id, def.spawn_point)
	return player

func spawn_bot(cls: ClassDef, bot_name: String, map_id: String, pos: Vector3, level: int) -> SimEntity:
	var b := spawn_character(SimEntity.Kind.BOT, cls, bot_name, map_id, pos, level)
	b.brain = BotBrain.new()
	b.brain.setup(b, rng)
	# equipamento de bot escala com nível
	_gear_bot(b)
	return b

func _gear_bot(b: SimEntity) -> void:
	var tier := clampi(b.level / 8, 0, 3)
	for item_id in GameData.items:
		var it: ItemDef = GameData.items[item_id]
		if not it.is_equipment() or it.rarity != tier:
			continue
		if it.class_restriction.size() > 0 and not (b.class_def.id in it.class_restriction):
			continue
		if it.slot == ItemDef.Slot.WEAPON and not (it.weapon_type in b.class_def.weapon_types):
			continue
		if it.weapon_type == "shield" and not b.class_def.can_use_shield:
			continue
		b.equipment[it.slot] = it
	b.recompute_stats()
	b.heal_full()

func despawn(e: SimEntity) -> void:
	if e == null or not entities.has(e.id):
		return
	entities.erase(e.id)
	if maps.has(e.map_id):
		maps[e.map_id]["entities"].erase(e)
	Events.entity_despawned.emit(e.id)

# ----------------------------------------------------------------------------
# TICK
# ----------------------------------------------------------------------------
func set_player_command(cmd: InputCommand) -> void:
	player_cmd = cmd

func tick(dt: float) -> void:
	tick_count += 1
	time += dt
	for map_id in maps:
		var m: Dictionary = maps[map_id]
		var ents: Array = m["entities"]
		# 1) comandos (jogador + cérebros)
		for e in ents:
			if not e.is_alive():
				continue
			var cmd: InputCommand = null
			if e == player:
				cmd = player_cmd
			elif e.brain != null:
				# cérebros pensam a 20 Hz (escalonados por id); entre pensamentos repetem o movimento
				if (tick_count + e.id) % AI_EVERY == 0 or e.brain_cmd == null:
					cmd = e.brain.think(e, self, m, dt * AI_EVERY)
					e.brain_cmd = cmd
				else:
					cmd = e.brain_cmd.duplicate_cmd()
					cmd.attack = false; cmd.skill_slot = -1; cmd.potion_slot = -1; cmd.dash = false; cmd.interact = false
			if cmd != null:
				_apply_command(e, cmd, m, dt)
		# 2) estados, cooldowns, movimento
		for e in ents.duplicate():
			_update_entity(e, m, dt)
		_update_projectiles(m, dt)
		_update_spawners(m, dt)
		_update_loot(m, dt)
	# descarta inputs de 1 tick do jogador
	player_cmd = player_cmd.duplicate_cmd()
	player_cmd.attack = false; player_cmd.skill_slot = -1; player_cmd.potion_slot = -1
	player_cmd.interact = false; player_cmd.dash = false
	_process_map_changes()

# ----------------------------------------------------------------------------
# COMANDOS
# ----------------------------------------------------------------------------
func _apply_command(e: SimEntity, cmd: InputCommand, m: Dictionary, dt: float) -> void:
	e.last_cmd = cmd
	if e.state == SimEntity.State.STUNNED or e.state == SimEntity.State.DEAD:
		return

	# --- input buffer: guarda a ação se não pode agir agora ---
	var action_cmd := cmd
	if cmd.has_action() and not cmd.interact:
		if e.can_act() or _in_cancel_window(e):
			e.buffered_cmd = null
		else:
			e.buffered_cmd = cmd.duplicate_cmd()
			e.buffered_ticks = Balance.INPUT_BUFFER_TICKS
	elif e.buffered_cmd != null:
		e.buffered_ticks -= 1
		if e.buffered_ticks <= 0:
			e.buffered_cmd = null
		elif e.can_act() or _in_cancel_window(e):
			action_cmd = e.buffered_cmd
			action_cmd.move = cmd.move
			action_cmd.aim = cmd.aim
			e.buffered_cmd = null

	# --- encarar o cursor (personagens) ---
	var can_turn := e.can_act() or (e.state == SimEntity.State.CASTING and e.current_skill and not e.current_skill.lock_facing)
	if can_turn and e.is_character():
		e.face_towards(cmd.aim)

	# --- poções: a qualquer momento vivo ---
	if action_cmd.potion_slot >= 0:
		use_potion(e, action_cmd.potion_slot)

	# --- dash ---
	if action_cmd.dash and e.dash_cd <= 0.0 and (e.can_act() or _in_cancel_window(e)) and not e.has_debuff("root"):
		var d := Vector3(cmd.move.x, 0, cmd.move.y)
		if d.length_squared() < 0.01:
			d = e.forward()
		e.dash_dir = d.normalized()
		e.dash_cd = Balance.DASH_COOLDOWN
		e.is_blocking = false
		e.set_state(SimEntity.State.DASHING, Balance.DASH_TIME)
		Events.skill_cast.emit(e.id, "dash", "active")
		return

	# --- skills ---
	if action_cmd.skill_slot >= 0 and (e.can_act() or _in_cancel_window(e)):
		if try_cast(e, action_cmd.skill_slot, action_cmd.aim, m):
			return
	# --- ataque básico ---
	if action_cmd.attack and (e.can_act() or _in_cancel_window(e)) and e.basic_cd <= 0.0 and e.basic_skill:
		_start_skill(e, e.basic_skill, -1, action_cmd.aim)
		e.basic_cd = e.basic_skill.cooldown
		return
	# --- interagir ---
	if action_cmd.interact and e == player:
		_interact(e, m)

	# --- bloqueio ---
	if e.is_character():
		var want_block := cmd.block and e.can_act() and e.mp > 0.0
		e.is_blocking = want_block
		if want_block:
			e.mp = maxf(0.0, e.mp - Balance.BLOCK_MP_PER_SEC * dt)

	# --- movimento ---
	if e.can_act():
		var mv := Vector3(cmd.move.x, 0.0, cmd.move.y)
		if mv.length() > 1.0:
			mv = mv.normalized()
		if e.has_debuff("root"):
			mv = Vector3.ZERO
		if mv.length_squared() > 0.001:
			var spd := e.stats.move_speed * e.slow_factor() * (0.5 if e.is_blocking else 1.0)
			e.velocity = mv * spd
			_move(e, e.velocity * dt, m)
			e.set_state(SimEntity.State.BLOCKING if e.is_blocking else SimEntity.State.MOVING)
			if not e.is_character():
				e.face_towards(e.position + mv)
		else:
			e.velocity = Vector3.ZERO
			e.set_state(SimEntity.State.BLOCKING if e.is_blocking else SimEntity.State.IDLE)
	elif e.state == SimEntity.State.CASTING and _in_cancel_window(e):
		var mv := Vector3(cmd.move.x, 0.0, cmd.move.y)
		if mv.length_squared() > 0.01:
			# cancel de recovery por movimento
			_end_skill(e)
			e.velocity = mv.normalized() * e.stats.move_speed * e.slow_factor()
			_move(e, e.velocity * dt, m)
			e.set_state(SimEntity.State.MOVING)

func _in_cancel_window(e: SimEntity) -> bool:
	if e.state != SimEntity.State.CASTING or e.current_skill == null:
		return false
	var s := e.current_skill
	return e.skill_applied and e.state_time >= s.startup + s.active + s.cancel_after

func _interact(e: SimEntity, m: Dictionary) -> void:
	var best: SimEntity = null
	var best_d := 2.6
	for o in m["entities"]:
		if o.kind == SimEntity.Kind.NPC:
			var d: float = o.position.distance_to(e.position)
			if d < best_d:
				best_d = d
				best = o
	if best:
		e.face_towards(best.position)
		Events.dialog_requested.emit(best.npc_data.get("id", ""))

# ----------------------------------------------------------------------------
# SKILLS
# ----------------------------------------------------------------------------
func try_cast(e: SimEntity, slot: int, aim: Vector3, m: Dictionary) -> bool:
	if slot < 0 or slot >= e.skills.size():
		return false
	var s: SkillDef = e.skills[slot]
	if e.level < s.unlock_level:
		return false
	var lv := e.mastery_of(s.id)
	if e.cooldowns.get(s.id, 0.0) > 0.0:
		return false
	var cost := s.mp_cost_at(lv)
	if e.mp < cost:
		if e == player:
			Events.notification.emit("MP insuficiente")
		return false
	e.mp -= cost
	e.cooldowns[s.id] = s.cooldown_at(lv)
	e.skill_uses[s.id] = int(e.skill_uses.get(s.id, 0)) + 1
	if int(e.skill_uses[s.id]) >= Balance.SKILL_USES_PER_FREE_MASTERY and lv < Balance.MASTERY_MAX:
		e.skill_uses[s.id] = 0
		e.mastery[s.id] = lv + 1
		e.recompute_stats()
		Events.mastery_changed.emit(e.id, s.id, lv + 1)
		if e == player:
			Events.notification.emit("Maestria de %s subiu para %d!" % [s.name, lv + 1])
	_start_skill(e, s, slot, aim)
	return true

func _start_skill(e: SimEntity, s: SkillDef, slot: int, aim: Vector3) -> void:
	if e.state == SimEntity.State.CASTING:
		_end_skill(e)
	e.current_skill = s
	e.current_skill_slot = slot
	e.skill_aim = aim
	e.skill_applied = false
	e.skill_phase = "startup"
	e.is_blocking = false
	e.velocity = Vector3.ZERO
	if e.is_character():
		e.face_towards(aim)
	e.set_state(SimEntity.State.CASTING, s.startup + s.active + s.recovery)
	Events.skill_cast.emit(e.id, s.id, "startup")

func _end_skill(e: SimEntity) -> void:
	e.current_skill = null
	e.skill_phase = ""
	e.current_skill_slot = -1
	e.set_state(SimEntity.State.IDLE)

func _update_skill(e: SimEntity, m: Dictionary, dt: float) -> void:
	var s := e.current_skill
	if s == null:
		e.set_state(SimEntity.State.IDLE)
		return
	var t := e.state_time
	if not e.skill_applied and t >= s.startup:
		e.skill_applied = true
		e.skill_phase = "active"
		Events.skill_cast.emit(e.id, s.id, "active")
		_apply_skill(e, s, m)
	elif e.skill_applied and e.skill_phase == "active" and t >= s.startup + s.active:
		e.skill_phase = "recovery"
		Events.skill_cast.emit(e.id, s.id, "recovery")
	if t >= e.state_duration:
		_end_skill(e)

func _apply_skill(e: SimEntity, s: SkillDef, m: Dictionary) -> void:
	var lv := e.mastery_of(s.id) if s.id in e.mastery else 0
	var power := s.power_at(lv)
	var extra: Dictionary = s.mastery_entry(lv).get("extra", {})
	var effects := s.effects.duplicate(true)
	for k in extra:
		effects[k] = extra[k]
	e.combat_timer = Balance.AGGRO_LOSE_TIME
	var aim := Combat.clamp_aim(e, e.skill_aim, s.range)
	var any_hit := false

	# movimento (dash de skill)
	if effects.has("dash"):
		var d := e.forward() * float(effects["dash"])
		_move(e, d, m)

	# invocações
	if effects.has("summon"):
		var sm: Dictionary = effects["summon"]
		var mdef: MonsterDef = GameData.monsters.get(sm.get("monster_id", ""))
		if mdef:
			# limita invocações vivas por dono
			var alive := 0
			for o in m["entities"]:
				if o.kind == SimEntity.Kind.SUMMON and o.owner_id == e.id and o.is_alive():
					alive += 1
			var n := int(sm.get("count", 1))
			for i in range(n):
				if alive >= int(sm.get("max", 3)):
					break
				var off := Vector3(rng.randf_range(-1.2, 1.2), 0, rng.randf_range(-1.2, 1.2))
				spawn_summon(e, mdef, e.position + e.forward() * 1.2 + off, float(sm.get("duration", 20)))
				alive += 1

	# projétil (DIRECTION com velocidade)
	if s.projectile_speed > 0.0 and s.target == SkillDef.Target.DIRECTION:
		_spawn_projectile(e, s, power, m, false)
		Events.skill_effect.emit(s.id, e.position, aim, s.radius)
		return

	if s.target == SkillDef.Target.SELF and s.kind != SkillDef.Kind.HEAL and s.kind != SkillDef.Kind.BUFF and not effects.has("shield"):
		Events.skill_effect.emit(s.id, e.position, e.position, s.radius)
		return

	var targets := Combat.select_targets(e, s, aim, m["entities"])
	Events.skill_effect.emit(s.id, e.position, aim, s.radius)
	for t in targets:
		match s.kind:
			SkillDef.Kind.HEAL:
				var amount := Combat.calc_heal(e, power, rng)
				_heal(e, t, amount)
			SkillDef.Kind.BUFF:
				pass
			_:
				var r := Combat.calc_damage(e, t, power, s.kind if s.kind != SkillDef.Kind.SUMMON else SkillDef.Kind.MAGICAL, rng)
				_deal_damage(e, t, r["amount"], r["crit"], r["blocked"], "magical" if s.kind == SkillDef.Kind.MAGICAL else "physical")
				any_hit = true
				if effects.has("heal_pct_of_dmg"):
					_heal(e, e, int(r["amount"] * float(effects["heal_pct_of_dmg"])))
		_apply_effects(e, t, effects, power)
	if effects.has("buff") or effects.has("shield"):
		_apply_effects(e, e, {"buff": effects.get("buff", null), "shield": effects.get("shield", null)}, power)
	if any_hit and s.hit_stop_frames > 0 and (e == player or targets.has(player)):
		Events.hit_stop.emit(s.hit_stop_frames)

func _apply_effects(src: SimEntity, t: SimEntity, effects: Dictionary, power: float) -> void:
	if not t.is_alive():
		return
	if effects.get("dot") != null:
		var d: Dictionary = effects["dot"]
		t.debuffs.append({"kind": "dot", "id": "dot_%d" % src.id, "remaining": float(d.get("duration", 4)), "dps": float(d.get("dps", 5)) * (src.stats.matk / 20.0), "src": src.id})
	if effects.get("slow") != null:
		var d: Dictionary = effects["slow"]
		t.debuffs.append({"kind": "slow", "remaining": float(d.get("duration", 2)), "pct": float(d.get("pct", 30))})
	if effects.get("root") != null:
		t.debuffs.append({"kind": "root", "remaining": float(effects["root"].get("duration", 2))})
	if effects.get("stun") != null and t.kind != SimEntity.Kind.NPC:
		var dur := float(effects["stun"].get("duration", 1))
		if t.monster_def and t.monster_def.is_boss:
			dur *= 0.4
		t.is_blocking = false
		t.current_skill = null
		t.set_state(SimEntity.State.STUNNED, dur)
	if effects.get("buff") != null:
		var b: Dictionary = effects["buff"].duplicate()
		b["remaining"] = float(b.get("duration", 10))
		t.buffs = t.buffs.filter(func(x): return x.get("id") != b.get("id"))
		t.buffs.append(b)
		t.recompute_stats()
		Events.buff_applied.emit(t.id, b.get("id", "buff"), b["remaining"])
	if effects.get("shield") != null:
		var sh: Dictionary = effects["shield"]
		t.shield_hp = maxf(t.shield_hp, t.stats.max_hp * float(sh.get("amount_pct_hp", 20)) / 100.0)
		t.buffs = t.buffs.filter(func(x): return x.get("id") != "shield")
		t.buffs.append({"id": "shield", "remaining": float(sh.get("duration", 5))})
		Events.buff_applied.emit(t.id, "shield", float(sh.get("duration", 5)))

func _spawn_projectile(e: SimEntity, s: SkillDef, power: float, m: Dictionary, is_basic: bool) -> void:
	var p := SimProjectile.new()
	p.id = _next_proj_id
	_next_proj_id += 1
	p.map_id = e.map_id
	p.owner_id = e.id
	p.skill = s
	p.power = power
	p.position = e.position + Vector3(0, 0.9, 0) + e.forward() * 0.6
	p.direction = e.forward()
	p.speed = s.projectile_speed
	p.max_distance = s.range
	p.radius = maxf(s.radius, 0.3)
	p.pierce = s.projectile_pierce
	p.color = s.icon_color
	p.is_basic = is_basic
	m["projectiles"].append(p)
	Events.projectile_spawned.emit(p)

func _update_projectiles(m: Dictionary, dt: float) -> void:
	var projs: Array = m["projectiles"]
	for p in projs.duplicate():
		var step: float = p.speed * dt
		p.position += p.direction * step
		p.traveled += step
		var owner: SimEntity = entities.get(p.owner_id)
		var remove: bool = p.traveled >= p.max_distance or owner == null
		if not remove:
			var def: MapDef = m["def"]
			var h := def.half()
			if absf(p.position.x) > h.x or absf(p.position.z) > h.y or _point_in_solid(p.position, m):
				remove = true
		if not remove:
			for t in m["entities"]:
				if not t.is_alive() or t.id in p.hit_ids or not owner.is_hostile_to(t):
					continue
				var d := Vector2(t.position.x, t.position.z).distance_to(Vector2(p.position.x, p.position.z))
				if d <= t.radius + p.radius:
					p.hit_ids.append(t.id)
					var r := Combat.calc_damage(owner, t, p.power, p.skill.kind, rng)
					_deal_damage(owner, t, r["amount"], r["crit"], r["blocked"], "magical" if p.skill.kind == SkillDef.Kind.MAGICAL else "physical")
					owner.combat_timer = Balance.AGGRO_LOSE_TIME
					_apply_effects(owner, t, p.skill.effects, p.power)
					if p.skill.hit_stop_frames > 0 and (owner == player or t == player):
						Events.hit_stop.emit(p.skill.hit_stop_frames)
					if not p.pierce:
						remove = true
						break
		if remove:
			projs.erase(p)
			Events.projectile_removed.emit(p.id)

# ----------------------------------------------------------------------------
# DANO / CURA / MORTE
# ----------------------------------------------------------------------------
func _deal_damage(attacker: SimEntity, target: SimEntity, amount: int, crit: bool, blocked: bool, kind: String) -> void:
	if not target.is_alive():
		return
	if target.shield_hp > 0.0:
		var absorbed := minf(target.shield_hp, float(amount))
		target.shield_hp -= absorbed
		amount -= int(absorbed)
	target.hp -= amount
	target.hit_flash = 0.12
	target.combat_timer = Balance.AGGRO_LOSE_TIME
	target.last_damage_from = attacker.id
	target.threat[attacker.id] = float(target.threat.get(attacker.id, 0.0)) + amount
	if target.kind == SimEntity.Kind.MONSTER:
		target.aggro_target = attacker.id if target.aggro_target < 0 else target.aggro_target
		target.aggro_timer = Balance.AGGRO_LOSE_TIME
	Events.damage_dealt.emit(attacker.id, target.id, amount, crit, blocked, kind)
	if blocked:
		Events.blocked_hit.emit(target.id)
	if target.hp <= 0.0:
		target.hp = 0.0
		_kill(target, attacker)

func _heal(src: SimEntity, target: SimEntity, amount: int) -> void:
	if not target.is_alive() or amount <= 0:
		return
	var before := target.hp
	target.hp = minf(target.stats.max_hp, target.hp + amount)
	Events.healed.emit(src.id, target.id, int(target.hp - before))

func _kill(e: SimEntity, killer: SimEntity) -> void:
	e.is_blocking = false
	e.current_skill = null
	e.buffs.clear()
	e.debuffs.clear()
	e.shield_hp = 0.0
	e.set_state(SimEntity.State.DEAD)
	e.dead_time = 0.0
	Events.entity_died.emit(e.id, killer.id if killer else -1)
	if e.kind == SimEntity.Kind.MONSTER:
		_on_monster_killed(e, killer)
	elif e.kind == SimEntity.Kind.PLAYER:
		Events.notification.emit("Você morreu. Renascendo em Aldara...")
		var loss := int(e.xp * Balance.DEATH_XP_PENALTY)
		e.xp = maxi(0, e.xp - loss)
	elif e.kind == SimEntity.Kind.BOT:
		if rng.randf() < 0.5:
			Events.chat_message.emit(e.name, GameData.random_bot_line("death"), "global")

func _on_monster_killed(mob: SimEntity, killer: SimEntity) -> void:
	var m: Dictionary = maps[mob.map_id]
	# XP para quem mais bateu + dono da invocação
	var credit: SimEntity = killer
	if credit and credit.kind == SimEntity.Kind.SUMMON:
		credit = entities.get(credit.owner_id)
	if credit and credit.is_character():
		var xp := mob.monster_def.xp
		var diff := mob.level - credit.level
		var mult := clampf(1.0 + diff * 0.08, 0.3, 1.6)
		gain_xp(credit, int(xp * mult))
		QuestSystem.on_kill(credit, mob.monster_def.id)
		# loot
		var lt: LootTable = GameData.loot_tables.get(mob.monster_def.loot_table)
		var gold := rng.randi_range(mob.monster_def.gold_min, mob.monster_def.gold_max) * (3 if mob.monster_def.is_boss else 1)
		var drops := {}
		if lt:
			drops = lt.roll(rng)
		if gold > 0:
			drops["gold"] = gold
		var i := 0
		for item_id in drops:
			var off := Vector3(cos(i * 1.7) * 0.5, 0.0, sin(i * 1.7) * 0.5)
			m["loot"].append({"pos": mob.position + off, "item": item_id, "count": int(drops[item_id]), "timer": 45.0, "owner": credit.id})
			Events.loot_dropped.emit(mob.map_id, mob.position + off, item_id, int(drops[item_id]))
			i += 1
	# remove do spawner
	for sp in m["spawners"]:
		sp["alive"].erase(mob.id)

func gain_xp(e: SimEntity, amount: int) -> void:
	if e.level >= Balance.MAX_LEVEL:
		return
	e.xp += amount
	Events.xp_gained.emit(e.id, amount)
	while e.level < Balance.MAX_LEVEL and e.xp >= Balance.xp_for_level(e.level):
		e.xp -= Balance.xp_for_level(e.level)
		e.level += 1
		e.mastery_points += Balance.MASTERY_POINTS_PER_LEVEL + (1 if e.level in Balance.MASTERY_BONUS_LEVELS else 0)
		e.recompute_stats()
		e.hp = minf(e.stats.max_hp, e.hp + e.stats.max_hp * 0.3)
		e.mp = minf(e.stats.max_mp, e.mp + e.stats.max_mp * 0.3)
		Events.level_up.emit(e.id, e.level)
		if e == player:
			Events.notification.emit("Nível %d! +%d ponto(s) de maestria" % [e.level, Balance.MASTERY_POINTS_PER_LEVEL])
		elif e.kind == SimEntity.Kind.BOT and rng.randf() < 0.35:
			Events.chat_message.emit(e.name, GameData.random_bot_line("levelup") % e.level, "global")
		if e.level == Balance.MAX_LEVEL:
			e.xp = 0

func respawn_character(e: SimEntity) -> void:
	var town := GameData.town_map_id()
	e.hp = e.stats.max_hp * 0.5
	e.mp = e.stats.max_mp * 0.5
	e.set_state(SimEntity.State.IDLE)
	e.threat.clear()
	var def := map_def(town)
	_change_map(e, town, def.spawn_point)
	Events.entity_respawned.emit(e.id)

# ----------------------------------------------------------------------------
# UPDATE POR ENTIDADE
# ----------------------------------------------------------------------------
func _update_entity(e: SimEntity, m: Dictionary, dt: float) -> void:
	e.state_time += dt
	e.hit_flash = maxf(0.0, e.hit_flash - dt)
	if e.kind == SimEntity.Kind.NPC:
		return
	# cooldowns
	e.basic_cd = maxf(0.0, e.basic_cd - dt)
	e.potion_cd = maxf(0.0, e.potion_cd - dt)
	e.dash_cd = maxf(0.0, e.dash_cd - dt)
	e.combat_timer = maxf(0.0, e.combat_timer - dt)
	for k in e.cooldowns.keys():
		e.cooldowns[k] = maxf(0.0, e.cooldowns[k] - dt)
	if e.state == SimEntity.State.DEAD:
		e.dead_time += dt
		if e.kind == SimEntity.Kind.MONSTER or e.kind == SimEntity.Kind.SUMMON:
			if e.dead_time >= Balance.CORPSE_TIME:
				despawn(e)
		elif e.dead_time >= Balance.PLAYER_RESPAWN_TIME + (2.0 if e.kind == SimEntity.Kind.BOT else 0.0):
			respawn_character(e)
		return
	# invocação expira
	if e.kind == SimEntity.Kind.SUMMON and time >= e.summon_expires:
		despawn(e)
		return
	# buffs / debuffs
	var recompute := false
	for b in e.buffs.duplicate():
		b["remaining"] = float(b.get("remaining", 0)) - dt
		if b["remaining"] <= 0.0:
			e.buffs.erase(b)
			if b.get("id") == "shield":
				e.shield_hp = 0.0
			recompute = true
	for d in e.debuffs.duplicate():
		d["remaining"] = float(d.get("remaining", 0)) - dt
		if d.get("kind") == "dot":
			d["acc"] = float(d.get("acc", 0.0)) + float(d["dps"]) * dt
			if d["acc"] >= 1.0:
				var dmg := int(d["acc"])
				d["acc"] -= dmg
				var src: SimEntity = entities.get(int(d.get("src", -1)))
				if src:
					_deal_damage(src, e, dmg, false, false, "dot")
					if not e.is_alive():
						return
		if d["remaining"] <= 0.0:
			e.debuffs.erase(d)
	if recompute:
		e.recompute_stats()
	# regen
	if e.combat_timer <= 0.0 and e.is_character():
		e.hp = minf(e.stats.max_hp, e.hp + e.stats.max_hp * 0.02 * dt)
	if not e.is_blocking:
		e.mp = minf(e.stats.max_mp, e.mp + (e.stats.max_mp * 0.015 + 1.0) * dt)
	# estados
	match e.state:
		SimEntity.State.CASTING:
			_update_skill(e, m, dt)
		SimEntity.State.DASHING:
			_move(e, e.dash_dir * (Balance.DASH_DISTANCE / Balance.DASH_TIME) * dt, m)
			if e.state_time >= e.state_duration:
				e.set_state(SimEntity.State.IDLE)
		SimEntity.State.STUNNED:
			if e.state_time >= e.state_duration:
				e.set_state(SimEntity.State.IDLE)
		_:
			pass
	# aggro
	if e.kind == SimEntity.Kind.MONSTER and e.aggro_target >= 0:
		e.aggro_timer -= dt
		var t: SimEntity = entities.get(e.aggro_target)
		if t == null or not t.is_alive() or t.map_id != e.map_id or e.aggro_timer <= 0.0:
			e.aggro_target = -1
			e.threat.clear()
	# portais (personagens vivos)
	if e.is_character():
		_check_portals(e, m)
	# separação entre entidades (empurrão suave), em ticks alternados
	if (tick_count + e.id) % 2 == 0:
		_separate(e, m)

func use_potion(e: SimEntity, slot: int) -> bool:
	if slot < 0 or slot > 2 or e.potion_cd > 0.0:
		return false
	var item_id: String = e.potion_slots[slot]
	if item_id == "" or not e.has_item(item_id):
		if e == player:
			Events.notification.emit("Sem poção nesse slot")
		return false
	var item: ItemDef = GameData.items[item_id]
	e.remove_item(item_id, 1)
	e.potion_cd = item.consume_cooldown
	var c := item.consume
	if c.has("heal"):
		_heal(e, e, int(c["heal"]))
	if c.has("heal_pct"):
		_heal(e, e, int(e.stats.max_hp * float(c["heal_pct"])))
	if c.has("mana"):
		e.mp = minf(e.stats.max_mp, e.mp + float(c["mana"]))
	if c.has("mana_pct"):
		e.mp = minf(e.stats.max_mp, e.mp + e.stats.max_mp * float(c["mana_pct"]))
	if c.has("buff"):
		_apply_effects(e, e, {"buff": c["buff"]}, 1.0)
	Events.potion_used.emit(e.id, slot)
	return true

# ----------------------------------------------------------------------------
# MOVIMENTO / COLISÃO (dados do MapDef)
# ----------------------------------------------------------------------------
func _move(e: SimEntity, delta: Vector3, m: Dictionary) -> void:
	var def: MapDef = m["def"]
	var p := e.position + delta
	p.y = 0.0
	p = def.clamp_inside(p, e.radius)
	p = _resolve_obstacles(p, e.radius, m)
	e.position = p

const GRID_CELL := 12.0

## Pré-computa colisores (círculo ou caixa rotacionada) e os indexa numa grade espacial.
func _build_collider_grid(m: Dictionary) -> void:
	var def: MapDef = m["def"]
	var cols: Array = []
	var grid: Dictionary = {}
	for ob in def.obstacles:
		if not ob.get("solid", true):
			continue
		var pos: Vector3 = ob["pos"]
		var size: Vector3 = ob.get("size", Vector3.ONE)
		var kind: String = ob.get("kind", "house")
		var circle: bool = kind in ["tree", "rock", "pillar", "well", "fountain", "lamp", "statue"]
		var c := {"circle": circle, "x": pos.x, "z": pos.z, "cr": maxf(size.x, size.z) * 0.5,
			"hx": size.x * 0.5, "hz": size.z * 0.5, "rot": deg_to_rad(float(ob.get("rot", 0.0))), "tall": size.y > 1.2}
		var idx := cols.size()
		cols.append(c)
		var reach: float = c["cr"] if circle else maxf(size.x, size.z) * 0.75
		var cx0 := floori((pos.x - reach) / GRID_CELL); var cx1 := floori((pos.x + reach) / GRID_CELL)
		var cz0 := floori((pos.z - reach) / GRID_CELL); var cz1 := floori((pos.z + reach) / GRID_CELL)
		for cx in range(cx0, cx1 + 1):
			for cz in range(cz0, cz1 + 1):
				var key := Vector2i(cx, cz)
				if not grid.has(key):
					grid[key] = []
				grid[key].append(idx)
	m["colliders"] = cols
	m["grid"] = grid

func _nearby_colliders(m: Dictionary, p: Vector3) -> Array:
	var key := Vector2i(floori(p.x / GRID_CELL), floori(p.z / GRID_CELL))
	return m["grid"].get(key, [])

func _resolve_obstacles(p: Vector3, r: float, m: Dictionary) -> Vector3:
	var cols: Array = m["colliders"]
	for idx in _nearby_colliders(m, p):
		var c: Dictionary = cols[idx]
		if c["circle"]:
			var cr: float = c["cr"]
			var rel := Vector2(p.x - c["x"], p.z - c["z"])
			var d := rel.length()
			if d < cr + r and d > 0.0001:
				rel = rel / d * (cr + r)
				p.x = c["x"] + rel.x
				p.z = c["z"] + rel.y
		else:
			var rot: float = c["rot"]
			var rel := Vector2(p.x - c["x"], p.z - c["z"]).rotated(-rot)
			var hx: float = c["hx"] + r
			var hz: float = c["hz"] + r
			if absf(rel.x) < hx and absf(rel.y) < hz:
				var dx := hx - absf(rel.x)
				var dz := hz - absf(rel.y)
				if dx < dz:
					rel.x = signf(rel.x) * hx if rel.x != 0.0 else hx
				else:
					rel.y = signf(rel.y) * hz if rel.y != 0.0 else hz
				rel = rel.rotated(rot)
				p.x = c["x"] + rel.x
				p.z = c["z"] + rel.y
	return p

func _point_in_solid(p: Vector3, m: Dictionary) -> bool:
	var cols: Array = m["colliders"]
	for idx in _nearby_colliders(m, p):
		var c: Dictionary = cols[idx]
		if not c["tall"]:
			continue
		if c["circle"]:
			if Vector2(p.x - c["x"], p.z - c["z"]).length() < c["cr"]:
				return true
		else:
			var rel := Vector2(p.x - c["x"], p.z - c["z"]).rotated(-c["rot"])
			if absf(rel.x) < c["hx"] and absf(rel.y) < c["hz"]:
				return true
	return false

func is_walkable(p: Vector3, def: MapDef, r: float = 0.45) -> bool:
	var h := def.half()
	if absf(p.x) > h.x - r or absf(p.z) > h.y - r:
		return false
	if not maps.has(def.id):
		return true
	return _resolve_obstacles(p, r, maps[def.id]).distance_to(p) < 0.01

func random_walkable(def: MapDef, center: Vector3, radius: float) -> Vector3:
	for i in range(12):
		var a := rng.randf() * TAU
		var d := rng.randf_range(0.0, radius)
		var p := center + Vector3(cos(a) * d, 0.0, sin(a) * d)
		if is_walkable(p, def):
			return p
	return def.clamp_inside(center, 1.0)

func _separate(e: SimEntity, m: Dictionary) -> void:
	if e.state == SimEntity.State.DASHING:
		return
	for o in m["entities"]:
		if o == e or not o.is_alive():
			continue
		var rel := Vector2(e.position.x - o.position.x, e.position.z - o.position.z)
		var min_d: float = e.radius + o.radius
		var d := rel.length()
		if d < min_d and d > 0.0001:
			var push := (min_d - d) * 0.5
			var dir := rel / d
			e.position.x += dir.x * push
			e.position.z += dir.y * push
		elif d <= 0.0001:
			e.position.x += 0.05

func _check_portals(e: SimEntity, m: Dictionary) -> void:
	var def: MapDef = m["def"]
	for pt in def.portals:
		var pos: Vector3 = pt["pos"]
		if Vector2(e.position.x, e.position.z).distance_to(Vector2(pos.x, pos.z)) <= float(pt.get("radius", 2.0)):
			_pending_map_changes.append({"e": e, "map": pt["target_map"], "pos": pt["target_pos"]})
			return

func _process_map_changes() -> void:
	for ch in _pending_map_changes:
		_change_map(ch["e"], ch["map"], ch["pos"])
	_pending_map_changes.clear()

func _change_map(e: SimEntity, map_id: String, pos: Vector3) -> void:
	if not maps.has(map_id):
		var def: MapDef = GameData.maps.get(map_id)
		if def == null:
			return
		load_map(def)
	if maps.has(e.map_id):
		maps[e.map_id]["entities"].erase(e)
	# invocações seguem o dono
	e.map_id = map_id
	e.position = pos
	e.velocity = Vector3.ZERO
	e.aggro_target = -1
	maps[map_id]["entities"].append(e)
	Events.entity_changed_map.emit(e.id, map_id)
	for o in entities.values():
		if o.kind == SimEntity.Kind.SUMMON and o.owner_id == e.id and o.map_id != map_id:
			maps[o.map_id]["entities"].erase(o)
			o.map_id = map_id
			o.position = pos + Vector3(1, 0, 1)
			maps[map_id]["entities"].append(o)
			Events.entity_changed_map.emit(o.id, map_id)

# ----------------------------------------------------------------------------
# SPAWNERS / LOOT
# ----------------------------------------------------------------------------
func _update_spawners(m: Dictionary, dt: float) -> void:
	var def: MapDef = m["def"]
	for sp in m["spawners"]:
		var sdef: Dictionary = sp["def"]
		sp["alive"] = sp["alive"].filter(func(id): return entities.has(id))
		if sp["alive"].size() < int(sdef.get("count", 1)):
			sp["timer"] -= dt
			if sp["timer"] <= 0.0:
				var mdef: MonsterDef = GameData.monsters.get(sdef["monster_id"])
				if mdef:
					var pos := random_walkable(def, sdef["pos"], float(sdef.get("radius", 6.0)))
					spawn_monster(mdef, def.id, pos, sp)
				sp["timer"] = float(sdef.get("respawn", 10.0)) if sp["alive"].size() > 0 else 0.5

func _update_loot(m: Dictionary, dt: float) -> void:
	var loot: Array = m["loot"]
	for l in loot.duplicate():
		l["timer"] -= dt
		if l["timer"] <= 0.0:
			loot.erase(l)
			continue
		for e in m["entities"]:
			if not e.is_character() or not e.is_alive():
				continue
			if Vector2(e.position.x, e.position.z).distance_to(Vector2(l["pos"].x, l["pos"].z)) <= 0.9:
				_pickup(e, l)
				loot.erase(l)
				break

func _pickup(e: SimEntity, l: Dictionary) -> void:
	if l["item"] == "gold":
		e.gold += int(l["count"])
		if e == player:
			Events.notification.emit("+%d ouro" % int(l["count"]))
	else:
		e.add_item(l["item"], int(l["count"]))
		QuestSystem.on_item_changed(e, l["item"])
		if e == player:
			var it: ItemDef = GameData.items.get(l["item"])
			Events.notification.emit("+%d %s" % [int(l["count"]), it.name if it else l["item"]])

# ----------------------------------------------------------------------------
# EQUIPAMENTO / MAESTRIA (chamados pela UI)
# ----------------------------------------------------------------------------
func equip(e: SimEntity, item_id: String) -> bool:
	var item: ItemDef = GameData.items.get(item_id)
	if item == null or not item.is_equipment() or not e.has_item(item_id):
		return false
	if e.level < item.level_req:
		Events.notification.emit("Requer nível %d" % item.level_req)
		return false
	if item.class_restriction.size() > 0 and not (e.class_def.id in item.class_restriction):
		Events.notification.emit("Sua classe não pode usar isso")
		return false
	if item.slot == ItemDef.Slot.WEAPON and not (item.weapon_type in e.class_def.weapon_types):
		Events.notification.emit("Tipo de arma inválido para sua classe")
		return false
	if item.weapon_type == "shield" and not e.class_def.can_use_shield:
		Events.notification.emit("Sua classe não usa escudo")
		return false
	var slot := item.slot
	e.remove_item(item_id, 1)
	if e.equipment.has(slot) and e.equipment[slot] != null:
		e.add_item(e.equipment[slot].id, 1)
	e.equipment[slot] = item
	e.recompute_stats()
	Events.equipment_changed.emit(e.id)
	return true

func unequip(e: SimEntity, slot: int) -> void:
	if e.equipment.has(slot) and e.equipment[slot] != null:
		e.add_item(e.equipment[slot].id, 1)
		e.equipment.erase(slot)
		e.recompute_stats()
		Events.equipment_changed.emit(e.id)

func upgrade_mastery(e: SimEntity, skill_id: String) -> bool:
	var lv := e.mastery_of(skill_id)
	if lv >= Balance.MASTERY_MAX:
		return false
	var cost := Balance.mastery_cost(lv)
	if e.mastery_points < cost:
		Events.notification.emit("Pontos de maestria insuficientes (%d)" % cost)
		return false
	e.mastery_points -= cost
	e.mastery[skill_id] = lv + 1
	Events.mastery_changed.emit(e.id, skill_id, lv + 1)
	return true

func set_potion_slot(e: SimEntity, slot: int, item_id: String) -> void:
	e.potion_slots[slot] = item_id
