class_name CraftSystem
extends RefCounted

static func recipes_for_station(station: String) -> Array:
	var out: Array = []
	for rid in GameData.recipes:
		var r: RecipeDef = GameData.recipes[rid]
		if r.station == station:
			out.append(r)
	out.sort_custom(func(a, b): return a.level_req < b.level_req)
	return out

static func can_craft(e: SimEntity, r: RecipeDef) -> bool:
	if e.level < r.level_req or e.gold < r.gold_cost:
		return false
	for item_id in r.ingredients:
		if not e.has_item(item_id, int(r.ingredients[item_id])):
			return false
	return true

static func craft(e: SimEntity, r: RecipeDef) -> bool:
	if not can_craft(e, r):
		return false
	for item_id in r.ingredients:
		e.remove_item(item_id, int(r.ingredients[item_id]))
	e.gold -= r.gold_cost
	e.add_item(r.result_item, r.result_count)
	QuestSystem.on_craft(e, r.result_item, r.result_count)
	QuestSystem.on_item_changed(e, r.result_item)
	Events.crafted.emit(e.id, r.result_item, r.result_count)
	var it: ItemDef = GameData.items.get(r.result_item)
	Events.notification.emit("Criou %s x%d" % [it.name if it else r.result_item, r.result_count])
	return true

# --- loja ---
static func buy(e: SimEntity, item_id: String, count: int = 1) -> bool:
	var it: ItemDef = GameData.items.get(item_id)
	if it == null:
		return false
	var cost := it.price * count
	if e.gold < cost:
		Events.notification.emit("Ouro insuficiente")
		return false
	e.gold -= cost
	e.add_item(item_id, count)
	QuestSystem.on_item_changed(e, item_id)
	return true

static func sell(e: SimEntity, item_id: String, count: int = 1) -> bool:
	var it: ItemDef = GameData.items.get(item_id)
	if it == null or not e.has_item(item_id, count) or it.type == ItemDef.Type.QUEST:
		return false
	e.remove_item(item_id, count)
	e.gold += int(it.price * 0.5) * count
	QuestSystem.on_item_changed(e, item_id)
	return true
