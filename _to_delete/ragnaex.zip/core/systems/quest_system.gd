class_name QuestSystem
extends RefCounted
## Quests data-driven. Progresso vive na entidade (quests_active / quests_completed).

static func available_from_npc(e: SimEntity, npc_id: String) -> Array:
	var out: Array = []
	for qid in GameData.quests:
		var q: QuestDef = GameData.quests[qid]
		if q.giver_npc != npc_id:
			continue
		if can_accept(e, q):
			out.append(q)
	return out

static func can_accept(e: SimEntity, q: QuestDef) -> bool:
	if e.quests_active.has(q.id) or q.id in e.quests_completed:
		return false
	if e.level < q.level_req:
		return false
	if q.prereq_quest != "" and not (q.prereq_quest in e.quests_completed):
		return false
	return true

static func accept(e: SimEntity, q: QuestDef) -> void:
	if not can_accept(e, q):
		return
	e.quests_active[q.id] = 0
	Events.quest_accepted.emit(e.id, q.id)
	# COLLECT: conta o que já tem; TALK ao próprio NPC completa na hora
	if q.type == QuestDef.Type.COLLECT:
		on_item_changed(e, q.target_id)

static func progress(e: SimEntity, q: QuestDef) -> int:
	if q.type == QuestDef.Type.COLLECT:
		return mini(int(e.inventory.get(q.target_id, 0)), q.count)
	return int(e.quests_active.get(q.id, 0))

static func is_complete(e: SimEntity, q: QuestDef) -> bool:
	return e.quests_active.has(q.id) and progress(e, q) >= q.count

static func on_kill(e: SimEntity, monster_id: String) -> void:
	for qid in e.quests_active.keys():
		var q: QuestDef = GameData.quests.get(qid)
		if q and q.type == QuestDef.Type.KILL and q.target_id == monster_id:
			var cur := mini(int(e.quests_active[qid]) + 1, q.count)
			e.quests_active[qid] = cur
			Events.quest_progress.emit(e.id, qid, cur, q.count)

static func on_item_changed(e: SimEntity, item_id: String) -> void:
	for qid in e.quests_active.keys():
		var q: QuestDef = GameData.quests.get(qid)
		if q and q.type == QuestDef.Type.COLLECT and q.target_id == item_id:
			Events.quest_progress.emit(e.id, qid, progress(e, q), q.count)

static func on_craft(e: SimEntity, item_id: String, count: int) -> void:
	for qid in e.quests_active.keys():
		var q: QuestDef = GameData.quests.get(qid)
		if q and q.type == QuestDef.Type.CRAFT and q.target_id == item_id:
			var cur := mini(int(e.quests_active[qid]) + count, q.count)
			e.quests_active[qid] = cur
			Events.quest_progress.emit(e.id, qid, cur, q.count)

static func on_talk(e: SimEntity, npc_id: String) -> void:
	for qid in e.quests_active.keys():
		var q: QuestDef = GameData.quests.get(qid)
		if q and q.type == QuestDef.Type.TALK and q.target_id == npc_id:
			e.quests_active[qid] = q.count
			Events.quest_progress.emit(e.id, qid, q.count, q.count)

## Quests ativas que podem ser entregues neste NPC
static func turnins_at(e: SimEntity, npc_id: String) -> Array:
	var out: Array = []
	for qid in e.quests_active.keys():
		var q: QuestDef = GameData.quests.get(qid)
		if q and q.turnin() == npc_id and is_complete(e, q):
			out.append(q)
	return out

static func complete(e: SimEntity, q: QuestDef, sim) -> void:
	if not is_complete(e, q):
		return
	if q.type == QuestDef.Type.COLLECT:
		e.remove_item(q.target_id, q.count)
	e.quests_active.erase(q.id)
	e.quests_completed.append(q.id)
	sim.gain_xp(e, q.reward_xp)
	e.gold += q.reward_gold
	for item_id in q.reward_items:
		e.add_item(item_id, int(q.reward_items[item_id]))
	Events.quest_completed.emit(e.id, q.id)
	Events.notification.emit("Quest concluída: %s (+%d XP, +%d ouro)" % [q.title, q.reward_xp, q.reward_gold])
