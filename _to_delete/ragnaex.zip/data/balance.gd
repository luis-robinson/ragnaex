extends Node
## Todas as constantes de balanceamento num lugar só (autoload `Balance`).

const MAX_LEVEL := 30
const ATTRS := ["FOR", "AGI", "VIT", "WILL", "INT"]

# --- atributos -> stats derivados ---
const HP_PER_VIT := 12.0
const MP_PER_WILL := 8.0
const PATK_PER_FOR := 2.0
const PATK_PER_AGI_RANGED := 2.2      # arco: AGI substitui FOR
const PATK_PER_AGI_DAGGER := 1.0      # adaga: AGI complementa FOR
const PATK_PER_AGI_OTHER := 0.25
const MATK_PER_INT := 2.5
const PDEF_PER_VIT := 1.5
const MDEF_PER_WILL := 1.5
const CRIT_BASE := 5.0
const CRIT_PER_AGI := 0.4             # % por ponto
const MCRIT_PER_INT := 0.4
const CRIT_MULT := 1.5
const HEAL_PER_WILL := 0.03           # +3% de cura por ponto
const BLOCK_BASE_SHIELD := 12.0       # % chance base com escudo
const BLOCK_PER_FOR_SHIELD := 0.6     # % chance por FOR com escudo
const BLOCK_REDUCTION_BASE := 30.0    # % de redução ao bloquear
const BLOCK_REDUCTION_PER_FOR := 0.5  # com arma física
const BLOCK_REDUCTION_CAP := 60.0
const BLOCK_REDUCTION_MAGIC_WEAPON := 15.0
const BLOCK_MP_PER_SEC := 2.0
const GUARD_HOLD_REDUCTION_BONUS := 25.0  # segurando RMB: redução extra (bloqueio "ativo")
const DEF_FACTOR := 0.5               # dano -= def * DEF_FACTOR
const DMG_VARIANCE := 0.1

# --- progressão ---
const XP_BASE := 60.0
const XP_GROWTH := 1.22
const DEATH_XP_PENALTY := 0.03
const MASTERY_POINTS_PER_LEVEL := 1
const MASTERY_BONUS_LEVELS := [10, 20, 30]  # +1 ponto extra
const MASTERY_MAX := 5
const SKILL_USES_PER_FREE_MASTERY := 30
const SKILL_UNLOCK_LEVELS := [1, 3, 6, 10, 15, 20]

# --- combate / game feel ---
const INPUT_BUFFER_TICKS := 8
const HIT_STOP_FRAMES_BASIC := 2
const DASH_DISTANCE := 3.2
const DASH_TIME := 0.18
const DASH_COOLDOWN := 1.6
const POTION_COOLDOWN := 4.0
const AGGRO_LOSE_TIME := 6.0
const CORPSE_TIME := 1.6
const PLAYER_RESPAWN_TIME := 3.0
const ENTITY_RADIUS := 0.45

# --- bots ---
const BOT_CHAT_MIN := 25.0
const BOT_CHAT_MAX := 90.0

static func xp_for_level(level: int) -> int:
	if level >= MAX_LEVEL:
		return 0
	return int(round(XP_BASE * pow(XP_GROWTH, level - 1)))

static func mastery_cost(current_level: int) -> int:
	return current_level + 1
