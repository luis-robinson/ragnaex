class_name ClassesCatalog
extends RefCounted
## As 8 classes. Atributos vêm do equipamento inicial (ver items_catalog).

static func _mk(d: Dictionary) -> ClassDef:
	var c := ClassDef.new()
	for k in d:
		c.set(k, d[k])
	if c.model == "":
		c.model = c.id   # assets/models/<id>.glb (gerado por tools/blender/build_characters.py)
	return c

static func build() -> Array:
	return [
		_mk({"id": "paladin", "name": "Paladino", "role": "tank", "color": Color(0.95, 0.85, 0.45),
			"description": "Espada e escudo. Bloqueio forte, cura leve e provocação. Segura a linha de frente.",
			"weapon_types": ["sword", "mace"] as Array[String], "can_use_shield": true,
			"base_hp": 140.0, "base_mp": 45.0, "hp_per_level": 16.0, "mp_per_level": 5.0, "move_speed": 5.2,
			"basic_attack_power": 1.0, "basic_attack_cooldown": 0.7, "basic_attack_range": 1.9,
			"starting_equipment": ["sword_rusty", "shield_wood", "armor_leather"] as Array[String],
			"skill_ids": ["pal_holy_strike", "pal_shield_bash", "pal_consecrate", "pal_lay_hands", "pal_taunt", "pal_divine_shield"] as Array[String]}),
		_mk({"id": "berserker", "name": "Berserker", "role": "dps", "color": Color(0.85, 0.3, 0.25),
			"description": "Machado de duas mãos. Dano absurdo, fúria que cresce com HP baixo. Sem escudo, sem medo.",
			"weapon_types": ["axe2h"] as Array[String], "can_use_shield": false,
			"base_hp": 125.0, "base_mp": 40.0, "hp_per_level": 14.0, "mp_per_level": 4.0, "move_speed": 5.4,
			"basic_attack_power": 1.25, "basic_attack_cooldown": 0.85, "basic_attack_range": 2.2,
			"starting_equipment": ["axe_old", "armor_leather"] as Array[String],
			"skill_ids": ["ber_cleave", "ber_leap", "ber_whirlwind", "ber_fury", "ber_execute", "ber_warcry"] as Array[String]}),
		_mk({"id": "bishop", "name": "Bispo", "role": "healer", "color": Color(0.95, 0.95, 0.9),
			"description": "Cajado sagrado. Curas, escudos e buffs para o grupo; luz que fere mortos-vivos.",
			"weapon_types": ["staff", "mace"] as Array[String], "can_use_shield": false,
			"base_hp": 90.0, "base_mp": 90.0, "hp_per_level": 9.0, "mp_per_level": 10.0, "move_speed": 5.3,
			"basic_attack_power": 0.9, "basic_attack_cooldown": 0.75, "basic_attack_range": 7.0, "basic_attack_is_ranged": true, "basic_attack_kind": 1,
			"starting_equipment": ["staff_novice", "robe_cloth"] as Array[String],
			"skill_ids": ["bis_heal", "bis_smite", "bis_blessing", "bis_sanctuary", "bis_purify", "bis_judgement"] as Array[String]}),
		_mk({"id": "druid", "name": "Druida", "role": "caster", "color": Color(0.45, 0.8, 0.35),
			"description": "Natureza. Raízes, veneno, cura em área e forma de fera para lutar de perto.",
			"weapon_types": ["staff", "dagger"] as Array[String], "can_use_shield": false,
			"base_hp": 105.0, "base_mp": 75.0, "hp_per_level": 11.0, "mp_per_level": 8.0, "move_speed": 5.5,
			"basic_attack_power": 0.9, "basic_attack_cooldown": 0.7, "basic_attack_range": 6.5, "basic_attack_is_ranged": true, "basic_attack_kind": 1,
			"starting_equipment": ["staff_oak", "robe_cloth"] as Array[String],
			"skill_ids": ["dru_thorns", "dru_entangle", "dru_regrowth", "dru_swarm", "dru_bear_form", "dru_wild_growth"] as Array[String]}),
		_mk({"id": "ranger", "name": "Ranger", "role": "ranged", "color": Color(0.5, 0.75, 0.55),
			"description": "Arco. Skillshots longos, armadilhas e mobilidade. Mantenha distância.",
			"weapon_types": ["bow"] as Array[String], "can_use_shield": false,
			"base_hp": 100.0, "base_mp": 55.0, "hp_per_level": 10.0, "mp_per_level": 6.0, "move_speed": 5.8,
			"basic_attack_power": 1.0, "basic_attack_cooldown": 0.55, "basic_attack_range": 9.0, "basic_attack_is_ranged": true,
			"starting_equipment": ["bow_short", "armor_leather"] as Array[String],
			"skill_ids": ["ran_power_shot", "ran_multishot", "ran_disengage", "ran_trap", "ran_mark", "ran_rain"] as Array[String]}),
		_mk({"id": "assassin", "name": "Assassino", "role": "dps", "color": Color(0.55, 0.35, 0.75),
			"description": "Adagas. Crítico alto, veneno, furtividade e explosões de dano em alvos isolados.",
			"weapon_types": ["dagger"] as Array[String], "can_use_shield": false,
			"base_hp": 95.0, "base_mp": 60.0, "hp_per_level": 10.0, "mp_per_level": 6.0, "move_speed": 6.2,
			"basic_attack_power": 0.75, "basic_attack_cooldown": 0.38, "basic_attack_range": 1.7,
			"starting_equipment": ["dagger_iron", "armor_leather"] as Array[String],
			"skill_ids": ["ass_backstab", "ass_shadowstep", "ass_poison", "ass_fan", "ass_smoke", "ass_execute"] as Array[String]}),
		_mk({"id": "elementalist", "name": "Elementalista", "role": "caster", "color": Color(0.35, 0.6, 0.95),
			"description": "Fogo, gelo e raio. AoE no chão, controle e o maior dano mágico do jogo.",
			"weapon_types": ["staff", "wand"] as Array[String], "can_use_shield": false,
			"base_hp": 85.0, "base_mp": 100.0, "hp_per_level": 8.0, "mp_per_level": 11.0, "move_speed": 5.3,
			"basic_attack_power": 1.0, "basic_attack_cooldown": 0.65, "basic_attack_range": 8.0, "basic_attack_is_ranged": true, "basic_attack_kind": 1,
			"starting_equipment": ["wand_apprentice", "robe_cloth"] as Array[String],
			"skill_ids": ["ele_fireball", "ele_frost_nova", "ele_lightning", "ele_meteor", "ele_blink", "ele_blizzard"] as Array[String]}),
		_mk({"id": "necromancer", "name": "Necromancer", "role": "caster", "color": Color(0.4, 0.85, 0.65),
			"description": "Invoca esqueletos, drena vida e espalha pragas. Seus mortos lutam por você.",
			"weapon_types": ["scythe", "staff"] as Array[String], "can_use_shield": false,
			"base_hp": 95.0, "base_mp": 95.0, "hp_per_level": 9.0, "mp_per_level": 10.0, "move_speed": 5.2,
			"basic_attack_power": 0.95, "basic_attack_cooldown": 0.7, "basic_attack_range": 7.5, "basic_attack_is_ranged": true, "basic_attack_kind": 1,
			"starting_equipment": ["scythe_bone", "robe_cloth"] as Array[String],
			"skill_ids": ["nec_drain", "nec_raise", "nec_plague", "nec_bone_wall", "nec_curse", "nec_harvest"] as Array[String]}),
	]
