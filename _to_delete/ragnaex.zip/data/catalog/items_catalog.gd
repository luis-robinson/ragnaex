class_name ItemsCatalog
extends RefCounted
## Materiais, consumíveis e equipamentos. Equipamento = pontos de atributo.
## rarity 0..3 também é o "tier" (lv 1 / 8 / 16 / 24).

const MAT := ItemDef.Type.MATERIAL
const CON := ItemDef.Type.CONSUMABLE
const EQ := ItemDef.Type.EQUIPMENT
const QST := ItemDef.Type.QUEST
const S_W := ItemDef.Slot.WEAPON; const S_O := ItemDef.Slot.OFFHAND; const S_H := ItemDef.Slot.HEAD
const S_B := ItemDef.Slot.BODY; const S_F := ItemDef.Slot.BOOTS; const S_A := ItemDef.Slot.ACCESSORY

static func _mk(d: Dictionary) -> ItemDef:
	var it := ItemDef.new()
	for k in d:
		it.set(k, d[k])
	return it

static func _mat(id: String, name: String, price: int, desc: String, color: Color) -> Dictionary:
	return {"id": id, "name": name, "type": MAT, "price": price, "description": desc, "icon_color": color}

static func _weapon(id: String, name: String, wtype: String, tier: int, atk: float, matk: float, attrs: Dictionary, color: Color, classes: Array = []) -> Dictionary:
	var cr: Array[String] = []
	for c in classes:
		cr.append(c)
	return {"id": id, "name": name, "type": EQ, "slot": S_O if wtype == "shield" else S_W, "weapon_type": wtype, "rarity": tier, "level_req": [1, 8, 16, 24][tier],
		"atk": atk, "matk": matk, "attributes": attrs, "icon_color": color, "price": [40, 220, 700, 1800][tier], "stack_max": 1, "class_restriction": cr}

static func _armor(id: String, name: String, slot: int, tier: int, def: float, mdef: float, attrs: Dictionary, color: Color) -> Dictionary:
	return {"id": id, "name": name, "type": EQ, "slot": slot, "rarity": tier, "level_req": [1, 8, 16, 24][tier],
		"def": def, "mdef": mdef, "attributes": attrs, "icon_color": color, "price": [30, 180, 600, 1500][tier], "stack_max": 1}

static func build() -> Array:
	var L := [
		# ---------------- consumíveis ----------------
		{"id": "potion_hp_s", "name": "Poção de Vida (P)", "type": CON, "price": 15, "icon_color": Color(1, 0.35, 0.35), "description": "Recupera 60 HP.", "consume": {"heal": 60}, "consume_cooldown": 4.0},
		{"id": "potion_hp_m", "name": "Poção de Vida (M)", "type": CON, "price": 45, "icon_color": Color(1, 0.2, 0.2), "description": "Recupera 35% do HP.", "consume": {"heal_pct": 0.35}, "consume_cooldown": 4.0, "level_req": 8},
		{"id": "potion_mp_s", "name": "Poção de Mana (P)", "type": CON, "price": 18, "icon_color": Color(0.35, 0.5, 1), "description": "Recupera 40 MP.", "consume": {"mana": 40}, "consume_cooldown": 4.0},
		{"id": "potion_mp_m", "name": "Poção de Mana (M)", "type": CON, "price": 50, "icon_color": Color(0.2, 0.35, 1), "description": "Recupera 35% do MP.", "consume": {"mana_pct": 0.35}, "consume_cooldown": 4.0, "level_req": 8},
		{"id": "elixir_might", "name": "Elixir da Força", "type": CON, "price": 90, "icon_color": Color(1, 0.7, 0.2), "description": "+20% ATK/MATK por 45s.", "consume": {"buff": {"id": "elixir", "duration": 45, "atk_pct": 20, "matk_pct": 20}}, "consume_cooldown": 6.0},
		{"id": "elixir_stone", "name": "Elixir de Pedra", "type": CON, "price": 90, "icon_color": Color(0.6, 0.6, 0.7), "description": "+25% DEF por 45s.", "consume": {"buff": {"id": "stoneskin", "duration": 45, "def_pct": 25}}, "consume_cooldown": 6.0},
		# ---------------- materiais ----------------
		_mat("slime_gel", "Gel de Slime", 4, "Pegajoso. Alquimistas adoram.", Color(0.4, 0.9, 0.5)),
		_mat("wolf_pelt", "Pele de Lobo", 9, "Couro resistente.", Color(0.55, 0.45, 0.35)),
		_mat("boar_tusk", "Presa de Javali", 10, "Afiada. Boa para adornos.", Color(0.95, 0.9, 0.8)),
		_mat("herb_green", "Erva Verde", 5, "Base de poções de vida.", Color(0.3, 0.8, 0.3)),
		_mat("herb_blue", "Erva Azul", 6, "Base de poções de mana.", Color(0.3, 0.5, 0.95)),
		_mat("iron_ore", "Minério de Ferro", 8, "Derretido vira lâminas.", Color(0.5, 0.5, 0.55)),
		_mat("spider_silk", "Seda de Aranha", 12, "Fina e forte.", Color(0.9, 0.9, 0.95)),
		_mat("ent_bark", "Casca de Ent", 15, "Madeira viva.", Color(0.45, 0.3, 0.2)),
		_mat("bandit_badge", "Insígnia de Bandido", 14, "Prova de serviço prestado.", Color(0.7, 0.2, 0.2)),
		_mat("bone_shard", "Fragmento de Osso", 16, "Ainda sussurra.", Color(0.9, 0.9, 0.8)),
		_mat("ghost_essence", "Essência Espectral", 25, "Fria ao toque.", Color(0.6, 0.9, 1.0)),
		_mat("golem_core", "Núcleo de Golem", 60, "Pulsa com magia antiga.", Color(0.9, 0.6, 0.2)),
		_mat("dragon_scale", "Escama de Dragonete", 80, "Rara. Quase indestrutível.", Color(0.8, 0.2, 0.3)),
		{"id": "letter_sealed", "name": "Carta Lacrada", "type": QST, "price": 0, "icon_color": Color(0.9, 0.85, 0.6), "description": "Carta do Ancião para a Capitã da guarda."},
		# ---------------- armas tier 0 (lv1) ----------------
		_weapon("sword_rusty", "Espada Enferrujada", "sword", 0, 8, 0, {"FOR": 3, "VIT": 1}, Color(0.6, 0.6, 0.6)),
		_weapon("axe_old", "Machado Velho", "axe2h", 0, 12, 0, {"FOR": 4}, Color(0.55, 0.45, 0.4)),
		_weapon("staff_novice", "Cajado de Noviço", "staff", 0, 2, 9, {"WILL": 3, "INT": 1}, Color(0.8, 0.7, 0.5)),
		_weapon("staff_oak", "Cajado de Carvalho", "staff", 0, 2, 8, {"INT": 2, "WILL": 2}, Color(0.5, 0.4, 0.25)),
		_weapon("bow_short", "Arco Curto", "bow", 0, 7, 0, {"AGI": 4}, Color(0.6, 0.45, 0.3)),
		_weapon("dagger_iron", "Adaga de Ferro", "dagger", 0, 6, 0, {"AGI": 3, "FOR": 1}, Color(0.7, 0.7, 0.75)),
		_weapon("wand_apprentice", "Varinha de Aprendiz", "wand", 0, 1, 10, {"INT": 4}, Color(0.6, 0.5, 0.9)),
		_weapon("scythe_bone", "Foice de Osso", "scythe", 0, 4, 8, {"INT": 3, "WILL": 1}, Color(0.85, 0.85, 0.75)),
		_weapon("shield_wood", "Escudo de Madeira", "shield", 0, 0, 0, {"FOR": 1, "VIT": 2}, Color(0.5, 0.35, 0.2)),
		# ---------------- armas tier 1 (lv8) — craft no ferreiro ----------------
		_weapon("sword_iron", "Espada de Ferro", "sword", 1, 16, 0, {"FOR": 6, "VIT": 2}, Color(0.75, 0.75, 0.8)),
		_weapon("axe_iron", "Machado de Ferro", "axe2h", 1, 24, 0, {"FOR": 8, "VIT": 1}, Color(0.7, 0.65, 0.6)),
		_weapon("staff_silk", "Cajado de Seda", "staff", 1, 3, 18, {"WILL": 5, "INT": 4}, Color(0.9, 0.85, 0.95)),
		_weapon("bow_hunter", "Arco do Caçador", "bow", 1, 15, 0, {"AGI": 8, "FOR": 1}, Color(0.4, 0.55, 0.3)),
		_weapon("dagger_fang", "Adaga Presa", "dagger", 1, 12, 0, {"AGI": 7, "FOR": 2}, Color(0.9, 0.85, 0.7)),
		_weapon("wand_silk", "Varinha de Seda", "wand", 1, 2, 20, {"INT": 8, "WILL": 1}, Color(0.7, 0.5, 1)),
		_weapon("scythe_iron", "Foice de Ferro", "scythe", 1, 8, 17, {"INT": 6, "WILL": 3}, Color(0.6, 0.6, 0.65)),
		_weapon("shield_iron", "Escudo de Ferro", "shield", 1, 0, 0, {"FOR": 3, "VIT": 5}, Color(0.6, 0.6, 0.65)),
		# ---------------- armas tier 2 (lv16) ----------------
		_weapon("sword_ent", "Espada de Ent", "sword", 2, 28, 0, {"FOR": 10, "VIT": 5, "AGI": 2}, Color(0.4, 0.6, 0.3)),
		_weapon("axe_bone", "Machado de Osso", "axe2h", 2, 40, 0, {"FOR": 14, "AGI": 2}, Color(0.9, 0.9, 0.8)),
		_weapon("staff_spectral", "Cajado Espectral", "staff", 2, 5, 32, {"WILL": 9, "INT": 8}, Color(0.6, 0.9, 1)),
		_weapon("bow_ent", "Arco de Ent", "bow", 2, 26, 0, {"AGI": 14, "VIT": 2}, Color(0.35, 0.5, 0.25)),
		_weapon("dagger_spectral", "Adaga Espectral", "dagger", 2, 21, 0, {"AGI": 12, "INT": 3, "FOR": 2}, Color(0.7, 0.95, 1)),
		_weapon("wand_spectral", "Varinha Espectral", "wand", 2, 3, 36, {"INT": 15, "WILL": 2}, Color(0.6, 0.8, 1)),
		_weapon("scythe_spectral", "Foice Espectral", "scythe", 2, 12, 30, {"INT": 11, "WILL": 6}, Color(0.5, 0.9, 0.9)),
		_weapon("shield_bone", "Escudo de Osso", "shield", 2, 0, 0, {"FOR": 6, "VIT": 9}, Color(0.9, 0.9, 0.85)),
		# ---------------- armas tier 3 (lv24) — boss ----------------
		_weapon("sword_dragon", "Espada Dracônica", "sword", 3, 44, 0, {"FOR": 16, "VIT": 8, "AGI": 4}, Color(0.9, 0.3, 0.3)),
		_weapon("axe_golem", "Machado do Golem", "axe2h", 3, 62, 0, {"FOR": 22, "VIT": 4}, Color(0.9, 0.6, 0.2)),
		_weapon("staff_dragon", "Cajado Dracônico", "staff", 3, 8, 50, {"WILL": 14, "INT": 13}, Color(0.9, 0.4, 0.4)),
		_weapon("bow_dragon", "Arco Dracônico", "bow", 3, 42, 0, {"AGI": 22, "FOR": 3}, Color(0.8, 0.3, 0.3)),
		_weapon("dagger_golem", "Adaga do Golem", "dagger", 3, 34, 0, {"AGI": 19, "FOR": 4, "INT": 3}, Color(0.9, 0.65, 0.3)),
		_weapon("wand_dragon", "Varinha Dracônica", "wand", 3, 5, 56, {"INT": 23, "WILL": 3}, Color(1, 0.4, 0.5)),
		_weapon("scythe_golem", "Foice do Golem", "scythe", 3, 18, 46, {"INT": 17, "WILL": 9}, Color(0.95, 0.6, 0.25)),
		_weapon("shield_dragon", "Escudo Dracônico", "shield", 3, 0, 0, {"FOR": 10, "VIT": 14}, Color(0.85, 0.3, 0.3)),
		# ---------------- armaduras ----------------
		_armor("armor_leather", "Armadura de Couro", S_B, 0, 4, 2, {"VIT": 2, "AGI": 1}, Color(0.55, 0.4, 0.25)),
		_armor("robe_cloth", "Túnica de Pano", S_B, 0, 2, 4, {"WILL": 2, "INT": 1}, Color(0.6, 0.6, 0.85)),
		_armor("armor_wolf", "Armadura de Lobo", S_B, 1, 10, 4, {"VIT": 5, "FOR": 2}, Color(0.5, 0.4, 0.3)),
		_armor("robe_silk", "Túnica de Seda", S_B, 1, 5, 10, {"WILL": 4, "INT": 3}, Color(0.85, 0.8, 0.95)),
		_armor("armor_ent", "Armadura de Ent", S_B, 2, 18, 8, {"VIT": 9, "FOR": 3, "AGI": 2}, Color(0.4, 0.55, 0.3)),
		_armor("robe_spectral", "Túnica Espectral", S_B, 2, 8, 18, {"WILL": 8, "INT": 6}, Color(0.6, 0.85, 1)),
		_armor("armor_dragon", "Armadura Dracônica", S_B, 3, 28, 12, {"VIT": 14, "FOR": 5, "AGI": 3}, Color(0.85, 0.3, 0.3)),
		_armor("robe_dragon", "Túnica Dracônica", S_B, 3, 12, 28, {"WILL": 12, "INT": 10}, Color(1, 0.5, 0.5)),
		_armor("cap_leather", "Gorro de Couro", S_H, 0, 2, 1, {"VIT": 1}, Color(0.55, 0.4, 0.25)),
		_armor("helm_iron", "Elmo de Ferro", S_H, 1, 6, 2, {"VIT": 3, "FOR": 1}, Color(0.65, 0.65, 0.7)),
		_armor("hood_silk", "Capuz de Seda", S_H, 1, 2, 6, {"INT": 2, "WILL": 2}, Color(0.85, 0.8, 0.95)),
		_armor("helm_bone", "Elmo de Osso", S_H, 2, 10, 5, {"VIT": 5, "FOR": 3}, Color(0.9, 0.9, 0.8)),
		_armor("crown_spectral", "Coroa Espectral", S_H, 2, 4, 11, {"INT": 5, "WILL": 4}, Color(0.6, 0.9, 1)),
		_armor("boots_leather", "Botas de Couro", S_F, 0, 1, 1, {"AGI": 1}, Color(0.5, 0.35, 0.2)),
		_armor("boots_wolf", "Botas de Lobo", S_F, 1, 4, 2, {"AGI": 3, "VIT": 1}, Color(0.5, 0.4, 0.3)),
		_armor("boots_ent", "Botas de Ent", S_F, 2, 8, 4, {"AGI": 5, "VIT": 3}, Color(0.4, 0.55, 0.3)),
		_armor("ring_gel", "Anel de Gel", S_A, 0, 0, 0, {"WILL": 2}, Color(0.4, 0.9, 0.5)),
		_armor("amulet_tusk", "Amuleto de Presa", S_A, 1, 0, 0, {"FOR": 3, "AGI": 2}, Color(0.95, 0.9, 0.8)),
		_armor("amulet_silk", "Amuleto de Seda", S_A, 1, 0, 0, {"INT": 3, "WILL": 2}, Color(0.9, 0.9, 0.95)),
		_armor("ring_spectral", "Anel Espectral", S_A, 2, 0, 0, {"INT": 4, "AGI": 4}, Color(0.6, 0.9, 1)),
		_armor("amulet_golem", "Amuleto do Golem", S_A, 3, 0, 0, {"FOR": 6, "VIT": 6, "WILL": 4}, Color(0.9, 0.6, 0.2)),
	]
	var out: Array = []
	for d in L:
		out.append(_mk(d))
	return out
