class_name MapsCatalog
extends RefCounted
## Cidade de Aldara + Campina (1-10) + Floresta (10-20) + Ruínas (20-30).
## Paleta inspirada em Tree of Savior: pastel quente, pedra creme, verdes suaves.

const C_STONE := Color(0.86, 0.80, 0.68)
const C_ROOF := Color(0.80, 0.42, 0.34)
const C_ROOF2 := Color(0.45, 0.55, 0.72)
const C_WOOD := Color(0.55, 0.40, 0.27)
const C_TREE := Color(0.40, 0.66, 0.38)
const C_TREE_DARK := Color(0.30, 0.52, 0.34)
const C_ROCK := Color(0.62, 0.60, 0.58)
const C_RUIN := Color(0.70, 0.68, 0.62)

static func _mk(d: Dictionary) -> MapDef:
	var m := MapDef.new()
	for k in d:
		m.set(k, d[k])
	return m

static func _ob(kind: String, x: float, z: float, sx: float, sy: float, sz: float, color: Color, rot: float = 0.0, solid: bool = true) -> Dictionary:
	return {"kind": kind, "pos": Vector3(x, 0, z), "size": Vector3(sx, sy, sz), "rot": rot, "color": color, "solid": solid}

static func _house(x: float, z: float, w: float, d: float, rot: float = 0.0, roof: Color = C_ROOF) -> Dictionary:
	var o := _ob("house", x, z, w, 3.2, d, C_STONE, rot)
	o["roof"] = roof
	return o

static func _tree(x: float, z: float, s: float = 1.0, dark: bool = false) -> Dictionary:
	return _ob("tree", x, z, 1.6 * s, 3.5 * s, 1.6 * s, C_TREE_DARK if dark else C_TREE)

static func _rock(x: float, z: float, s: float = 1.0) -> Dictionary:
	return _ob("rock", x, z, 1.4 * s, 0.9 * s, 1.2 * s, C_ROCK)

static func _npc(id: String, name: String, x: float, z: float, role: String, color: Color, dialog: Array, facing: float = 180.0, shop: Array = []) -> Dictionary:
	return {"id": id, "name": name, "pos": Vector3(x, 0, z), "role": role, "color": color, "dialog": dialog, "facing": facing, "shop": shop}

static func _portal(id: String, x: float, z: float, target: String, tx: float, tz: float, label: String) -> Dictionary:
	return {"id": id, "pos": Vector3(x, 0, z), "radius": 1.8, "target_map": target, "target_pos": Vector3(tx, 0, tz), "label": label}

static func _sp(monster: String, x: float, z: float, radius: float, count: int, respawn: float = 14.0) -> Dictionary:
	return {"monster_id": monster, "pos": Vector3(x, 0, z), "radius": radius, "count": count, "respawn": respawn}

static func build() -> Array:
	return [_aldara(), _meadows(), _forest(), _ruins()]

# ---------------------------------------------------------------------------
static func _aldara() -> MapDef:
	var obs: Array = []
	# praça central com fonte
	obs.append(_ob("fountain", 0, 0, 3.4, 1.2, 3.4, C_STONE))
	# casas ao redor da praça (anel)
	obs.append(_house(-14, -14, 7, 6, 0, C_ROOF))
	obs.append(_house(14, -14, 7, 6, 0, C_ROOF2))
	obs.append(_house(-22, 2, 6, 8, 90, C_ROOF2))
	obs.append(_house(22, 2, 6, 8, 90, C_ROOF))
	obs.append(_house(-13, 16, 7, 6, 0, C_ROOF2))
	obs.append(_house(13, 16, 7, 6, 0, C_ROOF))
	obs.append(_house(0, -22, 9, 7, 0, Color(0.55, 0.45, 0.65)))  # salão do ancião
	obs.append(_house(-26, -22, 6, 6, 0, C_ROOF))
	obs.append(_house(26, -22, 6, 6, 0, C_ROOF2))
	obs.append(_house(-26, 24, 6, 6, 0, C_ROOF2))
	obs.append(_house(26, 24, 6, 6, 0, C_ROOF))
	# forja e caldeirão (estações)
	obs.append(_ob("stall", -17, 5, 2.4, 1.6, 1.4, C_WOOD))
	obs.append(_ob("stall", 17, 5, 2.4, 1.6, 1.4, C_WOOD))
	obs.append(_ob("crate", -19, 8, 1.0, 1.0, 1.0, C_WOOD))
	obs.append(_ob("crate", 19, 8, 1.0, 1.0, 1.0, C_WOOD))
	# poço, estátua e lampiões
	obs.append(_ob("well", -8, 10, 1.6, 1.4, 1.6, C_STONE))
	obs.append(_ob("statue", 8, -8, 1.2, 2.6, 1.2, C_STONE))
	for p in [Vector3(-6, 0, -6), Vector3(6, 0, 6), Vector3(-6, 0, 6), Vector3(6, 0, -6)]:
		obs.append(_ob("lamp", p.x, p.z, 0.4, 3.0, 0.4, C_WOOD))
	# árvores decorativas e muralha
	for t in [[-30, -10], [-30, 12], [30, -10], [30, 12], [-10, -30], [10, -30], [-10, 30], [10, 30], [-20, -30], [20, 30]]:
		obs.append(_tree(t[0], t[1], 1.1))
	for i in range(-34, 35, 4):
		if absf(i) > 4:
			obs.append(_ob("wall", i, -36, 4, 2.5, 1.2, C_STONE))
			obs.append(_ob("wall", i, 36, 4, 2.5, 1.2, C_STONE))
			obs.append(_ob("wall", -36, i, 1.2, 2.5, 4, C_STONE))
			obs.append(_ob("wall", 36, i, 1.2, 2.5, 4, C_STONE))
	# bancos (não sólidos pra não travar bots)
	obs.append(_ob("bench", -3, 4, 1.6, 0.5, 0.5, C_WOOD, 0, false))
	obs.append(_ob("bench", 3, -4, 1.6, 0.5, 0.5, C_WOOD, 0, false))
	var decor: Array = []
	for i in range(-30, 31, 3):
		decor.append({"kind": "path", "pos": Vector3(0, 0, i), "size": Vector3(4, 0.02, 3), "color": Color(0.70, 0.62, 0.50)})
		decor.append({"kind": "path", "pos": Vector3(i, 0, 0), "size": Vector3(3, 0.02, 4), "color": Color(0.70, 0.62, 0.50)})
	return _mk({
		"id": "city_aldara", "name": "Aldara", "is_town": true, "level_range": Vector2i(1, 30), "size": Vector2(74, 74),
		"ground_color": Color(0.50, 0.64, 0.40), "ground_color_alt": Color(0.46, 0.60, 0.37), "ambient": Color(0.95, 0.92, 0.88), "sun_energy": 1.25,
		"spawn_point": Vector3(0, 0, 8), "obstacles": obs, "decor": decor, "bot_population": 14,
		"npcs": [
			_npc("elder", "Ancião Ravi", 0, -17, "quest", Color(0.75, 0.65, 0.9), ["Aldara resiste há 300 anos. Com gente como você, resiste mais 300.", "Fale com a Capitã Mira se procura trabalho."], 180),
			_npc("captain", "Capitã Mira", 3, 24, "quest", Color(0.85, 0.7, 0.4), ["A guarda está sem braços. Monstros na Campina, bandidos na Floresta...", "WASD para mover, botão esquerdo ataca, direito bloqueia. 1-6 são skills."], 0),
			_npc("smith", "Brom, o Ferreiro", -17, 3, "smith", Color(0.8, 0.5, 0.3), ["Minério de ferro vira lâmina. Presa de javali vira cabo. Traga material e eu forjo.", "Equipamento é o que dá seus atributos. Não ande com espada enferrujada."], 90),
			_npc("alchemist", "Lyra, a Alquimista", 17, 3, "alchemy", Color(0.5, 0.8, 0.6), ["Gel de slime, erva verde... poção de vida. Simples assim.", "Poções vão em F1, F2 e F3. Configure na bolsa (tecla I)."], 270),
			_npc("merchant", "Mercador Tobias", 0, 12, "merchant", Color(0.9, 0.8, 0.5), ["Poções, elixires e um bom preço pelo que você trouxe das caçadas."], 180, ["potion_hp_s", "potion_mp_s", "potion_hp_m", "potion_mp_m", "elixir_might", "elixir_stone", "cap_leather", "boots_leather"]),
			_npc("board", "Quadro de Avisos", 8, -12, "board", Color(0.6, 0.45, 0.3), ["Procura-se: aventureiros para a Campina (1-10), Floresta (10-20) e Ruínas (20-30).", "Dica: maestria sobe gastando pontos (tecla K) ou usando a skill 30 vezes."], 180),
			_npc("guard_s", "Guarda", -3, 30, "guard", Color(0.6, 0.6, 0.75), ["O portal sul leva à Campina. Monstros fracos, bons para começar."], 0),
			_npc("guard_e", "Guarda", 30, -3, "guard", Color(0.6, 0.6, 0.75), ["Portal leste: Floresta. Só vá depois do nível 10."], 270),
			_npc("guard_w", "Guarda", -30, 3, "guard", Color(0.6, 0.6, 0.75), ["Portal oeste: Ruínas. Nível 20 ou você volta em pedaços."], 90),
		],
		"portals": [
			_portal("to_meadows", 0, 33, "field_meadows", 0, -44, "Campina (Lv 1-10)"),
			_portal("to_forest", 33, 0, "field_forest", -48, 0, "Floresta (Lv 10-20)"),
			_portal("to_ruins", -33, 0, "field_ruins", 48, 0, "Ruínas (Lv 20-30)"),
		],
		"bot_hangouts": [Vector3(0, 0, 4), Vector3(-4, 0, -3), Vector3(4, 0, 3), Vector3(-14, 0, 4), Vector3(14, 0, 4), Vector3(0, 0, 14), Vector3(6, 0, -10), Vector3(-8, 0, 12), Vector3(2, 0, 20)],
	})

# ---------------------------------------------------------------------------
static func _meadows() -> MapDef:
	var obs: Array = []
	var rng := RandomNumberGenerator.new()
	rng.seed = 11
	for i in range(34):
		var x := rng.randf_range(-46, 46)
		var z := rng.randf_range(-40, 46)
		if absf(x) < 5 and z < -30:
			continue
		obs.append(_tree(x, z, rng.randf_range(0.8, 1.3), rng.randf() < 0.3))
	for i in range(14):
		obs.append(_rock(rng.randf_range(-46, 46), rng.randf_range(-40, 46), rng.randf_range(0.7, 1.4)))
	# clareira do rei javali (sul) cercada de pedras
	for a in range(0, 360, 40):
		var r := 11.0
		obs.append(_rock(cos(deg_to_rad(a)) * r, 34 + sin(deg_to_rad(a)) * r, 1.3))
	# cercas da fazenda abandonada (oeste)
	for i in range(-6, 7, 2):
		obs.append(_ob("fence", -30 + i, -10, 2, 1.0, 0.3, C_WOOD))
		obs.append(_ob("fence", -30 + i, 2, 2, 1.0, 0.3, C_WOOD))
	var decor: Array = []
	for i in range(60):
		decor.append({"kind": "grass", "pos": Vector3(rng.randf_range(-48, 48), 0, rng.randf_range(-48, 48)), "size": Vector3(0.6, 0.4, 0.6), "color": Color(0.5, 0.8, 0.45)})
	for i in range(30):
		decor.append({"kind": "flower", "pos": Vector3(rng.randf_range(-48, 48), 0, rng.randf_range(-48, 48)), "size": Vector3(0.3, 0.3, 0.3), "color": [Color(1, 0.8, 0.3), Color(1, 0.5, 0.6), Color(0.8, 0.7, 1)][i % 3]})
	return _mk({
		"id": "field_meadows", "name": "Campina de Aldara", "is_town": false, "level_range": Vector2i(1, 10), "size": Vector2(100, 100),
		"ground_color": Color(0.48, 0.68, 0.38), "ground_color_alt": Color(0.44, 0.64, 0.35), "ambient": Color(0.98, 0.95, 0.85), "sun_energy": 1.3,
		"spawn_point": Vector3(0, 0, -44), "obstacles": obs, "decor": decor, "bot_population": 6,
		"npcs": [_npc("meadow_guard", "Guarda da Estrada", 3, -44, "guard", Color(0.6, 0.6, 0.75), ["Slimes perto da entrada, javalis a leste, lobos ao norte. O Rei Javali fica na clareira ao sul."], 0)],
		"portals": [_portal("to_town", 0, -49, "city_aldara", 0, 29, "Aldara")],
		"spawners": [
			_sp("slime", -14, -28, 9, 6, 10.0), _sp("slime", 14, -26, 9, 6, 10.0), _sp("slime", 0, -12, 8, 5, 10.0),
			_sp("slime_blue", -30, -20, 8, 4, 14.0), _sp("slime_blue", 28, -8, 8, 4, 14.0),
			_sp("boar", 30, 10, 10, 5, 16.0), _sp("boar", 20, 24, 8, 4, 16.0),
			_sp("wolf", -28, 16, 10, 5, 18.0), _sp("wolf", -10, 28, 9, 4, 18.0),
			_sp("boar_king", 0, 34, 2, 1, 120.0),
		],
		"bot_hangouts": [],
	})

# ---------------------------------------------------------------------------
static func _forest() -> MapDef:
	var obs: Array = []
	var rng := RandomNumberGenerator.new()
	rng.seed = 23
	for i in range(140):
		var x := rng.randf_range(-52, 52)
		var z := rng.randf_range(-52, 52)
		if (absf(z) < 6 and x < -30) or (x > 10 and z < -28 and x < 40):  # entrada e acampamento livres
			continue
		if Vector2(x, z).distance_to(Vector2(25, -38)) < 10:
			continue
		obs.append(_tree(x, z, rng.randf_range(1.0, 1.8), rng.randf() < 0.5))
	for i in range(12):
		obs.append(_rock(rng.randf_range(-50, 50), rng.randf_range(-50, 50), rng.randf_range(0.8, 1.6)))
	# acampamento dos bandidos (norte-leste): tendas e paliçada
	for t in [[18, -34], [32, -34], [25, -46], [34, -42]]:
		obs.append(_ob("tent", t[0], t[1], 3.2, 2.2, 3.2, Color(0.55, 0.3, 0.25)))
	for i in range(10, 42, 3):
		obs.append(_ob("fence", i, -24, 3, 1.4, 0.4, C_WOOD))
	obs.append(_ob("crate", 22, -40, 1, 1, 1, C_WOOD))
	obs.append(_ob("crate", 29, -39, 1, 1, 1, C_WOOD))
	# posto do ranger (entrada)
	obs.append(_house(-40, -8, 5, 4, 0, C_WOOD))
	var decor: Array = []
	for i in range(80):
		decor.append({"kind": "grass", "pos": Vector3(rng.randf_range(-52, 52), 0, rng.randf_range(-52, 52)), "size": Vector3(0.7, 0.5, 0.7), "color": Color(0.35, 0.6, 0.35)})
	return _mk({
		"id": "field_forest", "name": "Floresta Sombria", "is_town": false, "level_range": Vector2i(10, 20), "size": Vector2(110, 110),
		"ground_color": Color(0.36, 0.52, 0.34), "ground_color_alt": Color(0.32, 0.48, 0.31), "ambient": Color(0.75, 0.85, 0.8), "sun_energy": 0.95,
		"spawn_point": Vector3(-48, 0, 0), "obstacles": obs, "decor": decor, "bot_population": 5,
		"npcs": [_npc("ranger_post", "Ranger Teo", -40, -4, "quest", Color(0.5, 0.75, 0.55), ["Aranhas por toda parte. Bandidos no acampamento ao norte-leste. Ents no fundo.", "Não lute com o Chefe sozinho abaixo do nível 17."], 90)],
		"portals": [_portal("to_town", -53, 0, "city_aldara", 29, 0, "Aldara")],
		"spawners": [
			_sp("spider", -20, -20, 10, 6, 14.0), _sp("spider", -15, 18, 10, 6, 14.0), _sp("spider", 10, 5, 10, 5, 14.0),
			_sp("bandit", 22, -32, 9, 5, 18.0), _sp("bandit", 34, -40, 7, 3, 18.0),
			_sp("bandit_archer", 28, -36, 8, 3, 20.0),
			_sp("ent", 30, 30, 10, 4, 24.0), _sp("ent", 5, 38, 9, 3, 24.0),
			_sp("bandit_chief", 38, -46, 2, 1, 180.0),
		],
		"bot_hangouts": [],
	})

# ---------------------------------------------------------------------------
static func _ruins() -> MapDef:
	var obs: Array = []
	var rng := RandomNumberGenerator.new()
	rng.seed = 37
	# colunas em grade quebrada
	for gx in range(-40, 41, 10):
		for gz in range(-40, 41, 10):
			if rng.randf() < 0.55 and not (absf(gz) < 6 and gx > 30):
				obs.append(_ob("pillar", gx + rng.randf_range(-2, 2), gz + rng.randf_range(-2, 2), 1.4, rng.randf_range(2.0, 5.0), 1.4, C_RUIN))
	# paredes em ruína
	for i in range(18):
		obs.append(_ob("ruin", rng.randf_range(-45, 45), rng.randf_range(-45, 45), rng.randf_range(3, 7), rng.randf_range(1.0, 2.5), 1.0, C_RUIN, rng.randf_range(0, 180)))
	for i in range(16):
		obs.append(_rock(rng.randf_range(-48, 48), rng.randf_range(-48, 48), rng.randf_range(0.8, 1.5)))
	# altar do dragonete (oeste) com anel de pilares
	for a in range(0, 360, 45):
		obs.append(_ob("pillar", -38 + cos(deg_to_rad(a)) * 12, sin(deg_to_rad(a)) * 12, 1.6, 6.0, 1.6, Color(0.6, 0.55, 0.6)))
	obs.append(_ob("statue", -38, 0, 2.0, 1.0, 2.0, Color(0.5, 0.45, 0.5), 0, false))
	var decor: Array = []
	for i in range(50):
		decor.append({"kind": "grass", "pos": Vector3(rng.randf_range(-50, 50), 0, rng.randf_range(-50, 50)), "size": Vector3(0.6, 0.35, 0.6), "color": Color(0.5, 0.55, 0.45)})
	return _mk({
		"id": "field_ruins", "name": "Ruínas de Vel'Thar", "is_town": false, "level_range": Vector2i(20, 30), "size": Vector2(110, 110),
		"ground_color": Color(0.55, 0.52, 0.47), "ground_color_alt": Color(0.50, 0.48, 0.44), "ambient": Color(0.7, 0.72, 0.85), "sun_energy": 0.8,
		"spawn_point": Vector3(48, 0, 0), "obstacles": obs, "decor": decor, "bot_population": 4,
		"npcs": [_npc("ruins_scholar", "Erudita Senna", 44, -4, "guard", Color(0.8, 0.75, 0.9), ["Vel'Thar caiu há mil anos. Esqueletos na entrada, espectros no meio, golens no fundo.", "O altar a oeste... não acorde o que dorme lá sem estar pronto."], 90)],
		"portals": [_portal("to_town", 53, 0, "city_aldara", -29, 0, "Aldara")],
		"spawners": [
			_sp("skeleton", 28, -20, 10, 6, 16.0), _sp("skeleton", 26, 22, 10, 6, 16.0), _sp("skeleton", 5, -5, 9, 5, 16.0),
			_sp("ghost", -5, -30, 10, 4, 20.0), _sp("ghost", -8, 30, 10, 4, 20.0),
			_sp("golem", -20, -15, 9, 3, 30.0), _sp("golem", -22, 18, 9, 3, 30.0),
			_sp("dragonling", -38, 0, 2, 1, 300.0),
		],
		"bot_hangouts": [],
	})
