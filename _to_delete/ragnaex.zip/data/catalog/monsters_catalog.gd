class_name MonstersCatalog
extends RefCounted
## Monstros por área: Campina (1-10), Floresta (10-20), Ruínas (20-30) + mini-bosses + invocação.

static func _mk(d: Dictionary) -> MonsterDef:
	var m := MonsterDef.new()
	for k in d:
		m.set(k, d[k])
	return m

static func _lt(id: String, entries: Array) -> LootTable:
	var l := LootTable.new()
	l.id = id
	l.entries = entries
	return l

static func build() -> Array:
	var L := [
		# ---- Campina (lv 1-10) ----
		{"id": "slime", "name": "Slime", "level": 1, "hp": 38, "atk": 7, "def": 1, "mdef": 1, "move_speed": 2.8, "attack_range": 1.4, "attack_cooldown": 1.6, "xp": 10,
		 "radius": 0.45, "scale": 0.8, "color": Color(0.45, 0.9, 0.5), "shape": "sphere", "loot_table": "lt_slime", "gold_min": 1, "gold_max": 4, "model": "mob_slime"},
		{"id": "slime_blue", "name": "Slime Azul", "level": 3, "hp": 60, "atk": 10, "matk": 12, "def": 2, "mdef": 4, "move_speed": 3.0, "attack_range": 5.0, "attack_cooldown": 1.9, "xp": 16, "ranged": true,
		 "radius": 0.45, "scale": 0.85, "color": Color(0.4, 0.6, 1.0), "shape": "sphere", "loot_table": "lt_slime_blue", "gold_min": 2, "gold_max": 6, "model": "mob_slime"},
		{"id": "boar", "name": "Javali", "level": 5, "hp": 95, "atk": 15, "def": 4, "mdef": 2, "move_speed": 4.2, "attack_range": 1.6, "attack_cooldown": 1.3, "attack_startup": 0.3, "xp": 24, "aggro_range": 6.0,
		 "radius": 0.55, "scale": 1.0, "color": Color(0.5, 0.35, 0.25), "shape": "box", "loot_table": "lt_boar", "gold_min": 3, "gold_max": 8, "model": "mob_boar"},
		{"id": "wolf", "name": "Lobo", "level": 7, "hp": 110, "atk": 19, "def": 5, "mdef": 3, "move_speed": 5.0, "attack_range": 1.7, "attack_cooldown": 1.1, "attack_startup": 0.25, "xp": 32, "aggro_range": 9.0,
		 "radius": 0.5, "scale": 1.0, "color": Color(0.5, 0.5, 0.55), "shape": "box", "loot_table": "lt_wolf", "gold_min": 4, "gold_max": 10, "model": "mob_wolf"},
		{"id": "boar_king", "name": "Rei Javali", "level": 10, "hp": 520, "atk": 26, "def": 8, "mdef": 5, "move_speed": 4.0, "attack_range": 2.2, "attack_cooldown": 1.5, "attack_startup": 0.45, "xp": 180, "aggro_range": 8.0, "leash_range": 25.0,
		 "radius": 0.9, "scale": 1.8, "color": Color(0.6, 0.3, 0.2), "shape": "box", "is_boss": true, "loot_table": "lt_boar_king", "gold_min": 30, "gold_max": 60, "skill_ids": ["mob_charge"] as Array[String], "model": "mob_boar"},
		# ---- Floresta (lv 10-20) ----
		{"id": "spider", "name": "Aranha Gigante", "level": 11, "hp": 180, "atk": 26, "def": 7, "mdef": 6, "move_speed": 4.6, "attack_range": 1.7, "attack_cooldown": 1.2, "xp": 48, "aggro_range": 8.0,
		 "radius": 0.55, "scale": 1.0, "color": Color(0.25, 0.2, 0.3), "shape": "box", "loot_table": "lt_spider", "gold_min": 6, "gold_max": 14, "model": "mob_spider"},
		{"id": "bandit", "name": "Bandido", "level": 13, "hp": 220, "atk": 30, "def": 9, "mdef": 7, "move_speed": 4.8, "attack_range": 1.8, "attack_cooldown": 1.0, "attack_startup": 0.25, "xp": 60, "aggro_range": 9.0,
		 "radius": 0.45, "scale": 1.0, "color": Color(0.6, 0.25, 0.25), "shape": "capsule", "loot_table": "lt_bandit", "gold_min": 10, "gold_max": 24, "model": "mob_bandit"},
		{"id": "bandit_archer", "name": "Bandido Arqueiro", "level": 14, "hp": 170, "atk": 34, "def": 6, "mdef": 7, "move_speed": 4.6, "attack_range": 8.0, "attack_cooldown": 1.6, "attack_startup": 0.4, "xp": 62, "aggro_range": 10.0, "ranged": true,
		 "radius": 0.45, "scale": 1.0, "color": Color(0.5, 0.35, 0.2), "shape": "capsule", "loot_table": "lt_bandit", "gold_min": 10, "gold_max": 24, "model": "mob_bandit"},
		{"id": "ent", "name": "Ent", "level": 17, "hp": 420, "atk": 40, "def": 16, "mdef": 8, "move_speed": 2.6, "attack_range": 2.4, "attack_cooldown": 1.8, "attack_startup": 0.5, "xp": 95, "aggro_range": 6.0,
		 "radius": 0.75, "scale": 1.5, "color": Color(0.35, 0.3, 0.2), "shape": "box", "loot_table": "lt_ent", "gold_min": 12, "gold_max": 28, "model": "mob_ent"},
		{"id": "bandit_chief", "name": "Chefe dos Bandidos", "level": 20, "hp": 1400, "atk": 52, "def": 18, "mdef": 14, "move_speed": 4.6, "attack_range": 2.2, "attack_cooldown": 1.1, "attack_startup": 0.3, "xp": 520, "aggro_range": 9.0, "leash_range": 25.0,
		 "radius": 0.6, "scale": 1.35, "color": Color(0.75, 0.15, 0.15), "shape": "capsule", "is_boss": true, "loot_table": "lt_bandit_chief", "gold_min": 80, "gold_max": 150, "skill_ids": ["mob_whirl"] as Array[String], "model": "mob_bandit"},
		# ---- Ruínas (lv 20-30) ----
		{"id": "skeleton", "name": "Esqueleto", "level": 21, "hp": 380, "atk": 50, "def": 18, "mdef": 10, "move_speed": 4.0, "attack_range": 1.8, "attack_cooldown": 1.2, "xp": 120, "aggro_range": 8.0,
		 "radius": 0.45, "scale": 1.0, "color": Color(0.9, 0.9, 0.8), "shape": "capsule", "loot_table": "lt_skeleton", "gold_min": 15, "gold_max": 35, "model": "mob_skeleton"},
		{"id": "ghost", "name": "Espectro", "level": 24, "hp": 320, "atk": 30, "matk": 62, "def": 10, "mdef": 26, "move_speed": 4.4, "attack_range": 7.0, "attack_cooldown": 1.7, "attack_startup": 0.45, "xp": 150, "aggro_range": 9.0, "ranged": true,
		 "radius": 0.45, "scale": 1.0, "color": Color(0.6, 0.9, 1.0), "shape": "cone", "loot_table": "lt_ghost", "gold_min": 18, "gold_max": 40, "model": "mob_ghost"},
		{"id": "golem", "name": "Golem de Pedra", "level": 27, "hp": 1100, "atk": 70, "def": 34, "mdef": 18, "move_speed": 2.8, "attack_range": 2.6, "attack_cooldown": 2.0, "attack_startup": 0.6, "xp": 260, "aggro_range": 7.0,
		 "radius": 0.85, "scale": 1.7, "color": Color(0.5, 0.5, 0.45), "shape": "box", "loot_table": "lt_golem", "gold_min": 25, "gold_max": 60, "model": "mob_golem"},
		{"id": "dragonling", "name": "Dragonete Ancestral", "level": 30, "hp": 4200, "atk": 95, "matk": 90, "def": 36, "mdef": 30, "move_speed": 4.2, "attack_range": 2.8, "attack_cooldown": 1.3, "attack_startup": 0.4, "xp": 1600, "aggro_range": 10.0, "leash_range": 30.0,
		 "radius": 1.1, "scale": 2.2, "color": Color(0.8, 0.2, 0.3), "shape": "box", "is_boss": true, "loot_table": "lt_dragonling", "gold_min": 200, "gold_max": 400, "skill_ids": ["mob_firebreath"] as Array[String], "model": "mob_dragon"},
		# ---- invocação do Necromancer ----
		{"id": "skeleton_minion", "name": "Esqueleto Servo", "level": 1, "hp": 60, "atk": 12, "def": 4, "mdef": 4, "move_speed": 5.2, "attack_range": 1.6, "attack_cooldown": 1.0, "xp": 0,
		 "radius": 0.4, "scale": 0.9, "color": Color(0.8, 0.95, 0.85), "shape": "capsule", "loot_table": "", "gold_min": 0, "gold_max": 0, "model": "mob_skeleton"},
	]
	var out: Array = []
	for d in L:
		out.append(_mk(d))
	return out

static func build_loot() -> Array:
	return [
		_lt("lt_slime", [{"item": "slime_gel", "chance": 0.7, "min": 1, "max": 2}, {"item": "herb_green", "chance": 0.25}, {"item": "ring_gel", "chance": 0.03}]),
		_lt("lt_slime_blue", [{"item": "slime_gel", "chance": 0.6}, {"item": "herb_blue", "chance": 0.45}, {"item": "potion_mp_s", "chance": 0.1}]),
		_lt("lt_boar", [{"item": "boar_tusk", "chance": 0.5}, {"item": "herb_green", "chance": 0.3}, {"item": "cap_leather", "chance": 0.05}, {"item": "boots_leather", "chance": 0.05}]),
		_lt("lt_wolf", [{"item": "wolf_pelt", "chance": 0.6}, {"item": "iron_ore", "chance": 0.35}, {"item": "potion_hp_s", "chance": 0.12}]),
		_lt("lt_boar_king", [{"item": "boar_tusk", "chance": 1.0, "min": 3, "max": 5}, {"item": "amulet_tusk", "chance": 0.5}, {"item": "iron_ore", "chance": 1.0, "min": 2, "max": 4}, {"item": "elixir_might", "chance": 0.4}]),
		_lt("lt_spider", [{"item": "spider_silk", "chance": 0.6, "min": 1, "max": 2}, {"item": "herb_blue", "chance": 0.3}, {"item": "hood_silk", "chance": 0.04}]),
		_lt("lt_bandit", [{"item": "bandit_badge", "chance": 0.55}, {"item": "iron_ore", "chance": 0.4}, {"item": "potion_hp_m", "chance": 0.1}, {"item": "helm_iron", "chance": 0.04}, {"item": "boots_wolf", "chance": 0.04}]),
		_lt("lt_ent", [{"item": "ent_bark", "chance": 0.7, "min": 1, "max": 2}, {"item": "herb_green", "chance": 0.5, "min": 1, "max": 3}, {"item": "elixir_stone", "chance": 0.08}]),
		_lt("lt_bandit_chief", [{"item": "bandit_badge", "chance": 1.0, "min": 3, "max": 5}, {"item": "ent_bark", "chance": 1.0, "min": 2, "max": 3}, {"item": "amulet_silk", "chance": 0.5}, {"item": "helm_bone", "chance": 0.3}, {"item": "elixir_might", "chance": 0.5}]),
		_lt("lt_skeleton", [{"item": "bone_shard", "chance": 0.65, "min": 1, "max": 2}, {"item": "iron_ore", "chance": 0.4}, {"item": "potion_hp_m", "chance": 0.12}]),
		_lt("lt_ghost", [{"item": "ghost_essence", "chance": 0.55}, {"item": "herb_blue", "chance": 0.4, "min": 1, "max": 2}, {"item": "potion_mp_m", "chance": 0.12}, {"item": "ring_spectral", "chance": 0.03}]),
		_lt("lt_golem", [{"item": "golem_core", "chance": 0.35}, {"item": "iron_ore", "chance": 1.0, "min": 2, "max": 4}, {"item": "bone_shard", "chance": 0.5}, {"item": "boots_ent", "chance": 0.05}]),
		_lt("lt_dragonling", [{"item": "dragon_scale", "chance": 1.0, "min": 2, "max": 4}, {"item": "golem_core", "chance": 1.0, "min": 1, "max": 2}, {"item": "amulet_golem", "chance": 0.5}, {"item": "elixir_might", "chance": 1.0, "min": 1, "max": 2}, {"item": "crown_spectral", "chance": 0.4}]),
	]
