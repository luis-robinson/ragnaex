class_name QuestsCatalog
extends RefCounted
## Cadeia inicial de Aldara → Campina → Floresta → Ruínas.

const KILL := QuestDef.Type.KILL
const COLLECT := QuestDef.Type.COLLECT
const TALK := QuestDef.Type.TALK
const CRAFT := QuestDef.Type.CRAFT

static func _mk(d: Dictionary) -> QuestDef:
	var q := QuestDef.new()
	for k in d:
		q.set(k, d[k])
	return q

static func build() -> Array:
	var L := [
		{"id": "q01_welcome", "title": "Bem-vindo a Aldara", "giver_npc": "elder", "type": TALK, "target_id": "captain", "count": 1, "level_req": 1,
		 "reward_xp": 30, "reward_gold": 15, "reward_items": {"potion_hp_s": 2}, "next_quest": "q02_slimes", "map_hint": "Cidade de Aldara",
		 "description": "O Ancião Ravi quer que você se apresente à Capitã Mira, na praça.",
		 "dialog_offer": "Rosto novo! Vá falar com a Capitã Mira perto do portal sul. Ela sempre precisa de braços.",
		 "dialog_progress": "A Capitã está perto do portal sul da praça.", "dialog_complete": "Ótimo. Ravi me falou de você. Vamos ao trabalho."},
		{"id": "q02_slimes", "title": "Praga Gelatinosa", "giver_npc": "captain", "type": KILL, "target_id": "slime", "count": 6, "level_req": 1, "prereq_quest": "q01_welcome",
		 "reward_xp": 90, "reward_gold": 40, "reward_items": {"potion_hp_s": 2}, "next_quest": "q03_gel", "map_hint": "Campina (portal sul)",
		 "description": "Elimine 6 Slimes na Campina ao sul de Aldara.",
		 "dialog_offer": "Os slimes da Campina estão comendo as plantações. Derrube 6 deles.",
		 "dialog_progress": "Ainda tem slime na Campina. Use WASD para andar e o botão esquerdo para atacar.", "dialog_complete": "Menos gosma, mais colheita. Bom trabalho."},
		{"id": "q03_gel", "title": "Gel para a Alquimista", "giver_npc": "captain", "turnin_npc": "alchemist", "type": COLLECT, "target_id": "slime_gel", "count": 5, "level_req": 2, "prereq_quest": "q02_slimes",
		 "reward_xp": 110, "reward_gold": 30, "reward_items": {"herb_green": 3}, "next_quest": "q04_potion", "map_hint": "Campina",
		 "description": "Leve 5 Géis de Slime para Lyra, a alquimista.",
		 "dialog_offer": "Lyra, a alquimista, paga bem por gel de slime. Leve 5 pra ela.",
		 "dialog_progress": "Preciso de 5 géis. Os slimes da Campina soltam isso.", "dialog_complete": "Perfeito! Isso vai render boas poções."},
		{"id": "q04_potion", "title": "Primeira Poção", "giver_npc": "alchemist", "type": CRAFT, "target_id": "potion_hp_s", "count": 2, "level_req": 2, "prereq_quest": "q03_gel",
		 "reward_xp": 120, "reward_gold": 25, "reward_items": {"potion_mp_s": 2}, "next_quest": "q05_boars", "map_hint": "Alquimista (Aldara)",
		 "description": "Use o caldeirão de Lyra e crie 2 Poções de Vida (P).",
		 "dialog_offer": "Vou te ensinar: fale comigo de novo e use o caldeirão. Crie 2 poções de vida.",
		 "dialog_progress": "Abra o caldeirão (fale comigo) e crie as poções com erva verde + gel.", "dialog_complete": "Olha só, um alquimista nato!"},
		{"id": "q05_boars", "title": "Presas de Javali", "giver_npc": "smith", "type": COLLECT, "target_id": "boar_tusk", "count": 4, "level_req": 4, "prereq_quest": "q04_potion",
		 "reward_xp": 200, "reward_gold": 60, "reward_items": {"iron_ore": 4}, "next_quest": "q06_wolves", "map_hint": "Campina (leste)",
		 "description": "Traga 4 Presas de Javali para Brom, o ferreiro.",
		 "dialog_offer": "Presa de javali faz cabo bom. Me traz 4 e eu te mostro a forja.",
		 "dialog_progress": "Os javalis ficam no lado leste da Campina.", "dialog_complete": "Agora sim. Dá uma olhada na forja quando quiser — sua primeira arma de ferro espera."},
		{"id": "q06_wolves", "title": "Uivos na Noite", "giver_npc": "captain", "type": KILL, "target_id": "wolf", "count": 8, "level_req": 6, "prereq_quest": "q05_boars",
		 "reward_xp": 320, "reward_gold": 80, "reward_items": {"potion_hp_m": 2}, "next_quest": "q07_king", "map_hint": "Campina (norte)",
		 "description": "Lobos atacam viajantes. Mate 8 na Campina.",
		 "dialog_offer": "Os lobos estão ousados. Elimine 8 deles.",
		 "dialog_progress": "Lobos são rápidos — use o bloqueio (botão direito) quando eles avançarem.", "dialog_complete": "A estrada está mais segura. Por enquanto."},
		{"id": "q07_king", "title": "O Rei Javali", "giver_npc": "captain", "type": KILL, "target_id": "boar_king", "count": 1, "level_req": 8, "prereq_quest": "q06_wolves",
		 "reward_xp": 600, "reward_gold": 150, "reward_items": {"elixir_might": 1}, "next_quest": "q08_forest", "map_hint": "Campina (clareira sul)",
		 "description": "Derrote o Rei Javali na clareira sul da Campina.",
		 "dialog_offer": "Um javali gigante lidera os outros. Leve poções. Derrote-o.",
		 "dialog_progress": "Ele fica na clareira sul. Desvie da investida com Shift.", "dialog_complete": "O Rei caiu! Você está pronto para a Floresta."},
		{"id": "q08_forest", "title": "Rumo à Floresta", "giver_npc": "captain", "turnin_npc": "ranger_post", "type": TALK, "target_id": "ranger_post", "count": 1, "level_req": 9, "prereq_quest": "q07_king",
		 "reward_xp": 250, "reward_gold": 50, "reward_items": {}, "next_quest": "q09_spiders", "map_hint": "Floresta (portal leste)",
		 "description": "Procure o posto do Ranger Teo na entrada da Floresta.",
		 "dialog_offer": "Teo vigia a Floresta a leste. Ele vai precisar de ajuda.",
		 "dialog_progress": "O portal leste da cidade leva à Floresta.", "dialog_complete": "Mira te mandou? Bom. Tem aranha demais aqui."},
		{"id": "q09_spiders", "title": "Teias por Toda Parte", "giver_npc": "ranger_post", "type": COLLECT, "target_id": "spider_silk", "count": 6, "level_req": 10, "prereq_quest": "q08_forest",
		 "reward_xp": 700, "reward_gold": 120, "reward_items": {"potion_mp_m": 2}, "next_quest": "q10_bandits", "map_hint": "Floresta",
		 "description": "Colete 6 Sedas de Aranha.",
		 "dialog_offer": "Seda de aranha vende bem e as aranhas são praga. Traga 6.",
		 "dialog_progress": "As aranhas ficam entre as árvores grandes.", "dialog_complete": "Excelente. Isso paga a estadia de um mês."},
		{"id": "q10_bandits", "title": "Bandidos na Trilha", "giver_npc": "ranger_post", "type": KILL, "target_id": "bandit", "count": 10, "level_req": 12, "prereq_quest": "q09_spiders",
		 "reward_xp": 1100, "reward_gold": 200, "reward_items": {"iron_ore": 6}, "next_quest": "q11_chief", "map_hint": "Floresta (acampamento)",
		 "description": "Derrube 10 Bandidos no acampamento da Floresta.",
		 "dialog_offer": "Bandidos montaram acampamento ao norte. Reduza o número deles.",
		 "dialog_progress": "O acampamento fica ao norte da Floresta. Cuidado com os arqueiros.", "dialog_complete": "Eles vão pensar duas vezes agora."},
		{"id": "q11_chief", "title": "O Chefe", "giver_npc": "ranger_post", "type": KILL, "target_id": "bandit_chief", "count": 1, "level_req": 17, "prereq_quest": "q10_bandits",
		 "reward_xp": 2500, "reward_gold": 400, "reward_items": {"elixir_stone": 1}, "next_quest": "q12_ruins", "map_hint": "Floresta (acampamento)",
		 "description": "Derrote o Chefe dos Bandidos.",
		 "dialog_offer": "Sem o chefe, o bando se desfaz. Vá até o fundo do acampamento.",
		 "dialog_progress": "Ele gira a arma — saia do alcance quando ele começar a girar.", "dialog_complete": "A Floresta respira de novo. Obrigado."},
		{"id": "q12_ruins", "title": "Sussurros das Ruínas", "giver_npc": "elder", "type": KILL, "target_id": "skeleton", "count": 12, "level_req": 20, "prereq_quest": "q11_chief",
		 "reward_xp": 3200, "reward_gold": 500, "reward_items": {"potion_hp_m": 3}, "next_quest": "q13_cores", "map_hint": "Ruínas (portal oeste)",
		 "description": "Os mortos despertaram nas Ruínas a oeste. Elimine 12 Esqueletos.",
		 "dialog_offer": "Algo mexeu nas Ruínas. Os ossos andam. Vá pelo portal oeste.",
		 "dialog_progress": "Esqueletos são resistentes a dano físico fraco — melhore sua arma na forja.", "dialog_complete": "Então é verdade. Algo ancestral despertou."},
		{"id": "q13_cores", "title": "Coração de Pedra", "giver_npc": "smith", "type": COLLECT, "target_id": "golem_core", "count": 2, "level_req": 24, "prereq_quest": "q12_ruins",
		 "reward_xp": 4500, "reward_gold": 800, "reward_items": {"bone_shard": 5}, "next_quest": "q14_dragon", "map_hint": "Ruínas (fundo)",
		 "description": "Traga 2 Núcleos de Golem para Brom.",
		 "dialog_offer": "Com núcleo de golem eu forjo armas lendárias. Traz dois.",
		 "dialog_progress": "Golens ficam no fundo das Ruínas. Eles são lentos — use isso.", "dialog_complete": "Isso... isso é poder de verdade. A forja está pronta pra você."},
		{"id": "q14_dragon", "title": "O Dragonete Ancestral", "giver_npc": "elder", "type": KILL, "target_id": "dragonling", "count": 1, "level_req": 27, "prereq_quest": "q13_cores",
		 "reward_xp": 9000, "reward_gold": 2000, "reward_items": {"dragon_scale": 2, "elixir_might": 3}, "map_hint": "Ruínas (altar)",
		 "description": "Derrote o Dragonete Ancestral no altar das Ruínas.",
		 "dialog_offer": "A fonte dos sussurros é um dragonete adormecido há séculos. Acabe com isso.",
		 "dialog_progress": "O bafo de fogo cobre um cone — fique ao lado dele.", "dialog_complete": "Aldara está em dívida com você. Que sua lenda seja contada."},
	]
	var out: Array = []
	for d in L:
		out.append(_mk(d))
	return out
