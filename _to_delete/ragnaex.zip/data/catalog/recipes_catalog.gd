class_name RecipesCatalog
extends RefCounted

static func _mk(d: Dictionary) -> RecipeDef:
	var r := RecipeDef.new()
	for k in d:
		r.set(k, d[k])
	return r

static func _r(result: String, count: int, station: String, lv: int, gold: int, ing: Dictionary) -> Dictionary:
	return {"id": "rec_" + result, "result_item": result, "result_count": count, "station": station, "level_req": lv, "gold_cost": gold, "ingredients": ing}

static func build() -> Array:
	var L := [
		# ---- alquimia ----
		_r("potion_hp_s", 2, "alchemy", 1, 0, {"herb_green": 1, "slime_gel": 1}),
		_r("potion_mp_s", 2, "alchemy", 1, 0, {"herb_blue": 1, "slime_gel": 1}),
		_r("potion_hp_m", 1, "alchemy", 8, 10, {"herb_green": 3, "spider_silk": 1}),
		_r("potion_mp_m", 1, "alchemy", 8, 10, {"herb_blue": 3, "spider_silk": 1}),
		_r("elixir_might", 1, "alchemy", 10, 40, {"boar_tusk": 2, "herb_green": 2, "wolf_pelt": 1}),
		_r("elixir_stone", 1, "alchemy", 14, 40, {"ent_bark": 2, "iron_ore": 1, "herb_blue": 1}),
		_r("ring_gel", 1, "alchemy", 3, 20, {"slime_gel": 8, "herb_blue": 2}),
		_r("amulet_silk", 1, "alchemy", 10, 60, {"spider_silk": 6, "herb_blue": 3}),
		_r("ring_spectral", 1, "alchemy", 18, 150, {"ghost_essence": 4, "spider_silk": 3}),
		_r("robe_silk", 1, "alchemy", 8, 60, {"spider_silk": 5, "slime_gel": 4}),
		_r("hood_silk", 1, "alchemy", 8, 40, {"spider_silk": 3, "slime_gel": 2}),
		_r("robe_spectral", 1, "alchemy", 16, 200, {"ghost_essence": 5, "spider_silk": 4, "bone_shard": 2}),
		_r("crown_spectral", 1, "alchemy", 18, 220, {"ghost_essence": 4, "bone_shard": 3}),
		_r("robe_dragon", 1, "alchemy", 24, 600, {"dragon_scale": 2, "ghost_essence": 6, "golem_core": 1}),
		_r("staff_silk", 1, "alchemy", 8, 80, {"spider_silk": 4, "iron_ore": 2, "herb_blue": 2}),
		_r("wand_silk", 1, "alchemy", 8, 80, {"spider_silk": 4, "slime_gel": 3, "herb_blue": 2}),
		_r("staff_spectral", 1, "alchemy", 16, 250, {"ghost_essence": 5, "ent_bark": 3}),
		_r("wand_spectral", 1, "alchemy", 16, 250, {"ghost_essence": 5, "bone_shard": 2}),
		_r("scythe_spectral", 1, "alchemy", 16, 250, {"ghost_essence": 4, "bone_shard": 4, "iron_ore": 2}),
		# ---- ferraria ----
		_r("sword_iron", 1, "smith", 5, 50, {"iron_ore": 4, "boar_tusk": 2}),
		_r("axe_iron", 1, "smith", 5, 60, {"iron_ore": 6, "boar_tusk": 1}),
		_r("dagger_fang", 1, "smith", 5, 50, {"iron_ore": 3, "boar_tusk": 3}),
		_r("bow_hunter", 1, "smith", 5, 50, {"iron_ore": 2, "wolf_pelt": 3, "boar_tusk": 1}),
		_r("scythe_iron", 1, "smith", 5, 60, {"iron_ore": 5, "slime_gel": 2}),
		_r("shield_iron", 1, "smith", 5, 50, {"iron_ore": 5, "wolf_pelt": 1}),
		_r("armor_wolf", 1, "smith", 6, 60, {"wolf_pelt": 5, "iron_ore": 2}),
		_r("helm_iron", 1, "smith", 6, 40, {"iron_ore": 4}),
		_r("boots_wolf", 1, "smith", 6, 30, {"wolf_pelt": 3}),
		_r("amulet_tusk", 1, "smith", 8, 60, {"boar_tusk": 5, "iron_ore": 1}),
		_r("sword_ent", 1, "smith", 14, 200, {"ent_bark": 4, "iron_ore": 6, "bandit_badge": 3}),
		_r("axe_bone", 1, "smith", 16, 220, {"bone_shard": 6, "iron_ore": 6}),
		_r("dagger_spectral", 1, "smith", 16, 220, {"ghost_essence": 3, "iron_ore": 4, "bandit_badge": 2}),
		_r("bow_ent", 1, "smith", 14, 200, {"ent_bark": 5, "spider_silk": 4}),
		_r("shield_bone", 1, "smith", 16, 200, {"bone_shard": 6, "ent_bark": 2}),
		_r("armor_ent", 1, "smith", 14, 240, {"ent_bark": 6, "bandit_badge": 4, "iron_ore": 3}),
		_r("helm_bone", 1, "smith", 16, 150, {"bone_shard": 5, "iron_ore": 2}),
		_r("boots_ent", 1, "smith", 14, 120, {"ent_bark": 3, "spider_silk": 2}),
		_r("sword_dragon", 1, "smith", 24, 700, {"dragon_scale": 2, "golem_core": 1, "iron_ore": 10}),
		_r("axe_golem", 1, "smith", 24, 700, {"golem_core": 2, "bone_shard": 8}),
		_r("dagger_golem", 1, "smith", 24, 650, {"golem_core": 1, "ghost_essence": 4, "iron_ore": 6}),
		_r("bow_dragon", 1, "smith", 24, 700, {"dragon_scale": 2, "ent_bark": 6}),
		_r("staff_dragon", 1, "smith", 24, 700, {"dragon_scale": 2, "ghost_essence": 5}),
		_r("wand_dragon", 1, "smith", 24, 700, {"dragon_scale": 1, "golem_core": 1, "ghost_essence": 4}),
		_r("scythe_golem", 1, "smith", 24, 700, {"golem_core": 2, "ghost_essence": 3, "bone_shard": 4}),
		_r("shield_dragon", 1, "smith", 24, 650, {"dragon_scale": 2, "golem_core": 1}),
		_r("armor_dragon", 1, "smith", 24, 800, {"dragon_scale": 3, "golem_core": 1, "iron_ore": 8}),
		_r("amulet_golem", 1, "smith", 26, 500, {"golem_core": 2, "dragon_scale": 1}),
	]
	var out: Array = []
	for d in L:
		out.append(_mk(d))
	return out
