class_name SkillsCatalog
extends RefCounted
## 8 classes × 6 skills. Slots 1..6 na ordem de ClassDef.skill_ids. Desbloqueio: lv 1/3/6/10/15/20.
## target: 0 SELF, 1 DIRECTION, 2 GROUND, 3 CONE, 4 TARGET · kind: 0 PHYS, 1 MAG, 2 HEAL, 3 BUFF, 4 SUMMON, 5 MOVE

const T_SELF := 0; const T_DIR := 1; const T_GROUND := 2; const T_CONE := 3; const T_TARGET := 4
const K_PHYS := 0; const K_MAG := 1; const K_HEAL := 2; const K_BUFF := 3; const K_SUMMON := 4; const K_MOVE := 5
const UNLOCK := [1, 3, 6, 10, 15, 20]

static func _mk(d: Dictionary) -> SkillDef:
	var s := SkillDef.new()
	for k in d:
		s.set(k, d[k])
	return s

## maestria padrão: +12% poder, -4% MP, -5% CD por nível; `extras` opcional por nível (índice 1..5)
static func _mastery(extras: Dictionary = {}) -> Array:
	var arr := []
	for lv in range(6):
		arr.append({"power_mult": 1.0 + 0.12 * lv, "mp_mult": 1.0 - 0.04 * lv, "cd_mult": 1.0 - 0.05 * lv, "extra": extras.get(lv, {})})
	return arr

static func build() -> Array:
	var out: Array = []
	var defs := _all()
	for cls_id in defs:
		var list: Array = defs[cls_id]
		for i in range(list.size()):
			var d: Dictionary = list[i]
			d["class_id"] = cls_id
			d["unlock_level"] = UNLOCK[i]
			if not d.has("mastery"):
				d["mastery"] = _mastery()
			out.append(_mk(d))
	# skills de monstros/bosses
	for d in [
		{"id": "mob_charge", "name": "Investida", "target": T_DIR, "kind": K_PHYS, "power": 1.8, "cooldown": 7.0, "range": 7.0, "radius": 1.0, "startup": 0.6, "active": 0.1, "recovery": 0.6, "hit_stop_frames": 4, "icon_color": Color(1, 0.6, 0.3),
		 "effects": {"dash": 6.0, "stun": {"duration": 0.8}}},
		{"id": "mob_whirl", "name": "Giro Mortal", "target": T_SELF, "kind": K_PHYS, "power": 1.6, "cooldown": 8.0, "radius": 3.2, "startup": 0.7, "active": 0.2, "recovery": 0.5, "hit_stop_frames": 4, "icon_color": Color(1, 0.4, 0.3)},
		{"id": "mob_firebreath", "name": "Bafo de Fogo", "target": T_CONE, "kind": K_MAG, "power": 1.5, "cooldown": 6.0, "radius": 6.5, "cone_angle_deg": 70, "startup": 0.8, "active": 0.2, "recovery": 0.6, "hit_stop_frames": 4, "icon_color": Color(1, 0.3, 0.1),
		 "effects": {"dot": {"dps": 8, "duration": 4}}},
	]:
		d["mp_cost"] = 0
		d["mastery"] = _mastery()
		out.append(_mk(d))
	return out

static func _all() -> Dictionary:
	return {
	"paladin": [
		{"id": "pal_holy_strike", "name": "Golpe Sagrado", "description": "Golpe frontal com luz. Cura 15% do dano causado.", "target": T_CONE, "kind": K_PHYS,
		 "power": 1.6, "mp_cost": 8, "cooldown": 3.0, "radius": 2.4, "cone_angle_deg": 90, "startup": 0.14, "active": 0.06, "recovery": 0.3, "cancel_after": 0.12, "icon_color": Color(1, 0.95, 0.6),
		 "effects": {"heal_pct_of_dmg": 0.15}, "mastery": _mastery({3: {"heal_pct_of_dmg": 0.25}, 5: {"heal_pct_of_dmg": 0.35}})},
		{"id": "pal_shield_bash", "name": "Pancada de Escudo", "description": "Avança e atordoa o alvo à frente por 1s.", "target": T_DIR, "kind": K_PHYS,
		 "power": 1.1, "mp_cost": 10, "cooldown": 7.0, "range": 3.0, "radius": 0.9, "max_targets": 1, "startup": 0.1, "active": 0.08, "recovery": 0.3, "icon_color": Color(0.8, 0.8, 0.9),
		 "effects": {"stun": {"duration": 1.0}, "dash": 1.5}, "mastery": _mastery({2: {"stun": {"duration": 1.3}}, 4: {"stun": {"duration": 1.6}}})},
		{"id": "pal_consecrate", "name": "Consagração", "description": "Abençoa o chão: dano sagrado em área ao redor.", "target": T_SELF, "kind": K_MAG,
		 "power": 1.4, "mp_cost": 16, "cooldown": 9.0, "radius": 3.2, "startup": 0.25, "active": 0.1, "recovery": 0.4, "icon_color": Color(1, 0.9, 0.4)},
		{"id": "pal_lay_hands", "name": "Imposição de Mãos", "description": "Cura forte em si mesmo (ou aliado próximo).", "target": T_SELF, "kind": K_HEAL,
		 "power": 2.2, "mp_cost": 22, "cooldown": 14.0, "radius": 2.0, "startup": 0.3, "active": 0.05, "recovery": 0.35, "icon_color": Color(1, 1, 0.8)},
		{"id": "pal_taunt", "name": "Provocar", "description": "Atrai todos os inimigos num raio e ganha +25% DEF por 6s.", "target": T_SELF, "kind": K_BUFF,
		 "power": 0.0, "mp_cost": 12, "cooldown": 12.0, "radius": 7.0, "startup": 0.1, "active": 0.05, "recovery": 0.25, "icon_color": Color(1, 0.6, 0.4),
		 "effects": {"buff": {"id": "bulwark", "duration": 6, "def_pct": 25}}},
		{"id": "pal_divine_shield", "name": "Escudo Divino", "description": "Escudo que absorve 25% do HP máximo por 6s.", "target": T_SELF, "kind": K_BUFF,
		 "power": 0.0, "mp_cost": 28, "cooldown": 22.0, "startup": 0.15, "active": 0.05, "recovery": 0.2, "icon_color": Color(1, 1, 0.5),
		 "effects": {"shield": {"amount_pct_hp": 25, "duration": 6}}, "mastery": _mastery({2: {"shield": {"amount_pct_hp": 32, "duration": 6}}, 4: {"shield": {"amount_pct_hp": 40, "duration": 7}}})},
	],
	"berserker": [
		{"id": "ber_cleave", "name": "Rachar", "description": "Golpe largo que acerta até 4 inimigos.", "target": T_CONE, "kind": K_PHYS,
		 "power": 1.8, "mp_cost": 9, "cooldown": 3.5, "radius": 2.8, "cone_angle_deg": 120, "max_targets": 4, "startup": 0.18, "active": 0.06, "recovery": 0.35, "hit_stop_frames": 4, "icon_color": Color(1, 0.45, 0.3)},
		{"id": "ber_leap", "name": "Salto Selvagem", "description": "Salta até o ponto do cursor e esmaga o chão.", "target": T_GROUND, "kind": K_PHYS,
		 "power": 1.5, "mp_cost": 12, "cooldown": 8.0, "range": 6.0, "radius": 2.2, "startup": 0.12, "active": 0.1, "recovery": 0.35, "icon_color": Color(1, 0.6, 0.3),
		 "effects": {"dash": 5.5, "slow": {"pct": 30, "duration": 1.5}}},
		{"id": "ber_whirlwind", "name": "Redemoinho", "description": "Gira a arma: dano em todos ao redor.", "target": T_SELF, "kind": K_PHYS,
		 "power": 2.2, "mp_cost": 18, "cooldown": 10.0, "radius": 3.0, "startup": 0.2, "active": 0.3, "recovery": 0.4, "icon_color": Color(1, 0.5, 0.5)},
		{"id": "ber_fury", "name": "Fúria", "description": "+35% ATK e +15% velocidade por 8s.", "target": T_SELF, "kind": K_BUFF,
		 "power": 0.0, "mp_cost": 15, "cooldown": 20.0, "startup": 0.1, "active": 0.05, "recovery": 0.2, "icon_color": Color(1, 0.3, 0.2),
		 "effects": {"buff": {"id": "fury", "duration": 8, "atk_pct": 35, "speed_pct": 15}}},
		{"id": "ber_execute", "name": "Executar", "description": "Golpe devastador em um alvo. Dano enorme.", "target": T_TARGET, "kind": K_PHYS,
		 "power": 3.4, "mp_cost": 20, "cooldown": 12.0, "range": 2.6, "radius": 0.0, "startup": 0.3, "active": 0.06, "recovery": 0.5, "hit_stop_frames": 6, "icon_color": Color(0.9, 0.2, 0.2)},
		{"id": "ber_warcry", "name": "Grito de Guerra", "description": "Atordoa inimigos próximos por 1.2s.", "target": T_SELF, "kind": K_MAG,
		 "power": 0.4, "mp_cost": 22, "cooldown": 24.0, "radius": 4.0, "startup": 0.2, "active": 0.05, "recovery": 0.3, "icon_color": Color(1, 0.8, 0.5),
		 "effects": {"stun": {"duration": 1.2}}},
	],
	"bishop": [
		{"id": "bis_heal", "name": "Curar", "description": "Cura o aliado sob o cursor (ou você).", "target": T_SELF, "kind": K_HEAL,
		 "power": 1.5, "mp_cost": 14, "cooldown": 2.5, "radius": 0.0, "startup": 0.3, "active": 0.05, "recovery": 0.25, "lock_facing": false, "icon_color": Color(0.8, 1, 0.8)},
		{"id": "bis_smite", "name": "Castigar", "description": "Raio de luz que atravessa inimigos.", "target": T_DIR, "kind": K_MAG,
		 "power": 1.7, "mp_cost": 12, "cooldown": 3.0, "range": 8.0, "radius": 0.5, "projectile_speed": 20.0, "projectile_pierce": true, "startup": 0.2, "active": 0.05, "recovery": 0.3, "icon_color": Color(1, 1, 0.7)},
		{"id": "bis_blessing", "name": "Bênção", "description": "+20% ATK/MATK e +5 crit para aliados próximos por 15s.", "target": T_SELF, "kind": K_BUFF,
		 "power": 0.0, "mp_cost": 20, "cooldown": 25.0, "radius": 6.0, "startup": 0.25, "active": 0.05, "recovery": 0.3, "icon_color": Color(1, 0.95, 0.6),
		 "effects": {"buff": {"id": "blessing", "duration": 15, "atk_pct": 20, "matk_pct": 20, "crit": 5}}},
		{"id": "bis_sanctuary", "name": "Santuário", "description": "Cura em área no ponto do cursor.", "target": T_GROUND, "kind": K_HEAL,
		 "power": 1.2, "mp_cost": 26, "cooldown": 12.0, "range": 8.0, "radius": 3.0, "startup": 0.35, "active": 0.05, "recovery": 0.35, "icon_color": Color(0.9, 1, 0.9)},
		{"id": "bis_purify", "name": "Purificar", "description": "Explosão sagrada: dano e lentidão em cone.", "target": T_CONE, "kind": K_MAG,
		 "power": 1.5, "mp_cost": 18, "cooldown": 8.0, "radius": 4.5, "cone_angle_deg": 80, "startup": 0.25, "active": 0.05, "recovery": 0.35, "icon_color": Color(1, 1, 0.9),
		 "effects": {"slow": {"pct": 40, "duration": 2.5}}},
		{"id": "bis_judgement", "name": "Julgamento", "description": "Pilar de luz no cursor: dano alto e atordoa.", "target": T_GROUND, "kind": K_MAG,
		 "power": 2.8, "mp_cost": 32, "cooldown": 18.0, "range": 9.0, "radius": 2.2, "startup": 0.45, "active": 0.05, "recovery": 0.4, "hit_stop_frames": 5, "icon_color": Color(1, 0.95, 0.5),
		 "effects": {"stun": {"duration": 1.0}}},
	],
	"druid": [
		{"id": "dru_thorns", "name": "Espinhos", "description": "Lança espinhos envenenados na direção do cursor.", "target": T_DIR, "kind": K_MAG,
		 "power": 1.3, "mp_cost": 9, "cooldown": 2.5, "range": 8.0, "radius": 0.4, "projectile_speed": 18.0, "startup": 0.15, "active": 0.05, "recovery": 0.25, "icon_color": Color(0.5, 0.9, 0.4),
		 "effects": {"dot": {"dps": 4, "duration": 4}}},
		{"id": "dru_entangle", "name": "Enraizar", "description": "Raízes prendem inimigos na área por 2.5s.", "target": T_GROUND, "kind": K_MAG,
		 "power": 0.6, "mp_cost": 15, "cooldown": 10.0, "range": 8.0, "radius": 2.5, "startup": 0.25, "active": 0.05, "recovery": 0.3, "icon_color": Color(0.4, 0.7, 0.3),
		 "effects": {"root": {"duration": 2.5}}},
		{"id": "dru_regrowth", "name": "Rebrotar", "description": "Cura a si e aliados próximos.", "target": T_SELF, "kind": K_HEAL,
		 "power": 1.3, "mp_cost": 18, "cooldown": 8.0, "radius": 4.0, "startup": 0.3, "active": 0.05, "recovery": 0.3, "icon_color": Color(0.6, 1, 0.6)},
		{"id": "dru_swarm", "name": "Enxame", "description": "Insetos devoram inimigos em cone (dano contínuo).", "target": T_CONE, "kind": K_MAG,
		 "power": 1.0, "mp_cost": 20, "cooldown": 9.0, "radius": 5.0, "cone_angle_deg": 70, "startup": 0.2, "active": 0.05, "recovery": 0.3, "icon_color": Color(0.7, 0.6, 0.2),
		 "effects": {"dot": {"dps": 7, "duration": 5}, "slow": {"pct": 25, "duration": 3}}},
		{"id": "dru_bear_form", "name": "Forma de Urso", "description": "+40% DEF, +25% ATK e +HP por 10s.", "target": T_SELF, "kind": K_BUFF,
		 "power": 0.0, "mp_cost": 25, "cooldown": 28.0, "startup": 0.2, "active": 0.05, "recovery": 0.3, "icon_color": Color(0.55, 0.4, 0.25),
		 "effects": {"buff": {"id": "bear", "duration": 10, "def_pct": 40, "atk_pct": 25, "attr_VIT": 6}}},
		{"id": "dru_wild_growth", "name": "Crescimento Selvagem", "description": "Floresta explode no cursor: dano alto + raízes.", "target": T_GROUND, "kind": K_MAG,
		 "power": 2.6, "mp_cost": 34, "cooldown": 20.0, "range": 9.0, "radius": 3.2, "startup": 0.4, "active": 0.05, "recovery": 0.4, "icon_color": Color(0.3, 0.9, 0.4),
		 "effects": {"root": {"duration": 1.5}}},
	],
	"ranger": [
		{"id": "ran_power_shot", "name": "Tiro Poderoso", "description": "Flecha perfurante de longo alcance.", "target": T_DIR, "kind": K_PHYS,
		 "power": 2.0, "mp_cost": 8, "cooldown": 3.0, "range": 12.0, "radius": 0.4, "projectile_speed": 28.0, "projectile_pierce": true, "startup": 0.22, "active": 0.05, "recovery": 0.3, "icon_color": Color(0.7, 1, 0.7)},
		{"id": "ran_multishot", "name": "Tiro Múltiplo", "description": "Leque de flechas em cone curto.", "target": T_CONE, "kind": K_PHYS,
		 "power": 1.3, "mp_cost": 12, "cooldown": 5.0, "radius": 6.0, "cone_angle_deg": 60, "max_targets": 5, "startup": 0.18, "active": 0.05, "recovery": 0.3, "icon_color": Color(0.8, 1, 0.6)},
		{"id": "ran_disengage", "name": "Recuar", "description": "Salto para trás e +30% velocidade por 3s.", "target": T_SELF, "kind": K_BUFF,
		 "power": 0.0, "mp_cost": 8, "cooldown": 9.0, "startup": 0.05, "active": 0.05, "recovery": 0.15, "lock_facing": true, "icon_color": Color(0.6, 0.9, 0.9),
		 "effects": {"dash": -4.5, "buff": {"id": "swift", "duration": 3, "speed_pct": 30}}},
		{"id": "ran_trap", "name": "Armadilha", "description": "Explosão no cursor que enraíza e fere.", "target": T_GROUND, "kind": K_PHYS,
		 "power": 1.4, "mp_cost": 14, "cooldown": 10.0, "range": 8.0, "radius": 2.0, "startup": 0.2, "active": 0.05, "recovery": 0.3, "icon_color": Color(0.7, 0.6, 0.4),
		 "effects": {"root": {"duration": 2.0}}},
		{"id": "ran_mark", "name": "Marca do Caçador", "description": "+40% ATK e +15 crit por 8s.", "target": T_SELF, "kind": K_BUFF,
		 "power": 0.0, "mp_cost": 16, "cooldown": 22.0, "startup": 0.1, "active": 0.05, "recovery": 0.2, "icon_color": Color(1, 0.8, 0.4),
		 "effects": {"buff": {"id": "mark", "duration": 8, "atk_pct": 40, "crit": 15}}},
		{"id": "ran_rain", "name": "Chuva de Flechas", "description": "Chuva de flechas em grande área no cursor.", "target": T_GROUND, "kind": K_PHYS,
		 "power": 2.4, "mp_cost": 30, "cooldown": 18.0, "range": 11.0, "radius": 3.8, "startup": 0.4, "active": 0.05, "recovery": 0.4, "icon_color": Color(0.6, 0.8, 1),
		 "effects": {"slow": {"pct": 30, "duration": 2}}},
	],
	"assassin": [
		{"id": "ass_backstab", "name": "Apunhalar", "description": "Golpe rápido com chance de crítico altíssima.", "target": T_TARGET, "kind": K_PHYS,
		 "power": 1.7, "mp_cost": 7, "cooldown": 2.5, "range": 2.2, "startup": 0.08, "active": 0.05, "recovery": 0.22, "cancel_after": 0.05, "icon_color": Color(0.8, 0.5, 1),
		 "effects": {"buff": {"id": "focus", "duration": 0.3, "crit": 40}}},
		{"id": "ass_shadowstep", "name": "Passo das Sombras", "description": "Teleporta até o cursor e corta tudo ao redor.", "target": T_GROUND, "kind": K_PHYS,
		 "power": 1.2, "mp_cost": 12, "cooldown": 7.0, "range": 7.0, "radius": 1.8, "startup": 0.05, "active": 0.05, "recovery": 0.25, "icon_color": Color(0.5, 0.3, 0.7),
		 "effects": {"dash": 6.5}},
		{"id": "ass_poison", "name": "Lâmina Venenosa", "description": "Corte em cone que envenena por 6s.", "target": T_CONE, "kind": K_PHYS,
		 "power": 1.1, "mp_cost": 10, "cooldown": 6.0, "radius": 2.3, "cone_angle_deg": 100, "startup": 0.1, "active": 0.05, "recovery": 0.25, "icon_color": Color(0.4, 0.9, 0.3),
		 "effects": {"dot": {"dps": 6, "duration": 6}}},
		{"id": "ass_fan", "name": "Leque de Facas", "description": "Lança facas em todas as direções.", "target": T_SELF, "kind": K_PHYS,
		 "power": 1.5, "mp_cost": 16, "cooldown": 9.0, "radius": 4.5, "startup": 0.15, "active": 0.05, "recovery": 0.3, "icon_color": Color(0.8, 0.8, 0.9)},
		{"id": "ass_smoke", "name": "Cortina de Fumaça", "description": "Lentidão em área e +25% velocidade própria.", "target": T_SELF, "kind": K_MAG,
		 "power": 0.3, "mp_cost": 18, "cooldown": 16.0, "radius": 4.0, "startup": 0.1, "active": 0.05, "recovery": 0.2, "icon_color": Color(0.5, 0.5, 0.55),
		 "effects": {"slow": {"pct": 50, "duration": 3}, "buff": {"id": "smoke", "duration": 4, "speed_pct": 25}}},
		{"id": "ass_execute", "name": "Golpe Mortal", "description": "Dano brutal em um alvo isolado.", "target": T_TARGET, "kind": K_PHYS,
		 "power": 3.6, "mp_cost": 24, "cooldown": 14.0, "range": 2.4, "startup": 0.2, "active": 0.05, "recovery": 0.4, "hit_stop_frames": 6, "icon_color": Color(0.9, 0.2, 0.5)},
	],
	"elementalist": [
		{"id": "ele_fireball", "name": "Bola de Fogo", "description": "Projétil de fogo que explode e queima.", "target": T_DIR, "kind": K_MAG,
		 "power": 1.8, "mp_cost": 11, "cooldown": 2.5, "range": 9.0, "radius": 0.5, "projectile_speed": 16.0, "startup": 0.22, "active": 0.05, "recovery": 0.3, "icon_color": Color(1, 0.5, 0.2),
		 "effects": {"dot": {"dps": 5, "duration": 3}}},
		{"id": "ele_frost_nova", "name": "Nova de Gelo", "description": "Congela e retarda tudo ao redor.", "target": T_SELF, "kind": K_MAG,
		 "power": 1.1, "mp_cost": 16, "cooldown": 9.0, "radius": 3.5, "startup": 0.15, "active": 0.05, "recovery": 0.3, "icon_color": Color(0.6, 0.9, 1),
		 "effects": {"root": {"duration": 1.2}, "slow": {"pct": 50, "duration": 3}}},
		{"id": "ele_lightning", "name": "Relâmpago", "description": "Raio instantâneo em linha reta.", "target": T_DIR, "kind": K_MAG,
		 "power": 2.0, "mp_cost": 14, "cooldown": 4.0, "range": 10.0, "radius": 0.6, "max_targets": 3, "startup": 0.2, "active": 0.05, "recovery": 0.3, "hit_stop_frames": 4, "icon_color": Color(0.8, 0.8, 1)},
		{"id": "ele_meteor", "name": "Meteoro", "description": "Meteoro cai no cursor: dano enorme em área.", "target": T_GROUND, "kind": K_MAG,
		 "power": 3.0, "mp_cost": 30, "cooldown": 14.0, "range": 10.0, "radius": 3.0, "startup": 0.55, "active": 0.05, "recovery": 0.45, "hit_stop_frames": 6, "icon_color": Color(1, 0.4, 0.1),
		 "effects": {"dot": {"dps": 6, "duration": 3}}},
		{"id": "ele_blink", "name": "Piscar", "description": "Teleporta curta distância na direção do cursor.", "target": T_SELF, "kind": K_MOVE,
		 "power": 0.0, "mp_cost": 10, "cooldown": 8.0, "startup": 0.02, "active": 0.02, "recovery": 0.1, "icon_color": Color(0.7, 0.6, 1),
		 "effects": {"dash": 6.0}},
		{"id": "ele_blizzard", "name": "Nevasca", "description": "Tempestade de gelo gigante no cursor.", "target": T_GROUND, "kind": K_MAG,
		 "power": 2.6, "mp_cost": 38, "cooldown": 20.0, "range": 10.0, "radius": 4.5, "startup": 0.5, "active": 0.05, "recovery": 0.5, "icon_color": Color(0.5, 0.8, 1),
		 "effects": {"slow": {"pct": 60, "duration": 4}, "dot": {"dps": 5, "duration": 4}}},
	],
	"necromancer": [
		{"id": "nec_drain", "name": "Drenar Vida", "description": "Dreno sombrio: cura 40% do dano.", "target": T_DIR, "kind": K_MAG,
		 "power": 1.4, "mp_cost": 10, "cooldown": 2.5, "range": 7.0, "radius": 0.7, "max_targets": 1, "startup": 0.2, "active": 0.05, "recovery": 0.3, "icon_color": Color(0.4, 1, 0.6),
		 "effects": {"heal_pct_of_dmg": 0.4}},
		{"id": "nec_raise", "name": "Erguer Mortos", "description": "Invoca 2 esqueletos por 25s (máx 3).", "target": T_SELF, "kind": K_SUMMON,
		 "power": 0.0, "mp_cost": 22, "cooldown": 12.0, "startup": 0.4, "active": 0.05, "recovery": 0.3, "icon_color": Color(0.7, 0.9, 0.7),
		 "effects": {"summon": {"monster_id": "skeleton_minion", "count": 2, "duration": 25, "max": 3}},
		 "mastery": _mastery({2: {"summon": {"monster_id": "skeleton_minion", "count": 2, "duration": 30, "max": 4}}, 4: {"summon": {"monster_id": "skeleton_minion", "count": 3, "duration": 35, "max": 5}}})},
		{"id": "nec_plague", "name": "Praga", "description": "Nuvem de doença no cursor: dano contínuo forte.", "target": T_GROUND, "kind": K_MAG,
		 "power": 0.8, "mp_cost": 18, "cooldown": 9.0, "range": 9.0, "radius": 3.0, "startup": 0.3, "active": 0.05, "recovery": 0.3, "icon_color": Color(0.5, 0.7, 0.3),
		 "effects": {"dot": {"dps": 9, "duration": 6}, "slow": {"pct": 20, "duration": 3}}},
		{"id": "nec_bone_wall", "name": "Muralha de Ossos", "description": "Escudo de ossos (20% HP) e +20% DEF por 6s.", "target": T_SELF, "kind": K_BUFF,
		 "power": 0.0, "mp_cost": 20, "cooldown": 18.0, "startup": 0.15, "active": 0.05, "recovery": 0.25, "icon_color": Color(0.9, 0.9, 0.8),
		 "effects": {"shield": {"amount_pct_hp": 20, "duration": 6}, "buff": {"id": "bonewall", "duration": 6, "def_pct": 20}}},
		{"id": "nec_curse", "name": "Maldição", "description": "Cone de trevas: dano e lentidão pesada.", "target": T_CONE, "kind": K_MAG,
		 "power": 1.6, "mp_cost": 20, "cooldown": 10.0, "radius": 5.0, "cone_angle_deg": 75, "startup": 0.25, "active": 0.05, "recovery": 0.35, "icon_color": Color(0.5, 0.2, 0.6),
		 "effects": {"slow": {"pct": 45, "duration": 3}}},
		{"id": "nec_harvest", "name": "Colheita Sombria", "description": "Explosão de almas: dano alto em área e cura 25%.", "target": T_SELF, "kind": K_MAG,
		 "power": 2.6, "mp_cost": 36, "cooldown": 22.0, "radius": 4.5, "startup": 0.45, "active": 0.05, "recovery": 0.45, "hit_stop_frames": 5, "icon_color": Color(0.3, 1, 0.7),
		 "effects": {"heal_pct_of_dmg": 0.25}},
	],
	}
