extends Node
## GameData (autoload): catálogo de todas as definições, indexadas por id.
## Os dados são escritos em GDScript (data/catalog/*.gd) e viram Resources em memória;
## qualquer um pode ser salvo como .tres com ResourceSaver se quiser editar no inspetor.

var classes: Dictionary = {}     # id -> ClassDef
var skills: Dictionary = {}      # id -> SkillDef
var items: Dictionary = {}       # id -> ItemDef
var monsters: Dictionary = {}    # id -> MonsterDef
var quests: Dictionary = {}      # id -> QuestDef
var recipes: Dictionary = {}     # id -> RecipeDef
var maps: Dictionary = {}        # id -> MapDef
var loot_tables: Dictionary = {} # id -> LootTable
var bot_names: Array = []
var bot_lines: Dictionary = {}
var _basic_cache: Dictionary = {}

func _ready() -> void:
	load_all()

func load_all() -> void:
	for c in ClassesCatalog.build():
		classes[c.id] = c
	for s in SkillsCatalog.build():
		skills[s.id] = s
	for i in ItemsCatalog.build():
		items[i.id] = i
	for m in MonstersCatalog.build():
		monsters[m.id] = m
	for l in MonstersCatalog.build_loot():
		loot_tables[l.id] = l
	for q in QuestsCatalog.build():
		quests[q.id] = q
	for r in RecipesCatalog.build():
		recipes[r.id] = r
	for m in MapsCatalog.build():
		maps[m.id] = m
	bot_names = BotsCatalog.NAMES.duplicate()
	bot_lines = BotsCatalog.LINES

func town_map_id() -> String:
	for id in maps:
		if maps[id].is_town:
			return id
	return maps.keys()[0]

func class_list() -> Array:
	var out := classes.values()
	out.sort_custom(func(a, b): return a.name < b.name)
	return out

func random_bot_line(ctx: String) -> String:
	var arr: Array = bot_lines.get(ctx, bot_lines.get("town", ["..."]))
	return arr[randi() % arr.size()]

## Ataque básico como SkillDef gerado por classe (cadência, alcance e tipo vêm da ClassDef).
func basic_skill_for_class(cls: ClassDef) -> SkillDef:
	var key := "basic_" + cls.id
	if _basic_cache.has(key):
		return _basic_cache[key]
	var s := SkillDef.new()
	s.id = key
	s.name = "Ataque"
	s.class_id = cls.id
	s.kind = cls.basic_attack_kind
	s.power = cls.basic_attack_power
	s.mp_cost = 0.0
	s.cooldown = cls.basic_attack_cooldown
	s.startup = 0.12 if not cls.basic_attack_is_ranged else 0.18
	s.active = 0.06
	s.recovery = maxf(0.12, cls.basic_attack_cooldown * 0.45)
	s.cancel_after = 0.05
	s.hit_stop_frames = Balance.HIT_STOP_FRAMES_BASIC
	s.max_targets = 1 if cls.basic_attack_is_ranged else 2
	if cls.basic_attack_is_ranged:
		s.target = SkillDef.Target.DIRECTION
		s.range = cls.basic_attack_range
		s.radius = 0.35
		s.projectile_speed = 22.0
		s.icon_color = cls.color
	else:
		s.target = SkillDef.Target.CONE
		s.radius = cls.basic_attack_range
		s.cone_angle_deg = 110.0
	_basic_cache[key] = s
	return s

func basic_skill_for_monster(m: MonsterDef) -> SkillDef:
	var key := "basic_mob_" + m.id
	if _basic_cache.has(key):
		return _basic_cache[key]
	var s := SkillDef.new()
	s.id = key
	s.name = "Ataque"
	s.kind = SkillDef.Kind.MAGICAL if m.matk > m.atk else SkillDef.Kind.PHYSICAL
	s.power = 1.0
	s.mp_cost = 0.0
	s.cooldown = m.attack_cooldown
	s.startup = m.attack_startup
	s.active = 0.08
	s.recovery = 0.35
	s.cancel_after = 0.1
	s.hit_stop_frames = 2
	s.max_targets = 1
	s.icon_color = m.color
	if m.ranged:
		s.target = SkillDef.Target.DIRECTION
		s.range = m.attack_range
		s.radius = 0.35
		s.projectile_speed = 14.0
	else:
		s.target = SkillDef.Target.CONE
		s.radius = m.attack_range
		s.cone_angle_deg = 100.0
	_basic_cache[key] = s
	return s
