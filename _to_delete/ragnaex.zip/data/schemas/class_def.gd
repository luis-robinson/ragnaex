class_name ClassDef
extends Resource

@export var id: String = ""
@export var name: String = ""
@export var description: String = ""
@export var color: Color = Color.WHITE
@export var model: String = ""               ## nome do GLB em assets/models (sem extensão)
@export var weapon_types: Array[String] = []  ## tipos de arma permitidos (sword, axe2h, staff, bow, dagger, wand, scythe, mace)
@export var can_use_shield: bool = false
@export var base_hp: float = 100.0            ## HP base no lv1 (por nível soma hp_per_level)
@export var base_mp: float = 50.0
@export var hp_per_level: float = 12.0
@export var mp_per_level: float = 6.0
@export var move_speed: float = 5.5
@export var basic_attack_power: float = 1.0
@export var basic_attack_cooldown: float = 0.65
@export var basic_attack_range: float = 1.8
@export var basic_attack_is_ranged: bool = false
@export var basic_attack_kind: int = 0        ## SkillDef.Kind (0 physical, 1 magical)
@export var starting_equipment: Array[String] = []
@export var skill_ids: Array[String] = []     ## 6 skills, ordem = slots 1..6
@export var role: String = "dps"              ## tank | dps | healer | ranged | caster
