class_name ItemDef
extends Resource
## Itens: materiais, consumíveis e equipamentos. Equipamento é o que dá pontos de atributo.

enum Type { MATERIAL, CONSUMABLE, EQUIPMENT, QUEST }
enum Slot { NONE, WEAPON, OFFHAND, HEAD, BODY, BOOTS, ACCESSORY }

@export var id: String = ""
@export var name: String = ""
@export var description: String = ""
@export var type: Type = Type.MATERIAL
@export var slot: Slot = Slot.NONE
@export var icon_color: Color = Color.WHITE
@export var stack_max: int = 99
@export var price: int = 10
@export var level_req: int = 1
@export var rarity: int = 0                 ## 0 comum, 1 incomum, 2 raro, 3 épico

## equipamento
@export var weapon_type: String = ""        ## sword, axe2h, staff, bow, dagger, wand, scythe, mace, shield
@export var atk: float = 0.0
@export var matk: float = 0.0
@export var def: float = 0.0
@export var mdef: float = 0.0
@export var attributes: Dictionary = {}     ## {"FOR":2,"AGI":0,"VIT":1,"WILL":0,"INT":0}
@export var class_restriction: Array[String] = []

## consumível: {"heal": 50, "heal_pct": 0.2, "mana": 30, "buff": {"id":"might","duration":30,"atk_pct":15}}
@export var consume: Dictionary = {}
@export var consume_cooldown: float = 3.0

func is_equipment() -> bool:
	return type == Type.EQUIPMENT

func attr(name: String) -> int:
	return int(attributes.get(name, 0))
