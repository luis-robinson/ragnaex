class_name MapDef
extends Resource
## Um mapa é 100% dados: a simulação usa `obstacles` para colisão e a apresentação
## constrói o blockout a partir dos mesmos dados (ou carrega o GLB quando existir).
## O chão é o plano y = 0.

@export var id: String = ""
@export var name: String = ""
@export var is_town: bool = false
@export var level_range: Vector2i = Vector2i(1, 10)
@export var size: Vector2 = Vector2(80, 80)        ## área caminhável centrada em (0,0)
@export var ground_color: Color = Color(0.35, 0.55, 0.3)
@export var ground_color_alt: Color = Color(0.3, 0.5, 0.27)
@export var ambient: Color = Color(0.9, 0.9, 1.0)
@export var sun_energy: float = 1.2
@export var spawn_point: Vector3 = Vector3.ZERO
@export var model: String = ""                     ## GLB do cenário em assets/models (opcional)

## obstáculos: {"kind":"house|wall|tree|rock|fence|well|fountain|stall|pillar|ruin|crate",
##   "pos":Vector3, "size":Vector3, "rot":float(deg), "color":Color, "solid":bool}
@export var obstacles: Array = []
## portais: {"id":"to_meadows","pos":Vector3,"radius":2.0,"target_map":"field_meadows","target_pos":Vector3,"label":"Campina"}
@export var portals: Array = []
## npcs: {"id":"elder","name":"Ancião Ravi","pos":Vector3,"role":"quest|smith|alchemy|merchant|board|guard",
##   "color":Color,"dialog":["..."],"quests":["q01"],"shop":["potion_hp_s"],"facing":float}
@export var npcs: Array = []
## spawners: {"monster_id":"slime","pos":Vector3,"radius":8.0,"count":5,"respawn":12.0}
@export var spawners: Array = []
## pontos de interesse para bots (praça, ferreiro, etc.)
@export var bot_hangouts: Array = []               ## Array[Vector3]
@export var bot_population: int = 0
@export var decor: Array = []                       ## {"kind":"grass|flower|lamp|banner|path","pos":Vector3,"size":Vector3,"color":Color}

func half() -> Vector2:
	return size * 0.5

func clamp_inside(p: Vector3, margin: float = 0.5) -> Vector3:
	var h := half() - Vector2(margin, margin)
	return Vector3(clampf(p.x, -h.x, h.x), p.y, clampf(p.z, -h.y, h.y))
