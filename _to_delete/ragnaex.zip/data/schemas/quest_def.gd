class_name QuestDef
extends Resource

enum Type { KILL, COLLECT, TALK, CRAFT }

@export var id: String = ""
@export var title: String = ""
@export var description: String = ""
@export var giver_npc: String = ""        ## NPC que dá a quest
@export var turnin_npc: String = ""       ## NPC que recebe (vazio = o mesmo)
@export var type: Type = Type.KILL
@export var target_id: String = ""        ## monster_id / item_id / npc_id / item craftado
@export var count: int = 1
@export var level_req: int = 1
@export var reward_xp: int = 50
@export var reward_gold: int = 20
@export var reward_items: Dictionary = {}  ## {item_id: count}
@export var next_quest: String = ""
@export var prereq_quest: String = ""
@export var map_hint: String = ""          ## onde o objetivo está (texto)
@export var dialog_offer: String = ""
@export var dialog_progress: String = ""
@export var dialog_complete: String = ""

func turnin() -> String:
	return turnin_npc if turnin_npc != "" else giver_npc
