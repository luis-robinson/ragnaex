class_name SkillDef
extends Resource
## Definição de uma skill. Os números por maestria vêm de `mastery` (6 entradas, nível 0..5).

enum Target { SELF, DIRECTION, GROUND, CONE, TARGET }
enum Kind { PHYSICAL, MAGICAL, HEAL, BUFF, SUMMON, MOVEMENT }

@export var id: String = ""
@export var name: String = ""
@export var description: String = ""
@export var class_id: String = ""
@export var unlock_level: int = 1
@export var target: Target = Target.DIRECTION
@export var kind: Kind = Kind.PHYSICAL
@export var icon_color: Color = Color.WHITE

## multiplicador do ATK/MATK (1.0 = 100%)
@export var power: float = 1.0
@export var mp_cost: float = 10.0
@export var cooldown: float = 4.0
@export var range: float = 6.0         ## alcance máximo (DIRECTION = comprimento, GROUND = distância máx do retículo)
@export var radius: float = 1.5        ## GROUND/TARGET: raio do AoE. DIRECTION: meia-largura. CONE: raio
@export var cone_angle_deg: float = 90.0
@export var max_targets: int = 99

## timing em segundos (movimento por código, não root motion)
@export var startup: float = 0.15
@export var active: float = 0.05
@export var recovery: float = 0.35
@export var cancel_after: float = 0.2   ## a partir de quando (dentro da recovery) pode cancelar com movimento/dash
@export var lock_facing: bool = true    ## trava a direção durante a skill
@export var hit_stop_frames: int = 3

## projétil: 0 = instantâneo (hitscan). >0 = velocidade m/s (DIRECTION)
@export var projectile_speed: float = 0.0
@export var projectile_pierce: bool = false

## efeitos extra: {"dot": {"dps": 5, "duration": 4}, "slow": {"pct": 40, "duration": 2},
## "stun": {"duration": 1}, "root": {"duration": 2}, "buff": {"id":"fury","duration":8,"atk_pct":30},
## "heal_pct_of_dmg": 0.3, "dash": 4.0, "summon": {"monster_id":"skeleton","count":2,"duration":20},
## "shield": {"amount_pct_hp": 20, "duration": 5}}
@export var effects: Dictionary = {}

## Maestria: array de 6 dicionários {power_mult, mp_mult, cd_mult, extra:Dictionary}
@export var mastery: Array = []

func mastery_entry(level: int) -> Dictionary:
	var lv := clampi(level, 0, 5)
	if mastery.size() > lv:
		return mastery[lv]
	# fallback padrão: +12% poder, -4% custo, -5% cooldown por nível
	return {"power_mult": 1.0 + 0.12 * lv, "mp_mult": 1.0 - 0.04 * lv, "cd_mult": 1.0 - 0.05 * lv, "extra": {}}

func power_at(level: int) -> float:
	return power * float(mastery_entry(level).get("power_mult", 1.0))

func mp_cost_at(level: int) -> float:
	return mp_cost * float(mastery_entry(level).get("mp_mult", 1.0))

func cooldown_at(level: int) -> float:
	return cooldown * float(mastery_entry(level).get("cd_mult", 1.0))
