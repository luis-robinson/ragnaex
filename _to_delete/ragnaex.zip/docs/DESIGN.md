# RagnaEx — Documento de design (fonte da verdade para os agentes)

## Visão
"MMO" 2.5D single-player com bots que parecem jogadores. Referências: Ragnarok Online (câmera alta fixa, mundo 3D),
Tree of Savior (arte: chibi, pastel, pintado/flat, outline), Drakantos (combate de ação sem target-lock: personagem encara
o cursor, LMB básico, skills como skillshots/área no cursor).

## Pilares
1. **Responsividade**: input nunca é engolido (buffer de 8 ticks), startup curto, recovery cancelável por movimento/dash, hit-stop curto.
2. **Mira pelo mouse**: toda skill tem forma no chão (retículo) — SELF / DIRECTION / GROUND / CONE / TARGET.
3. **Equipamento é poder**: pontos de atributo vêm só de itens; level dá HP/MP base e pontos de maestria.
4. **Mundo vivo**: bots usam o mesmo pipeline do jogador; caçam, vendem, conversam, morrem.
5. **Pronto para rede**: `core/sim` é o servidor; apresentação é cliente burro.

## Controles
WASD mover · LMB ataque básico · RMB (segurar) bloqueio · 1-6 skills · F1-F3 poções · Shift dash · Espaço interagir ·
Q/E girar câmera 45° · scroll zoom · I bolsa · C personagem · K skills/maestria · L quests · Enter chat · Esc fecha.

## Atributos → stats (`core/sim/stats.gd`, constantes em `data/balance.gd`)
| Atributo | Efeito |
|---|---|
| FOR | ATK físico (×2/pt); com escudo: +0.6%/pt chance de bloqueio; com arma física: redução ao bloquear 30% + 0.5%/pt (cap 60%) |
| AGI | arco: substitui FOR (×2.2/pt); adaga: +1/pt; outras ×0.25; crit físico +0.4%/pt |
| VIT | HP +12/pt; DEF física +1.5/pt |
| WILL | cura +3%/pt; MP +8/pt; DEF mágica +1.5/pt |
| INT | MATK ×2.5/pt; crit mágico +0.4%/pt |

Dano = (ATK × poder − DEF × 0.5, mín. 15% do bruto) × variação ±10% × crit 1.5. Bloqueio ativo (RMB) sempre bloqueia e soma +25% de redução
(+10% com escudo), custa 2 MP/s e reduz velocidade a 50%. Bloqueio passivo só com escudo (chance).

## Classes (6 skills, slots 1-6, unlock 1/3/6/10/15/20)
Paladino (espada+escudo, tank) · Berserker (machado 2H, dps) · Bispo (cajado, healer) · Druida (natureza, caster/heal) ·
Ranger (arco, ranged) · Assassino (adagas, dps/crit) · Elementalista (fogo/gelo/raio, caster AoE) · Necromancer (invocações/drenos).
Ataque básico: cadência, alcance e tipo (melee cone / ranged projétil) vêm da `ClassDef`.

## Maestria
Cada skill 0-5. Custo em pontos = nível atual + 1. Pontos: 1 por level, +1 nos levels 10/20/30. Usar a skill 30× sobe 1 nível grátis.
Por padrão cada nível = +12% poder, −4% MP, −5% CD; skills podem ter `extra` por nível (stun maior, mais invocações…).

## Progressão
Lv 1-30. XP = 60 × 1.22^(lv−1). Morte: −3% XP, respawn em Aldara com 50% HP/MP. Monstros dão XP × clamp(1 + 0.08×(lvMob − lvPlayer), 0.3, 1.6).

## Mundo
- **Aldara** (cidade): Ancião Ravi (quests), Capitã Mira (quests), Brom (ferreiro/forja), Lyra (alquimista/caldeirão), Tobias (mercador), Quadro, guardas.
  Portais: sul → Campina, leste → Floresta, oeste → Ruínas.
- **Campina (1-10)**: slime, slime azul (ranged), javali, lobo · boss Rei Javali (investida).
- **Floresta (10-20)**: aranha, bandido, bandido arqueiro, ent · boss Chefe dos Bandidos (giro).
- **Ruínas (20-30)**: esqueleto, espectro (ranged mágico), golem · boss Dragonete Ancestral (bafo de fogo).
- Loot: materiais por campo (gel, pele, presa, erva, minério, seda, casca, insígnia, osso, essência, núcleo, escama) + raros.

## Quests (cadeia)
q01 bem-vindo (TALK) → q02 slimes → q03 gel → q04 primeira poção (CRAFT) → q05 presas → q06 lobos → q07 rei javali →
q08 floresta (TALK) → q09 seda → q10 bandidos → q11 chefe → q12 ruínas → q13 núcleos → q14 dragonete.

## Crafting / loja
Ferreiro: armas/armaduras físicas por tier (lv 5/14/24). Alquimista: poções, elixires, robes/varinhas/cajados/foices, acessórios mágicos.
Venda = 50% do preço. Tiers de equipamento: 0 (lv1) · 1 (lv8) · 2 (lv16) · 3 (lv24, materiais de boss).

## Bots
FSM: TOWN_IDLE ↔ TOWN_WALK → TRAVEL (portal) → HUNT (campo do nível) → RETURN (HP < 30% ou bolsa > 60) → SHOP (vende, recompra poções) → …
Usam skills, poções e bloqueio reativo; falam no chat (contexto cidade/caça/morte/level/viagem); respondem ao jogador.

## Visual
Toon 2 bandas (sombra azulada) + outline inverted hull + `scaling_3d` 0.5 nearest. Câmera perspectiva FOV 35, pitch 52°, yaw em 45°.
Obstáculos entre câmera e jogador ficam 72% transparentes. Chibi: cabeça ≈ 1/3 da altura. Paleta: pedra creme, telhados terracota/azul, verdes suaves.

## Fora de escopo (por enquanto)
Rede real, PvP, guildas, dungeons instanciadas, áudio.
