class_name EntityView
extends Node3D
## Visual de uma SimEntity. Lê o estado da simulação a cada frame e anima.
## Usa assets/models/<model>.glb quando existir; senão monta um placeholder low-poly "chibi".

var entity: SimEntity
var model_root: Node3D
var anim: AnimationPlayer = null
var mat: ShaderMaterial = null          # material único (hit flash)
var nameplate: Label3D
var hp_bar: Node3D
var hp_fill: MeshInstance3D
var shield_fill: MeshInstance3D
var cast_bar: Node3D
var cast_fill: MeshInstance3D
var block_shield: MeshInstance3D = null
var weapon: Node3D = null
var _bob := 0.0
var _smooth_pos: Vector3
var _last_state := -1
var _is_player := false
var _base_scale := 1.0

func setup(e: SimEntity, is_player: bool) -> void:
	entity = e
	_is_player = is_player
	name = "E%d_%s" % [e.id, e.name]
	position = e.position
	_smooth_pos = e.position
	_base_scale = e.scale
	_build_model()
	_build_ui()

# ---------------------------------------------------------------------------
func _build_model() -> void:
	model_root = Node3D.new()
	model_root.name = "Model"
	add_child(model_root)
	var model_name := ""
	if entity.class_def and entity.class_def.model != "":
		model_name = entity.class_def.model
	elif entity.monster_def and entity.monster_def.model != "":
		model_name = entity.monster_def.model
	elif entity.kind == SimEntity.Kind.NPC:
		model_name = entity.npc_data.get("model", "npc_villager")
	var path := "res://assets/models/%s.glb" % model_name
	if model_name != "" and ResourceLoader.exists(path):
		var scene: PackedScene = load(path)
		var inst := scene.instantiate()
		model_root.add_child(inst)
		anim = _find_anim(inst)
		_apply_toon_recursive(inst)
		model_root.scale = Vector3.ONE * _base_scale
		return
	_build_placeholder()

func _find_anim(n: Node) -> AnimationPlayer:
	if n is AnimationPlayer:
		return n
	for c in n.get_children():
		var r := _find_anim(c)
		if r:
			return r
	return null

func _apply_toon_recursive(n: Node) -> void:
	if n is MeshInstance3D:
		var mi := n as MeshInstance3D
		for i in range(mi.get_surface_override_material_count()):
			var base := mi.get_active_material(i)
			var col := Color(0.8, 0.8, 0.8)
			if base is BaseMaterial3D:
				col = base.albedo_color
			var tm := Materials.toon_unique(col)
			if base is BaseMaterial3D and base.albedo_texture:
				tm.set_shader_parameter("albedo_tex", base.albedo_texture)
			mi.set_surface_override_material(i, tm)
			if mat == null:
				mat = tm
	for c in n.get_children():
		_apply_toon_recursive(c)

func _mesh(m: Mesh, color: Color, unique_mat: bool = false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = m
	if unique_mat:
		if mat == null:
			mat = Materials.toon_unique(color)
		mi.material_override = mat
	else:
		mi.material_override = Materials.toon(color)
	return mi

func _build_placeholder() -> void:
	var color := Color(0.7, 0.7, 0.7)
	if entity.class_def:
		color = entity.class_def.color
	elif entity.monster_def:
		color = entity.monster_def.color
	elif entity.kind == SimEntity.Kind.NPC:
		color = entity.npc_data.get("color", Color(0.8, 0.75, 0.6))
	var s := _base_scale
	model_root.scale = Vector3.ONE * s

	if entity.monster_def:
		_build_monster(color)
		return
	# --- humanoide chibi (ToS): cabeça grande, corpo curto ---
	var body := CapsuleMesh.new()
	body.radius = 0.28
	body.height = 0.9
	var b := _mesh(body, color, true)
	b.position.y = 0.55
	model_root.add_child(b)
	var head := SphereMesh.new()
	head.radius = 0.34
	head.height = 0.68
	head.radial_segments = 10
	head.rings = 6
	var skin := Color(0.98, 0.85, 0.72)
	if entity.kind == SimEntity.Kind.SUMMON:
		skin = color
	var h := _mesh(head, skin)
	h.position.y = 1.3
	model_root.add_child(h)
	# cabelo/chapéu com a cor da classe
	var hair := SphereMesh.new()
	hair.radius = 0.36
	hair.height = 0.5
	hair.radial_segments = 10
	hair.rings = 5
	var hr := _mesh(hair, color.darkened(0.25))
	hr.position.y = 1.42
	model_root.add_child(hr)
	# olhos
	for sx in [-1.0, 1.0]:
		var eye := BoxMesh.new()
		eye.size = Vector3(0.07, 0.1, 0.03)
		var ey := MeshInstance3D.new()
		ey.mesh = eye
		ey.material_override = Materials.flat(Color(0.12, 0.1, 0.16))
		ey.position = Vector3(sx * 0.12, 1.3, 0.31)
		model_root.add_child(ey)
	# pés
	for sx in [-1.0, 1.0]:
		var foot := BoxMesh.new()
		foot.size = Vector3(0.18, 0.12, 0.3)
		var f := _mesh(foot, color.darkened(0.45))
		f.position = Vector3(sx * 0.14, 0.06, 0.05)
		f.name = "FootL" if sx < 0 else "FootR"
		model_root.add_child(f)
	_build_weapon(color)

func _build_weapon(color: Color) -> void:
	var wtype := ""
	if entity.class_def:
		var w = entity.equipment.get(ItemDef.Slot.WEAPON)
		if w:
			wtype = w.weapon_type
		elif entity.class_def.weapon_types.size() > 0:
			wtype = entity.class_def.weapon_types[0]
	if weapon:
		weapon.queue_free()
		weapon = null
	if block_shield:
		block_shield.queue_free()
		block_shield = null
	if wtype == "":
		return
	weapon = Node3D.new()
	weapon.name = "Weapon"
	weapon.position = Vector3(0.36, 0.7, 0.15)
	model_root.add_child(weapon)
	var metal := Color(0.8, 0.82, 0.88)
	var wood := Color(0.5, 0.35, 0.22)
	match wtype:
		"sword":
			var blade := _mesh(_box(0.08, 0.9, 0.03), metal); blade.position.y = 0.45; weapon.add_child(blade)
			var guard := _mesh(_box(0.3, 0.06, 0.06), Color(0.8, 0.65, 0.3)); weapon.add_child(guard)
			var grip := _mesh(_box(0.06, 0.25, 0.06), wood); grip.position.y = -0.14; weapon.add_child(grip)
		"mace":
			var shaft := _mesh(_box(0.06, 0.8, 0.06), wood); shaft.position.y = 0.3; weapon.add_child(shaft)
			var headm := SphereMesh.new(); headm.radius = 0.16; headm.height = 0.32; headm.radial_segments = 6; headm.rings = 3
			var hm := _mesh(headm, metal); hm.position.y = 0.75; weapon.add_child(hm)
		"axe2h":
			var shaft := _mesh(_box(0.07, 1.4, 0.07), wood); shaft.position.y = 0.4; weapon.add_child(shaft)
			var bl := _mesh(_box(0.5, 0.45, 0.05), metal); bl.position = Vector3(0.2, 0.95, 0); weapon.add_child(bl)
			weapon.position = Vector3(0.4, 0.5, 0.1)
		"staff":
			var shaft := _mesh(_box(0.06, 1.6, 0.06), wood); shaft.position.y = 0.5; weapon.add_child(shaft)
			var orb := SphereMesh.new(); orb.radius = 0.14; orb.height = 0.28; orb.radial_segments = 8; orb.rings = 4
			var o := MeshInstance3D.new(); o.mesh = orb; o.material_override = Materials.glow(color.lightened(0.3), 1.5); o.position.y = 1.35; weapon.add_child(o)
		"wand":
			var shaft := _mesh(_box(0.04, 0.6, 0.04), wood); shaft.position.y = 0.3; weapon.add_child(shaft)
			var orb := SphereMesh.new(); orb.radius = 0.1; orb.height = 0.2; orb.radial_segments = 8; orb.rings = 4
			var o := MeshInstance3D.new(); o.mesh = orb; o.material_override = Materials.glow(color.lightened(0.3), 1.5); o.position.y = 0.65; weapon.add_child(o)
		"bow":
			var limb := TorusMesh.new(); limb.inner_radius = 0.5; limb.outer_radius = 0.56; limb.rings = 12; limb.ring_segments = 4
			var l := _mesh(limb, wood); l.rotation.y = PI * 0.5; l.scale = Vector3(1, 1, 0.5); weapon.add_child(l)
			var str := _mesh(_box(0.01, 1.05, 0.01), Color(0.9, 0.9, 0.9)); str.position.z = -0.15; weapon.add_child(str)
			weapon.position = Vector3(-0.3, 0.75, 0.25)
		"dagger":
			var blade := _mesh(_box(0.05, 0.45, 0.02), metal); blade.position.y = 0.25; weapon.add_child(blade)
			var grip := _mesh(_box(0.05, 0.18, 0.05), wood); grip.position.y = -0.06; weapon.add_child(grip)
			var w2 := Node3D.new(); w2.position = Vector3(-0.72, 0, 0); weapon.add_child(w2)
			var blade2 := _mesh(_box(0.05, 0.45, 0.02), metal); blade2.position.y = 0.25; w2.add_child(blade2)
		"scythe":
			var shaft := _mesh(_box(0.06, 1.7, 0.06), Color(0.3, 0.25, 0.3)); shaft.position.y = 0.5; weapon.add_child(shaft)
			var bl := _mesh(_box(0.7, 0.14, 0.03), metal); bl.position = Vector3(0.3, 1.35, 0); bl.rotation.z = -0.25; weapon.add_child(bl)
	# escudo
	var off = entity.equipment.get(ItemDef.Slot.OFFHAND)
	if off and off.weapon_type == "shield":
		var sh := BoxMesh.new()
		sh.size = Vector3(0.45, 0.6, 0.08)
		block_shield = _mesh(sh, off.icon_color)
		block_shield.position = Vector3(-0.38, 0.75, 0.1)
		model_root.add_child(block_shield)

func _box(x: float, y: float, z: float) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = Vector3(x, y, z)
	return b

func _build_monster(color: Color) -> void:
	var md := entity.monster_def
	match md.shape:
		"sphere":
			var sm := SphereMesh.new(); sm.radius = 0.5; sm.height = 0.8; sm.radial_segments = 10; sm.rings = 6
			var m := _mesh(sm, color, true); m.position.y = 0.4; model_root.add_child(m)
			for sx in [-1.0, 1.0]:
				var eye := SphereMesh.new(); eye.radius = 0.08; eye.height = 0.16; eye.radial_segments = 6; eye.rings = 3
				var ey := MeshInstance3D.new(); ey.mesh = eye; ey.material_override = Materials.flat(Color(0.1, 0.1, 0.15))
				ey.position = Vector3(sx * 0.18, 0.5, 0.42); model_root.add_child(ey)
		"box":
			var body := BoxMesh.new(); body.size = Vector3(0.9, 0.6, 1.3)
			var b := _mesh(body, color, true); b.position.y = 0.55; model_root.add_child(b)
			var head := BoxMesh.new(); head.size = Vector3(0.6, 0.5, 0.6)
			var h := _mesh(head, color.lightened(0.1)); h.position = Vector3(0, 0.7, 0.85); model_root.add_child(h)
			for sx in [-1.0, 1.0]:
				for sz in [-0.4, 0.4]:
					var leg := BoxMesh.new(); leg.size = Vector3(0.2, 0.45, 0.2)
					var l := _mesh(leg, color.darkened(0.3)); l.position = Vector3(sx * 0.3, 0.22, sz); model_root.add_child(l)
			for sx in [-1.0, 1.0]:
				var eye := BoxMesh.new(); eye.size = Vector3(0.08, 0.08, 0.04)
				var ey := MeshInstance3D.new(); ey.mesh = eye; ey.material_override = Materials.flat(Color(1, 0.3, 0.2))
				ey.position = Vector3(sx * 0.18, 0.78, 1.16); model_root.add_child(ey)
		"cone":
			var cm := CylinderMesh.new(); cm.top_radius = 0.0; cm.bottom_radius = 0.5; cm.height = 1.4; cm.radial_segments = 8
			var c := _mesh(cm, color, true); c.position.y = 1.0; c.rotation.x = PI; model_root.add_child(c)
			var head := SphereMesh.new(); head.radius = 0.35; head.height = 0.7; head.radial_segments = 8; head.rings = 4
			var h := _mesh(head, color.lightened(0.2)); h.position.y = 1.75; model_root.add_child(h)
			for sx in [-1.0, 1.0]:
				var eye := BoxMesh.new(); eye.size = Vector3(0.08, 0.12, 0.04)
				var ey := MeshInstance3D.new(); ey.mesh = eye; ey.material_override = Materials.flat(Color(0.2, 0.1, 0.3))
				ey.position = Vector3(sx * 0.12, 1.78, 0.33); model_root.add_child(ey)
		_:  # capsule (bandidos, esqueletos)
			var body := CapsuleMesh.new(); body.radius = 0.3; body.height = 1.0
			var b := _mesh(body, color, true); b.position.y = 0.6; model_root.add_child(b)
			var head := SphereMesh.new(); head.radius = 0.3; head.height = 0.6; head.radial_segments = 8; head.rings = 4
			var h := _mesh(head, color.lightened(0.15)); h.position.y = 1.35; model_root.add_child(h)
			for sx in [-1.0, 1.0]:
				var eye := BoxMesh.new(); eye.size = Vector3(0.07, 0.09, 0.03)
				var ey := MeshInstance3D.new(); ey.mesh = eye; ey.material_override = Materials.flat(Color(0.9, 0.2, 0.2))
				ey.position = Vector3(sx * 0.11, 1.37, 0.28); model_root.add_child(ey)
			var wpn := _mesh(_box(0.07, 0.8, 0.04), Color(0.75, 0.75, 0.8)); wpn.position = Vector3(0.38, 0.9, 0.1); model_root.add_child(wpn)
	if md.is_boss:
		var crown := CylinderMesh.new(); crown.top_radius = 0.3; crown.bottom_radius = 0.22; crown.height = 0.25; crown.radial_segments = 5
		var c := MeshInstance3D.new(); c.mesh = crown; c.material_override = Materials.glow(Color(1, 0.85, 0.3), 1.2)
		c.position.y = 1.0 if md.shape == "box" else 1.75
		model_root.add_child(c)

# ---------------------------------------------------------------------------
func _build_ui() -> void:
	var top := 1.95 * _base_scale
	if entity.monster_def and entity.monster_def.shape in ["sphere", "box"]:
		top = 1.4 * _base_scale
	nameplate = Label3D.new()
	nameplate.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	nameplate.no_depth_test = true
	nameplate.font_size = 26
	nameplate.pixel_size = 0.006
	nameplate.outline_size = 7
	nameplate.position.y = top + 0.45
	nameplate.fixed_size = false
	add_child(nameplate)
	_refresh_nameplate()

	if entity.kind != SimEntity.Kind.NPC:
		hp_bar = Node3D.new()
		hp_bar.position.y = top + 0.2
		add_child(hp_bar)
		var bg := _quad(1.0, 0.09, Color(0.1, 0.08, 0.12, 0.85))
		hp_bar.add_child(bg)
		var fill_col := Color(0.35, 0.85, 0.4)
		if entity.kind == SimEntity.Kind.MONSTER:
			fill_col = Color(0.9, 0.3, 0.3)
		elif entity.kind == SimEntity.Kind.BOT:
			fill_col = Color(0.4, 0.75, 0.95)
		hp_fill = _quad(1.0, 0.07, fill_col)
		hp_fill.position.z = 0.001
		hp_bar.add_child(hp_fill)
		shield_fill = _quad(1.0, 0.03, Color(0.95, 0.9, 0.5))
		shield_fill.position = Vector3(0, 0.05, 0.002)
		hp_bar.add_child(shield_fill)
		cast_bar = Node3D.new()
		cast_bar.position.y = top + 0.08
		cast_bar.visible = false
		add_child(cast_bar)
		cast_bar.add_child(_quad(0.8, 0.05, Color(0.1, 0.08, 0.12, 0.85)))
		cast_fill = _quad(0.8, 0.035, Color(1, 0.85, 0.4))
		cast_fill.position.z = 0.001
		cast_bar.add_child(cast_fill)

func _quad(w: float, h: float, color: Color) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(w, h)
	mi.mesh = q
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.no_depth_test = true
	m.render_priority = 2
	mi.material_override = m
	return mi

func _refresh_nameplate() -> void:
	var txt := entity.name
	var col := Color.WHITE
	match entity.kind:
		SimEntity.Kind.PLAYER:
			col = Color(1, 0.95, 0.6)
			txt = "%s\n%s" % [entity.name, entity.display_title()]
		SimEntity.Kind.BOT:
			col = Color(0.75, 0.9, 1.0)
			txt = "%s\n%s" % [entity.name, entity.display_title()]
		SimEntity.Kind.MONSTER:
			col = Color(1, 0.6, 0.6) if not entity.monster_def.is_boss else Color(1, 0.8, 0.3)
			txt = "%s %s" % [entity.name, entity.display_title()]
		SimEntity.Kind.NPC:
			col = Color(0.7, 1.0, 0.75)
			txt = "[%s]\n%s" % [_npc_role_label(), entity.name]
		SimEntity.Kind.SUMMON:
			col = Color(0.7, 0.95, 0.85)
	nameplate.text = txt
	nameplate.modulate = col

func _npc_role_label() -> String:
	match entity.npc_data.get("role", ""):
		"quest": return "Quest"
		"smith": return "Ferreiro"
		"alchemy": return "Alquimista"
		"merchant": return "Mercador"
		"board": return "Quadro"
		"guard": return "Guarda"
	return "NPC"

func refresh_equipment() -> void:
	if anim == null and entity.class_def:
		_build_weapon(entity.class_def.color)
	_refresh_nameplate()

# ---------------------------------------------------------------------------
func _process(delta: float) -> void:
	if entity == null:
		return
	# posição suavizada (a sim roda a 60Hz; interpola um pouco)
	_smooth_pos = _smooth_pos.lerp(entity.position, minf(1.0, delta * 28.0))
	position = _smooth_pos
	var target_rot := entity.facing
	if entity.kind != SimEntity.Kind.PLAYER and entity.kind != SimEntity.Kind.BOT:
		target_rot = entity.facing
	model_root.rotation.y = lerp_angle(model_root.rotation.y, target_rot, minf(1.0, delta * 18.0))
	_animate(delta)
	_update_bars()
	if mat:
		mat.set_shader_parameter("flash", 1.0 if entity.hit_flash > 0.0 else 0.0)
	if entity.level != int(nameplate.get_meta("lv", -1)):
		nameplate.set_meta("lv", entity.level)
		_refresh_nameplate()

func _update_bars() -> void:
	if hp_bar == null:
		return
	var ratio := clampf(entity.hp / maxf(1.0, entity.stats.max_hp), 0.0, 1.0)
	hp_fill.scale.x = maxf(0.001, ratio)
	hp_fill.position.x = -(1.0 - ratio) * 0.5
	var sr := clampf(entity.shield_hp / maxf(1.0, entity.stats.max_hp), 0.0, 1.0)
	shield_fill.visible = sr > 0.0
	shield_fill.scale.x = maxf(0.001, sr)
	shield_fill.position.x = -(1.0 - sr) * 0.5
	hp_bar.visible = entity.is_alive() and (entity.kind != SimEntity.Kind.MONSTER or ratio < 1.0 or entity.aggro_target >= 0)
	var casting := entity.state == SimEntity.State.CASTING and entity.current_skill != null and entity.current_skill.startup > 0.2
	cast_bar.visible = casting and entity.skill_phase == "startup"
	if cast_bar.visible:
		var r := clampf(entity.state_time / entity.current_skill.startup, 0.0, 1.0)
		cast_fill.scale.x = maxf(0.001, r)
		cast_fill.position.x = -(1.0 - r) * 0.4

func _animate(delta: float) -> void:
	var st := entity.state
	if anim:
		_animate_glb(st)
		return
	# --- animação procedural do placeholder ---
	var speed := entity.velocity.length()
	var moving := speed > 0.1 and st in [SimEntity.State.MOVING, SimEntity.State.BLOCKING]
	if moving:
		_bob += delta * 14.0
	else:
		_bob = lerpf(_bob, round(_bob / PI) * PI, minf(1.0, delta * 10.0))
	var y := absf(sin(_bob)) * 0.08 if moving else 0.0
	var tilt := 0.0
	var lunge := 0.0
	var scale_y := 1.0
	match st:
		SimEntity.State.CASTING:
			var s := entity.current_skill
			if s:
				var t := entity.state_time
				if t < s.startup:
					tilt = -0.25 * (t / s.startup)                 # puxa pra trás
					scale_y = 1.0 + 0.06 * (t / s.startup)
				elif t < s.startup + s.active + 0.08:
					tilt = 0.45                                     # avança
					lunge = 0.25
				else:
					var r := (t - s.startup - s.active) / maxf(0.01, s.recovery)
					tilt = 0.45 * (1.0 - r)
					lunge = 0.25 * (1.0 - r)
				if s.kind == SkillDef.Kind.MAGICAL or s.kind == SkillDef.Kind.HEAL or s.kind == SkillDef.Kind.SUMMON:
					tilt *= 0.3
					y += 0.1 * sin(entity.state_time * 20.0)
		SimEntity.State.BLOCKING:
			tilt = 0.12
		SimEntity.State.DASHING:
			tilt = 0.5
			scale_y = 0.85
		SimEntity.State.STUNNED:
			tilt = 0.15 * sin(entity.state_time * 25.0)
		SimEntity.State.DEAD:
			var d := clampf(entity.dead_time / 0.5, 0.0, 1.0)
			model_root.rotation.x = lerpf(model_root.rotation.x, -PI * 0.5, minf(1.0, delta * 8.0))
			model_root.position.y = -d * 0.4
			model_root.scale = Vector3.ONE * _base_scale
			return
	model_root.rotation.x = lerpf(model_root.rotation.x, tilt, minf(1.0, delta * 22.0))
	model_root.position.y = lerpf(model_root.position.y, y, minf(1.0, delta * 20.0))
	model_root.position.z = lerpf(model_root.position.z, 0.0, minf(1.0, delta * 20.0))
	model_root.scale = Vector3(1.0, scale_y, 1.0) * _base_scale
	if block_shield:
		block_shield.position.x = lerpf(block_shield.position.x, -0.05 if entity.is_blocking else -0.38, minf(1.0, delta * 15.0))
		block_shield.position.z = lerpf(block_shield.position.z, 0.45 if entity.is_blocking else 0.1, minf(1.0, delta * 15.0))
	if weapon:
		weapon.rotation.x = lerpf(weapon.rotation.x, -1.2 if lunge > 0.0 else 0.0, minf(1.0, delta * 25.0))
	var fl := model_root.get_node_or_null("FootL")
	var fr := model_root.get_node_or_null("FootR")
	if fl and fr:
		fl.position.z = sin(_bob) * 0.18 if moving else lerpf(fl.position.z, 0.05, minf(1.0, delta * 10.0))
		fr.position.z = -sin(_bob) * 0.18 if moving else lerpf(fr.position.z, 0.05, minf(1.0, delta * 10.0))

func _animate_glb(st: int) -> void:
	var want := "idle"
	match st:
		SimEntity.State.MOVING: want = "run"
		SimEntity.State.BLOCKING: want = "block" if anim.has_animation("block") else "idle"
		SimEntity.State.CASTING:
			var s := entity.current_skill
			want = "cast" if (s and s.kind in [SkillDef.Kind.MAGICAL, SkillDef.Kind.HEAL, SkillDef.Kind.SUMMON]) else "attack"
		SimEntity.State.DASHING: want = "run"
		SimEntity.State.STUNNED: want = "hit" if anim.has_animation("hit") else "idle"
		SimEntity.State.DEAD: want = "die"
	if not anim.has_animation(want):
		want = "idle" if anim.has_animation("idle") else ""
	if want != "" and anim.current_animation != want:
		anim.play(want, 0.1)
	if st == SimEntity.State.DEAD and want == "die" and anim.current_animation_position >= anim.current_animation_length - 0.01:
		anim.pause()
