class_name FxManager
extends Node3D
## Efeitos visuais lidos do EventBus: dano flutuante, hit-stop, anéis de skill, projéteis, loot, retículo.

var camera: CameraRig
var main                          # Main (para saber o mapa atual)
var _projectiles: Dictionary = {}   # id -> Node3D
var _loot_nodes: Array = []
var _hit_stop_left := 0.0
var reticle: MeshInstance3D
var dir_reticle: MeshInstance3D
var cone_reticle: MeshInstance3D
var _reticle_shader: Shader

func _ready() -> void:
	_reticle_shader = load("res://shaders/ground_reticle.gdshader")
	reticle = _make_reticle(0)
	dir_reticle = _make_reticle(1)
	cone_reticle = _make_reticle(2)
	Events.damage_dealt.connect(_on_damage)
	Events.healed.connect(_on_heal)
	Events.hit_stop.connect(_on_hit_stop)
	Events.skill_effect.connect(_on_skill_effect)
	Events.projectile_spawned.connect(_on_projectile)
	Events.projectile_removed.connect(_on_projectile_removed)
	Events.loot_dropped.connect(_on_loot)
	Events.level_up.connect(_on_level_up)
	Events.blocked_hit.connect(_on_block)
	Events.skill_cast.connect(_on_skill_cast)
	Events.entity_died.connect(_on_died)

func _make_reticle(shape: int) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var q := PlaneMesh.new()
	q.size = Vector2(2, 2)
	mi.mesh = q
	var m := ShaderMaterial.new()
	m.shader = _reticle_shader
	m.set_shader_parameter("shape", shape)
	mi.material_override = m
	mi.visible = false
	mi.position.y = 0.03
	add_child(mi)
	return mi

# ---------------------------------------------------------------------------
func _process(delta: float) -> void:
	if _hit_stop_left > 0.0:
		_hit_stop_left -= delta / maxf(Engine.time_scale, 0.01)
		if _hit_stop_left <= 0.0:
			Engine.time_scale = 1.0
	_update_projectiles(delta)
	_update_reticle()
	_update_loot(delta)

## Retículo de mira estilo MOBA: mostra alcance/forma da skill cujo número está sendo segurado,
## senão um pequeno cursor no chão.
func _update_reticle() -> void:
	var p: SimEntity = Sim.player
	if p == null or main == null or main.controller == null:
		return
	var aim: Vector3 = main.controller.aim_point
	var held: SkillDef = null
	for i in range(6):
		if Input.is_action_pressed("skill_%d" % (i + 1)) and i < p.skills.size():
			held = p.skills[i]
	if held == null and p.state == SimEntity.State.CASTING and p.current_skill and p.current_skill_slot >= 0:
		held = p.current_skill
	reticle.visible = false
	dir_reticle.visible = false
	cone_reticle.visible = false
	if held == null:
		reticle.visible = true
		reticle.position = Vector3(aim.x, 0.03, aim.z)
		reticle.scale = Vector3(0.35, 1, 0.35)
		reticle.material_override.set_shader_parameter("color", Color(1, 1, 1, 0.5))
		return
	var col := held.icon_color
	col.a = 0.85
	match held.target:
		SkillDef.Target.GROUND:
			var c := Combat.clamp_aim(p, aim, held.range)
			reticle.visible = true
			reticle.position = Vector3(c.x, 0.03, c.z)
			reticle.scale = Vector3(held.radius, 1, held.radius)
			reticle.material_override.set_shader_parameter("color", col)
		SkillDef.Target.DIRECTION:
			dir_reticle.visible = true
			var f := p.forward()
			dir_reticle.position = p.position + f * held.range * 0.5 + Vector3(0, 0.03, 0)
			dir_reticle.rotation.y = p.facing
			dir_reticle.scale = Vector3(maxf(held.radius, 0.35), 1, held.range * 0.5)
			dir_reticle.material_override.set_shader_parameter("color", col)
		SkillDef.Target.CONE:
			cone_reticle.visible = true
			cone_reticle.position = p.position + Vector3(0, 0.03, 0)
			cone_reticle.rotation.y = p.facing + PI
			cone_reticle.scale = Vector3(held.radius, 1, held.radius)
			cone_reticle.material_override.set_shader_parameter("color", col)
		SkillDef.Target.SELF:
			reticle.visible = true
			reticle.position = p.position + Vector3(0, 0.03, 0)
			reticle.scale = Vector3(maxf(held.radius, 1.0), 1, maxf(held.radius, 1.0))
			reticle.material_override.set_shader_parameter("color", col)
		SkillDef.Target.TARGET:
			reticle.visible = true
			reticle.position = Vector3(aim.x, 0.03, aim.z)
			reticle.scale = Vector3(0.9, 1, 0.9)
			reticle.material_override.set_shader_parameter("color", col)

# ---------------------------------------------------------------------------
func _on_damage(attacker_id: int, target_id: int, amount: int, crit: bool, blocked: bool, kind: String) -> void:
	var t: SimEntity = Sim.get_entity(target_id)
	if t == null or t.map_id != main.current_map_id:
		return
	var col := Color(1, 0.95, 0.85)
	if kind == "magical":
		col = Color(0.7, 0.8, 1)
	if kind == "dot":
		col = Color(0.6, 0.95, 0.5)
	if t == Sim.player:
		col = Color(1, 0.4, 0.4)
	var txt := str(amount)
	var size := 1.0
	if crit:
		txt += "!"
		size = 1.6
		col = Color(1, 0.75, 0.2) if t != Sim.player else Color(1, 0.3, 0.3)
	if blocked:
		txt = "⛨ " + txt
		col = Color(0.75, 0.8, 1)
	_float_text(t.position + Vector3(randf_range(-0.3, 0.3), 1.6 * t.scale, 0), txt, col, size)
	# flash na câmera quando o jogador leva dano forte
	if t == Sim.player and amount > t.stats.max_hp * 0.12:
		camera.add_shake(0.12)

func _on_heal(_src: int, target_id: int, amount: int) -> void:
	var t: SimEntity = Sim.get_entity(target_id)
	if t and t.map_id == main.current_map_id and amount > 0:
		_float_text(t.position + Vector3(0, 1.7 * t.scale, 0), "+%d" % amount, Color(0.5, 1, 0.5), 1.1)
		_ring(t.position, 0.9, Color(0.5, 1, 0.5), 0.5)

func _on_block(target_id: int) -> void:
	var t: SimEntity = Sim.get_entity(target_id)
	if t and t.map_id == main.current_map_id:
		_ring(t.position + Vector3(0, 0.8, 0), 0.6, Color(0.7, 0.8, 1), 0.25, true)

func _on_hit_stop(frames: int) -> void:
	Engine.time_scale = 0.05
	_hit_stop_left = frames / 60.0
	camera.add_shake(0.03 * frames)

func _on_skill_effect(skill_id: String, origin: Vector3, aim: Vector3, radius: float) -> void:
	var s: SkillDef = GameData.skills.get(skill_id)
	var col := s.icon_color if s else Color.WHITE
	if s == null:
		return
	match s.target:
		SkillDef.Target.GROUND:
			_ring(aim, radius, col, 0.45)
			_pillar(aim, radius * 0.5, col, 0.35)
		SkillDef.Target.SELF:
			_ring(origin, maxf(radius, 1.0), col, 0.4)
		SkillDef.Target.CONE:
			_arc(origin, radius, col, 0.3)
		SkillDef.Target.DIRECTION:
			if s.projectile_speed <= 0.0:
				_beam(origin, aim, s.range, col, 0.2)
		SkillDef.Target.TARGET:
			_ring(aim, 0.8, col, 0.3)

func _on_skill_cast(entity_id: int, skill_id: String, phase: String) -> void:
	if phase != "startup":
		return
	var e: SimEntity = Sim.get_entity(entity_id)
	if e == null or e.map_id != main.current_map_id or skill_id == "dash":
		return
	var s: SkillDef = GameData.skills.get(skill_id)
	if s and s.startup >= 0.3:
		_ring(e.position, 0.7, s.icon_color, s.startup, false, true)

func _on_died(entity_id: int, _killer: int) -> void:
	var e: SimEntity = Sim.get_entity(entity_id)
	if e and e.map_id == main.current_map_id:
		_ring(e.position, 0.8 * e.scale, Color(0.3, 0.25, 0.35), 0.6)

func _on_level_up(entity_id: int, new_level: int) -> void:
	var e: SimEntity = Sim.get_entity(entity_id)
	if e and e.map_id == main.current_map_id:
		_float_text(e.position + Vector3(0, 2.2, 0), "LEVEL %d!" % new_level, Color(1, 0.9, 0.3), 1.8)
		_pillar(e.position, 0.8, Color(1, 0.9, 0.3), 1.2)

# ---------------------------------------------------------------------------
func _float_text(pos: Vector3, text: String, color: Color, size: float = 1.0) -> void:
	var l := Label3D.new()
	l.text = text
	l.modulate = color
	l.outline_size = 14
	l.font_size = int(44 * size)
	l.pixel_size = 0.012
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	l.position = pos
	add_child(l)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "position", pos + Vector3(randf_range(-0.4, 0.4), 1.4, 0), 0.9).set_ease(Tween.EASE_OUT)
	tw.tween_property(l, "modulate:a", 0.0, 0.9).set_delay(0.4)
	tw.tween_property(l, "scale", Vector3.ONE * 0.6, 0.9).set_delay(0.3)
	tw.chain().tween_callback(l.queue_free)

func _ring(pos: Vector3, radius: float, color: Color, duration: float, raised: bool = false, shrink: bool = false) -> void:
	var mi := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.8
	tm.outer_radius = 1.0
	tm.rings = 20
	tm.ring_segments = 5
	mi.mesh = tm
	mi.material_override = Materials.glow(color, 2.0)
	mi.position = pos + Vector3(0, 0.08 if not raised else 0.0, 0)
	mi.scale = Vector3.ONE * (0.2 if not shrink else radius * 2.0)
	add_child(mi)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(mi, "scale", Vector3(radius, 0.4, radius) if not shrink else Vector3.ONE * 0.3, duration).set_ease(Tween.EASE_OUT)
	tw.tween_property(mi.material_override, "albedo_color:a", 0.0, duration)
	tw.chain().tween_callback(mi.queue_free)

func _pillar(pos: Vector3, radius: float, color: Color, duration: float) -> void:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = 4.0
	cm.radial_segments = 10
	mi.mesh = cm
	var m := Materials.glow(color, 1.5)
	m.albedo_color.a = 0.55
	mi.material_override = m
	mi.position = pos + Vector3(0, 2.0, 0)
	add_child(mi)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(mi, "scale", Vector3(0.1, 1.3, 0.1), duration).set_ease(Tween.EASE_IN)
	tw.tween_property(m, "albedo_color:a", 0.0, duration)
	tw.chain().tween_callback(mi.queue_free)

func _arc(pos: Vector3, radius: float, color: Color, duration: float) -> void:
	var p: SimEntity = Sim.player
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = 0.08
	cm.radial_segments = 14
	mi.mesh = cm
	var m := Materials.glow(color, 1.5)
	m.albedo_color.a = 0.35
	mi.material_override = m
	mi.position = pos + Vector3(0, 0.3, 0)
	mi.scale = Vector3(0.3, 1, 0.3)
	add_child(mi)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(mi, "scale", Vector3(1, 1, 1), duration).set_ease(Tween.EASE_OUT)
	tw.tween_property(m, "albedo_color:a", 0.0, duration)
	tw.chain().tween_callback(mi.queue_free)

func _beam(origin: Vector3, aim: Vector3, length: float, color: Color, duration: float) -> void:
	var d := aim - origin
	d.y = 0.0
	if d.length() < 0.01:
		return
	var dir := d.normalized()
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.35, 0.35, length)
	mi.mesh = bm
	var m := Materials.glow(color, 2.5)
	m.albedo_color.a = 0.8
	mi.material_override = m
	mi.position = origin + dir * length * 0.5 + Vector3(0, 0.9, 0)
	mi.rotation.y = atan2(dir.x, dir.z)
	add_child(mi)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(mi, "scale", Vector3(0.1, 0.1, 1.0), duration)
	tw.tween_property(m, "albedo_color:a", 0.0, duration)
	tw.chain().tween_callback(mi.queue_free)

# ---------------------------------------------------------------------------
func _on_projectile(p: SimProjectile) -> void:
	if p.map_id != main.current_map_id:
		return
	var n := Node3D.new()
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = maxf(p.radius * 0.6, 0.15)
	sm.height = sm.radius * 2.0
	sm.radial_segments = 8
	sm.rings = 4
	mi.mesh = sm
	mi.material_override = Materials.glow(p.color, 2.5)
	n.add_child(mi)
	var trail := MeshInstance3D.new()
	var tm := CylinderMesh.new()
	tm.top_radius = sm.radius * 0.6
	tm.bottom_radius = 0.0
	tm.height = 1.2
	tm.radial_segments = 6
	trail.mesh = tm
	trail.rotation.x = PI * 0.5
	trail.position.z = 0.6
	var trm := Materials.glow(p.color, 1.5)
	trm.albedo_color.a = 0.5
	trail.material_override = trm
	n.add_child(trail)
	var light := OmniLight3D.new()
	light.light_color = p.color
	light.light_energy = 1.0
	light.omni_range = 3.0
	n.add_child(light)
	n.position = p.position
	n.rotation.y = atan2(p.direction.x, p.direction.z)
	add_child(n)
	_projectiles[p.id] = n

func _on_projectile_removed(id: int) -> void:
	if _projectiles.has(id):
		var n: Node3D = _projectiles[id]
		_projectiles.erase(id)
		_ring(n.position - Vector3(0, 0.8, 0), 0.6, Color(1, 1, 1, 0.8), 0.25)
		n.queue_free()

func _update_projectiles(_delta: float) -> void:
	if main == null or not Sim.maps.has(main.current_map_id):
		return
	for p in Sim.maps[main.current_map_id]["projectiles"]:
		if _projectiles.has(p.id):
			_projectiles[p.id].position = p.position

func clear_map_fx() -> void:
	for id in _projectiles:
		_projectiles[id].queue_free()
	_projectiles.clear()
	for l in _loot_nodes:
		l.queue_free()
	_loot_nodes.clear()

# ---------------------------------------------------------------------------
func _on_loot(map_id: String, position: Vector3, item_id: String, count: int) -> void:
	if map_id != main.current_map_id:
		return
	_spawn_loot_node(position, item_id)

func _spawn_loot_node(position: Vector3, item_id: String) -> void:
	var n := Node3D.new()
	n.position = position
	n.set_meta("item", item_id)
	n.set_meta("origin", position)
	var mi := MeshInstance3D.new()
	var color := Color(1, 0.85, 0.3)
	if item_id != "gold":
		var it: ItemDef = GameData.items.get(item_id)
		if it:
			color = it.icon_color
	if item_id == "gold":
		var cm := CylinderMesh.new()
		cm.top_radius = 0.18; cm.bottom_radius = 0.18; cm.height = 0.06; cm.radial_segments = 8
		mi.mesh = cm
	else:
		var bm := BoxMesh.new()
		bm.size = Vector3(0.35, 0.35, 0.35)
		mi.mesh = bm
	mi.material_override = Materials.glow(color, 1.2)
	mi.position.y = 0.3
	n.add_child(mi)
	var l := OmniLight3D.new()
	l.light_color = color
	l.light_energy = 0.6
	l.omni_range = 2.0
	l.position.y = 0.4
	n.add_child(l)
	add_child(n)
	_loot_nodes.append(n)

func _update_loot(delta: float) -> void:
	if main == null or not Sim.maps.has(main.current_map_id):
		return
	var loot: Array = Sim.maps[main.current_map_id]["loot"]
	# remove nós cujo loot sumiu (pego ou expirou)
	for n in _loot_nodes.duplicate():
		var found := false
		var origin: Vector3 = n.get_meta("origin")
		for l in loot:
			if l["pos"].distance_to(origin) < 0.01 and l["item"] == n.get_meta("item"):
				found = true
				break
		if not found:
			_loot_nodes.erase(n)
			n.queue_free()
		else:
			n.get_child(0).rotation.y += delta * 2.0
			n.get_child(0).position.y = 0.3 + sin(Time.get_ticks_msec() / 300.0 + origin.x) * 0.08

func sync_loot_for_map() -> void:
	clear_map_fx()
	if not Sim.maps.has(main.current_map_id):
		return
	for l in Sim.maps[main.current_map_id]["loot"]:
		_spawn_loot_node(l["pos"], l["item"])
	for p in Sim.maps[main.current_map_id]["projectiles"]:
		_on_projectile(p)
