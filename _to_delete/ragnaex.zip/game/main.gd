extends Node
## Main: liga simulação (Sim) e apresentação. Cria o mundo visual do mapa atual,
## views de entidades, câmera, controle do jogador, FX e UI.

var world_root: Node3D
var map_node: Node3D = null
var views_root: Node3D
var views: Dictionary = {}       # entity_id -> EntityView
var camera: CameraRig
var controller: PlayerController
var fx: FxManager
var hud                          # Hud (CanvasLayer)
var current_map_id: String = ""
var started := false
var _autosave := 0.0
var _smoke_test := false
var _smoke_t := 0.0
var _shot_path := ""
var _shot_done := false

func _ready() -> void:
	world_root = Node3D.new()
	world_root.name = "World"
	add_child(world_root)
	views_root = Node3D.new()
	views_root.name = "Entities"
	world_root.add_child(views_root)
	camera = CameraRig.new()
	camera.name = "CameraRig"
	world_root.add_child(camera)
	fx = FxManager.new()
	fx.name = "FX"
	fx.camera = camera
	fx.main = self
	world_root.add_child(fx)
	controller = PlayerController.new()
	controller.name = "PlayerController"
	controller.camera = camera
	controller.set_physics_process(false)
	add_child(controller)
	hud = load("res://game/ui/hud.gd").new()
	hud.main = self
	add_child(hud)

	# carrega todos os mapas na simulação (o "servidor" simula tudo)
	for mid in GameData.maps:
		Sim.load_map(GameData.maps[mid])
	_populate_bots()

	Events.entity_spawned.connect(_on_spawned)
	Events.entity_despawned.connect(_on_despawned)
	Events.entity_changed_map.connect(_on_changed_map)
	Events.equipment_changed.connect(_on_equipment_changed)

	# mostra a cidade de fundo enquanto escolhe a classe
	_show_map(GameData.town_map_id())
	camera.global_position = Vector3(0, 0, 4)
	# smoke test headless:  godot --headless --path . -- --autostart=berserker [--screenshot=/tmp/x.png]
	var autostart := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--screenshot="):
			_shot_path = arg.get_slice("=", 1)
		if arg.begins_with("--autostart"):
			autostart = arg.get_slice("=", 1) if "=" in arg else "paladin"
	if autostart != "":
		start_game(GameData.classes.get(autostart, GameData.classes["paladin"]), "Smoke", false)
		_smoke_test = true
		return
	hud.show_class_select(SaveSystem.has_save())

func _populate_bots() -> void:
	var names: Array = GameData.bot_names.duplicate()
	names.shuffle()
	var classes: Array = GameData.class_list()
	var k := 0
	for mid in GameData.maps:
		var md: MapDef = GameData.maps[mid]
		for i in range(md.bot_population):
			var cls: ClassDef = classes[randi() % classes.size()]
			var lv := randi_range(md.level_range.x, md.level_range.y)
			if md.is_town:
				lv = randi_range(1, 30)
			var pos := Sim.random_walkable(md, md.spawn_point if not md.is_town else Vector3.ZERO, 10.0)
			Sim.spawn_bot(cls, names[k % names.size()], mid, pos, lv)
			k += 1

## Chamado pela UI de seleção de classe
func start_game(cls: ClassDef, char_name: String, load_save: bool) -> void:
	var data := SaveSystem.load_data() if load_save else {}
	var map_id := GameData.town_map_id()
	if load_save and data.has("class"):
		cls = GameData.classes.get(data["class"], cls)
		char_name = data.get("name", char_name)
		if GameData.maps.has(data.get("map", "")):
			map_id = data["map"]
	var p := Sim.spawn_player(cls, char_name, GameData.town_map_id())
	if load_save and data.size() > 0:
		SaveSystem.apply_to(p, data)
		if map_id != p.map_id:
			var pos: Array = data.get("pos", [0, 0])
			Sim._change_map(p, map_id, Vector3(float(pos[0]), 0, float(pos[1])))
		else:
			var pos: Array = data.get("pos", [0, 8])
			p.position = Vector3(float(pos[0]), 0, float(pos[1]))
	_show_map(p.map_id)
	controller.set_physics_process(true)
	Sim.running = true
	started = true
	hud.on_game_started()
	Events.notification.emit("Bem-vindo a Aldara, %s! Fale com o Ancião Ravi (Espaço) para começar." % char_name)
	Events.chat_message.emit("Sistema", "%s entrou no jogo." % char_name, "system")

func _process(delta: float) -> void:
	if not started:
		return
	if _smoke_test:
		_smoke(delta)
	_fade_occluders(delta)
	_autosave += delta
	if _autosave > 60.0:
		_autosave = 0.0
		SaveSystem.save_player(Sim.player)

# ---------------------------------------------------------------------------
## Obstáculos altos entre a câmera e o jogador ficam translúcidos (estilo ToS/RO).
func _fade_occluders(delta: float) -> void:
	if map_node == null or not map_node.has_meta("occluders") or not views.has(Sim.player.id):
		return
	var pv: Node3D = views[Sim.player.id]
	var ppos := pv.global_position + Vector3(0, 0.8, 0)
	var cpos := camera.cam.global_position
	var seg := ppos - cpos
	var seg_len := seg.length()
	var seg_dir := seg / maxf(seg_len, 0.01)
	for n in map_node.get_meta("occluders"):
		var node: Node3D = n
		var h: float = node.get_meta("occluder_h")
		var center := node.global_position + Vector3(0, h * 0.5, 0)
		var rel := center - cpos
		var along := rel.dot(seg_dir)
		var want := 0.0
		if along > 0.0 and along < seg_len + 1.0:
			var perp := (rel - seg_dir * along).length()
			if perp < 1.6 + h * 0.25:
				want = 0.72
		for c in node.get_children():
			if c is GeometryInstance3D:
				c.transparency = lerpf(c.transparency, want, minf(1.0, delta * 10.0))

func _show_map(map_id: String) -> void:
	if map_node:
		map_node.queue_free()
		map_node = null
	for id in views.keys():
		views[id].queue_free()
	views.clear()
	current_map_id = map_id
	var def: MapDef = GameData.maps[map_id]
	map_node = MapBuilder.build(def)
	world_root.add_child(map_node)
	for e in Sim.map_entities(map_id):
		_create_view(e)
	fx.sync_loot_for_map()
	if hud:
		hud.on_map_changed(def)

func _create_view(e: SimEntity) -> void:
	if views.has(e.id):
		return
	var v := EntityView.new()
	v.setup(e, e == Sim.player)
	views_root.add_child(v)
	views[e.id] = v
	if e == Sim.player:
		camera.target = v
		camera.global_position = v.global_position

func _on_spawned(e: SimEntity) -> void:
	if e.map_id == current_map_id:
		_create_view(e)

func _on_despawned(id: int) -> void:
	if views.has(id):
		views[id].queue_free()
		views.erase(id)

func _on_changed_map(id: int, map_id: String) -> void:
	var e: SimEntity = Sim.get_entity(id)
	if e == Sim.player:
		_show_map(map_id)
		Events.notification.emit("— %s —" % GameData.maps[map_id].name)
		return
	if map_id == current_map_id:
		_create_view(e)
	else:
		_on_despawned(id)

func _on_equipment_changed(id: int) -> void:
	if views.has(id):
		views[id].refresh_equipment()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST and started:
		SaveSystem.save_player(Sim.player)

## Smoke test: anda, ataca, usa skills, abre janelas e troca de mapa sozinho, depois sai.
var _smoke_stage := 0
func _smoke(delta: float) -> void:
	_smoke_t += delta
	var p := Sim.player
	var cmd := InputCommand.new()
	cmd.aim = p.position + p.forward() * 3.0
	match _smoke_stage:
		0:
			cmd.move = Vector2(0, 1)
			if _smoke_t > 2.0: _smoke_stage = 1
		1:
			cmd.attack = true
			cmd.skill_slot = int(_smoke_t * 4.0) % 6
			if _smoke_t > 4.0: _smoke_stage = 2
		2:
			cmd.dash = true
			cmd.potion_slot = 0
			hud.windows_script.toggle("inventory")
			hud.windows_script.toggle("character")
			hud.windows_script.toggle("skills")
			hud.windows_script.toggle("quests")
			hud.windows_script.close_all()
			hud.npc_ui.open("elder")
			hud.npc_ui.mode = "shop"; hud.npc_ui._rebuild()
			hud.npc_ui.mode = "craft"; hud.npc_ui._rebuild()
			hud.npc_ui.close()
			if _shot_path != "":
				hud.windows_script.toggle("skills")
				_smoke_stage = 20
			else:
				_smoke_stage = 3
		20:
			if _smoke_t > 4.6:
				get_viewport().get_texture().get_image().save_png(_shot_path.replace(".png", "_skills.png"))
				hud.windows_script.close_all()
				hud.npc_ui.open("smith")
				hud.npc_ui.mode = "craft"; hud.npc_ui._rebuild()
				_smoke_stage = 21
		21:
			if _smoke_t > 5.2:
				get_viewport().get_texture().get_image().save_png(_shot_path.replace(".png", "_craft.png"))
				hud.npc_ui.close()
				_smoke_stage = 3
		3:
			if _shot_path != "":
				var img := get_viewport().get_texture().get_image()
				img.save_png(_shot_path.replace(".png", "_town.png"))
			Sim._change_map(p, "field_meadows", Vector3(6, 0, -36))
			_smoke_stage = 4
			_smoke_t = 0.0
		4:
			if _smoke_t > 0.3 and not has_meta("smoke_mobs"):
				set_meta("smoke_mobs", true)
				for i in range(3):
					Sim.spawn_monster(GameData.monsters["slime"], p.map_id, p.position + Vector3(2.5 + i * 0.8, 0, 1.0 + i * 0.6))
				Sim.spawn_monster(GameData.monsters["wolf"], p.map_id, p.position + Vector3(-3.0, 0, 2.0))
			cmd.aim = p.position + Vector3(3.0, 0, 1.5)
			if _smoke_t > 0.6:
				cmd.attack = true
			if _smoke_t > 1.4 and _smoke_t < 1.5:
				cmd.skill_slot = 0
			if _smoke_t > 2.0:
				Input.action_press("skill_4")
			if _smoke_t > 2.6: _smoke_stage = 5
		5:
			if _shot_path != "":
				var img := get_viewport().get_texture().get_image()
				img.save_png(_shot_path)
				print("screenshot: " + _shot_path)
			print("SMOKE OK: map=%s hp=%d entities=%d views=%d" % [p.map_id, p.hp, Sim.entities.size(), views.size()])
			get_tree().quit(0)
	Sim.set_player_command(cmd)
