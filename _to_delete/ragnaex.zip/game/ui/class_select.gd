extends CanvasLayer
## Tela inicial: escolher classe e nome (ou continuar o save).

var hud
var has_save := false
var selected: ClassDef = null
var name_edit: LineEdit
var desc_label: Label
var start_btn: Button
var cards: Dictionary = {}

func _ready() -> void:
	layer = 20
	var bg := ColorRect.new()
	bg.color = Color(0.04, 0.04, 0.07, 0.75)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var panel := UiKit.panel()
	center.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	panel.add_child(v)
	var title := UiKit.label("RAGNAEX", 42, UiKit.GOLD)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(title)
	var sub := UiKit.label("Escolha sua classe. Atributos vêm do equipamento; skills sobem por maestria. Nível máximo 30.", 13, UiKit.MUTED)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(sub)
	if has_save:
		var d := SaveSystem.load_data()
		var cont := UiKit.button("▶ Continuar: %s (%s Lv.%d)" % [d.get("name", "?"), GameData.classes[d.get("class", "paladin")].name, int(d.get("level", 1))], func(): hud.on_class_chosen(GameData.classes[d.get("class", "paladin")], d.get("name", "Herói"), true), 300)
		cont.add_theme_font_size_override("font_size", 16)
		v.add_child(cont)
		v.add_child(UiKit.label("— ou crie um novo personagem (apaga o save) —", 11, UiKit.MUTED))
	var grid := GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	v.add_child(grid)
	for cls in GameData.class_list():
		var card := UiKit.button("", Callable(), 150)
		card.custom_minimum_size = Vector2(150, 96)
		var cv := VBoxContainer.new()
		cv.set_anchors_preset(Control.PRESET_FULL_RECT)
		cv.mouse_filter = Control.MOUSE_FILTER_IGNORE
		cv.alignment = BoxContainer.ALIGNMENT_CENTER
		var sq := UiKit.color_square(cls.color, 28)
		sq.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var hb := CenterContainer.new()
		hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
		hb.add_child(sq)
		cv.add_child(hb)
		var nl := UiKit.label(cls.name, 15, UiKit.TEXT)
		nl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		nl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		cv.add_child(nl)
		var rl := UiKit.label(cls.role + " · " + ", ".join(cls.weapon_types), 10, UiKit.MUTED)
		rl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		rl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		cv.add_child(rl)
		card.add_child(cv)
		card.pressed.connect(func(): _select(cls))
		grid.add_child(card)
		cards[cls.id] = card
	desc_label = UiKit.label("Selecione uma classe para ver a descrição e as skills.", 12)
	desc_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc_label.custom_minimum_size = Vector2(620, 90)
	v.add_child(desc_label)
	var h := HBoxContainer.new()
	v.add_child(h)
	h.add_child(UiKit.label("Nome:", 14))
	name_edit = LineEdit.new()
	name_edit.text = ["Aiden", "Lúcia", "Brann", "Sora", "Kaito", "Mira", "Dante", "Elara"][randi() % 8]
	name_edit.custom_minimum_size.x = 220
	name_edit.max_length = 16
	h.add_child(name_edit)
	start_btn = UiKit.button("Começar aventura", _start, 200)
	start_btn.disabled = true
	h.add_child(start_btn)

func _select(cls: ClassDef) -> void:
	selected = cls
	for id in cards:
		cards[id].modulate = Color(1, 1, 1) if id == cls.id else Color(0.7, 0.7, 0.7)
	var skills := ""
	for sid in cls.skill_ids:
		var s: SkillDef = GameData.skills.get(sid)
		if s:
			skills += "  • %s (Lv %d): %s\n" % [s.name, s.unlock_level, s.description]
	desc_label.text = "%s\n%s" % [cls.description, skills]
	start_btn.disabled = false

func _start() -> void:
	if selected == null:
		return
	var n := name_edit.text.strip_edges()
	if n == "":
		n = "Herói"
	SaveSystem.delete_save()
	hud.on_class_chosen(selected, n, false)
