class_name Hud
extends CanvasLayer
## HUD do jogo: barras, hotbar 1-6, poções F1-F3, chat, notificações, quest tracker,
## janelas (I/C/K/L), diálogo de NPC, loja/craft, seleção de classe e tela de morte.

var main
var root: Control
# topo-esquerda
var name_label: Label
var hp_bar: ProgressBar
var mp_bar: ProgressBar
var xp_bar: ProgressBar
var hp_text: Label
var mp_text: Label
var xp_text: Label
var gold_label: Label
var map_label: Label
# hotbar
var skill_slots: Array = []     # [{box, cd, key, name, lv}]
var potion_slots: Array = []
# chat / notificações
var chat_log: RichTextLabel
var chat_input: LineEdit
var notif_box: VBoxContainer
var quest_tracker: RichTextLabel
var hint_label: Label
var buffs_box: HBoxContainer
# janelas
var windows: Dictionary = {}    # nome -> Control
var windows_script
var npc_ui
var class_select: Control = null
var death_panel: Control = null
var _chat_focus := false

func _ready() -> void:
	layer = 10
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	_build_top_left()
	_build_hotbar()
	_build_chat()
	_build_notifications()
	_build_quest_tracker()
	_build_hints()
	windows_script = load("res://game/ui/windows.gd").new()
	windows_script.hud = self
	root.add_child(windows_script)
	npc_ui = load("res://game/ui/npc_ui.gd").new()
	npc_ui.hud = self
	root.add_child(npc_ui)
	root.visible = false
	Events.notification.connect(_notify)
	Events.chat_message.connect(_on_chat)
	Events.quest_accepted.connect(func(_e, _q): refresh_quest_tracker())
	Events.quest_progress.connect(func(_e, _q, _c, _n): refresh_quest_tracker())
	Events.quest_completed.connect(func(_e, _q): refresh_quest_tracker())
	Events.entity_died.connect(_on_died)
	Events.entity_respawned.connect(_on_respawned)
	Events.dialog_requested.connect(_on_dialog)
	Events.level_up.connect(_on_level_up)
	Events.mastery_changed.connect(_on_mastery)

func _on_level_up(id: int, _lv: int) -> void:
	if Sim.player and id == Sim.player.id:
		_refresh_hotbar_names()

func _on_mastery(id: int, _s: String, _l: int) -> void:
	if Sim.player and id == Sim.player.id:
		_refresh_hotbar_names()

func on_game_started() -> void:
	root.visible = true
	_refresh_hotbar_names()
	refresh_quest_tracker()

func on_map_changed(def: MapDef) -> void:
	if map_label:
		map_label.text = "%s  (Lv %d-%d)" % [def.name, def.level_range.x, def.level_range.y]

# ---------------------------------------------------------------------------
func _build_top_left() -> void:
	var p := UiKit.panel()
	p.position = Vector2(12, 12)
	p.custom_minimum_size = Vector2(280, 0)
	root.add_child(p)
	var v := VBoxContainer.new()
	p.add_child(v)
	name_label = UiKit.label("", 16, UiKit.GOLD)
	v.add_child(name_label)
	hp_bar = UiKit.bar(Color(0.85, 0.25, 0.3), 18)
	hp_text = UiKit.label("", 12)
	hp_text.set_anchors_preset(Control.PRESET_FULL_RECT)
	hp_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hp_bar.add_child(hp_text)
	v.add_child(hp_bar)
	mp_bar = UiKit.bar(Color(0.3, 0.45, 0.95), 14)
	mp_text = UiKit.label("", 11)
	mp_text.set_anchors_preset(Control.PRESET_FULL_RECT)
	mp_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	mp_bar.add_child(mp_text)
	v.add_child(mp_bar)
	xp_bar = UiKit.bar(Color(0.95, 0.8, 0.3), 8)
	v.add_child(xp_bar)
	var h := HBoxContainer.new()
	v.add_child(h)
	xp_text = UiKit.label("", 11, UiKit.MUTED)
	h.add_child(xp_text)
	xp_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	gold_label = UiKit.label("", 12, UiKit.GOLD)
	h.add_child(gold_label)
	buffs_box = HBoxContainer.new()
	v.add_child(buffs_box)
	map_label = UiKit.label("", 15, Color(0.85, 0.95, 1.0))
	map_label.position = Vector2(12, 140)
	root.add_child(map_label)

func _build_hotbar() -> void:
	var bar := HBoxContainer.new()
	bar.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	bar.grow_horizontal = Control.GROW_DIRECTION_BOTH
	bar.position = Vector2(0, -96)
	bar.add_theme_constant_override("separation", 6)
	root.add_child(bar)
	bar.anchor_left = 0.5; bar.anchor_right = 0.5; bar.anchor_top = 1.0; bar.anchor_bottom = 1.0
	bar.offset_top = -96; bar.offset_bottom = -12
	for i in range(6):
		var s := _slot("%d" % (i + 1), 56)
		bar.add_child(s["root"])
		skill_slots.append(s)
	var sep := Control.new()
	sep.custom_minimum_size.x = 14
	bar.add_child(sep)
	for i in range(3):
		var s := _slot("F%d" % (i + 1), 44)
		bar.add_child(s["root"])
		potion_slots.append(s)
	bar.reset_size()
	bar.offset_left = -bar.size.x * 0.5
	bar.offset_right = bar.size.x * 0.5

func _slot(key: String, size: int) -> Dictionary:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UiKit.panel_style(UiKit.BG, UiKit.BORDER, 4, 1))
	p.custom_minimum_size = Vector2(size + 14, size + 30)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 2)
	p.add_child(v)
	var box := Control.new()
	box.custom_minimum_size = Vector2(size, size)
	v.add_child(box)
	var icon := ColorRect.new()
	icon.color = Color(0.2, 0.2, 0.25)
	icon.set_anchors_preset(Control.PRESET_FULL_RECT)
	box.add_child(icon)
	var cd := ColorRect.new()
	cd.color = Color(0, 0, 0, 0.65)
	cd.set_anchors_preset(Control.PRESET_FULL_RECT)
	cd.visible = false
	box.add_child(cd)
	var cdt := UiKit.label("", 16)
	cdt.set_anchors_preset(Control.PRESET_FULL_RECT)
	cdt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	cdt.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	box.add_child(cdt)
	var k := UiKit.label(key, 11, UiKit.GOLD)
	k.position = Vector2(3, 1)
	box.add_child(k)
	var lv := UiKit.label("", 10, Color(0.8, 1, 0.8))
	lv.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	lv.position = Vector2(size - 22, size - 16)
	box.add_child(lv)
	var nm := UiKit.label("", 10, UiKit.MUTED, false)
	nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	nm.clip_text = true
	nm.custom_minimum_size.x = size
	v.add_child(nm)
	return {"root": p, "icon": icon, "cd": cd, "cdt": cdt, "name": nm, "lv": lv}

func _build_chat() -> void:
	var p := UiKit.panel(Color(0.05, 0.05, 0.08, 0.6), Color(0.3, 0.28, 0.35))
	p.anchor_top = 1.0; p.anchor_bottom = 1.0
	p.offset_left = 12; p.offset_right = 380; p.offset_top = -190; p.offset_bottom = -12
	root.add_child(p)
	var v := VBoxContainer.new()
	p.add_child(v)
	chat_log = RichTextLabel.new()
	chat_log.bbcode_enabled = true
	chat_log.scroll_following = true
	chat_log.size_flags_vertical = Control.SIZE_EXPAND_FILL
	chat_log.add_theme_font_size_override("normal_font_size", 12)
	chat_log.add_theme_font_size_override("bold_font_size", 12)
	chat_log.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(chat_log)
	chat_input = LineEdit.new()
	chat_input.placeholder_text = "Enter para falar..."
	chat_input.add_theme_font_size_override("font_size", 12)
	chat_input.text_submitted.connect(_on_chat_submit)
	chat_input.focus_entered.connect(func(): _chat_focus = true; _update_blocking())
	chat_input.focus_exited.connect(func(): _chat_focus = false; _update_blocking())
	v.add_child(chat_input)

func _build_notifications() -> void:
	notif_box = VBoxContainer.new()
	notif_box.anchor_left = 0.5; notif_box.anchor_right = 0.5
	notif_box.offset_left = -300; notif_box.offset_right = 300; notif_box.offset_top = 70
	notif_box.alignment = BoxContainer.ALIGNMENT_BEGIN
	notif_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(notif_box)

func _build_quest_tracker() -> void:
	var p := UiKit.panel(Color(0.05, 0.05, 0.08, 0.55), Color(0.3, 0.28, 0.35))
	p.anchor_left = 1.0; p.anchor_right = 1.0
	p.offset_left = -300; p.offset_right = -12; p.offset_top = 12
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(p)
	quest_tracker = RichTextLabel.new()
	quest_tracker.bbcode_enabled = true
	quest_tracker.fit_content = true
	quest_tracker.custom_minimum_size = Vector2(270, 20)
	quest_tracker.add_theme_font_size_override("normal_font_size", 12)
	quest_tracker.add_theme_font_size_override("bold_font_size", 13)
	quest_tracker.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_child(quest_tracker)

func _build_hints() -> void:
	hint_label = UiKit.label("WASD mover · LMB atacar · RMB bloquear · 1-6 skills · F1-F3 poções · Shift dash · Espaço interagir · Q/E girar câmera\nI bolsa · C personagem · K skills · L quests · Enter chat", 11, UiKit.MUTED)
	hint_label.anchor_left = 1.0; hint_label.anchor_right = 1.0; hint_label.anchor_top = 1.0; hint_label.anchor_bottom = 1.0
	hint_label.offset_left = -640; hint_label.offset_right = -12; hint_label.offset_top = -140; hint_label.offset_bottom = -106
	hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	root.add_child(hint_label)

# ---------------------------------------------------------------------------
func _process(_delta: float) -> void:
	var p: SimEntity = Sim.player
	if p == null or not root.visible:
		return
	name_label.text = "%s — %s Lv.%d" % [p.name, p.class_def.name, p.level]
	hp_bar.max_value = p.stats.max_hp
	hp_bar.value = p.hp
	hp_text.text = "%d / %d" % [int(p.hp), int(p.stats.max_hp)]
	if p.shield_hp > 0:
		hp_text.text += "  (+%d)" % int(p.shield_hp)
	mp_bar.max_value = p.stats.max_mp
	mp_bar.value = p.mp
	mp_text.text = "%d / %d" % [int(p.mp), int(p.stats.max_mp)]
	var need := Balance.xp_for_level(p.level)
	xp_bar.max_value = maxi(need, 1)
	xp_bar.value = p.xp if need > 0 else 1
	xp_text.text = "XP %d / %d" % [p.xp, need] if need > 0 else "Nível máximo"
	gold_label.text = "%d ouro" % p.gold
	# hotbar
	for i in range(6):
		var s: Dictionary = skill_slots[i]
		if i >= p.skills.size():
			continue
		var sk: SkillDef = p.skills[i]
		var locked := p.level < sk.unlock_level
		var cd := float(p.cooldowns.get(sk.id, 0.0))
		var no_mp := p.mp < sk.mp_cost_at(p.mastery_of(sk.id))
		s["cd"].visible = cd > 0.0 or locked or no_mp
		s["cdt"].text = ("Lv%d" % sk.unlock_level) if locked else ("%.1f" % cd if cd > 0.0 else ("MP" if no_mp else ""))
		s["icon"].color = sk.icon_color.darkened(0.6) if locked else sk.icon_color
	for i in range(3):
		var s: Dictionary = potion_slots[i]
		var item_id: String = p.potion_slots[i]
		var it: ItemDef = GameData.items.get(item_id) if item_id != "" else null
		var count := int(p.inventory.get(item_id, 0))
		s["icon"].color = it.icon_color if it else Color(0.2, 0.2, 0.25)
		s["name"].text = (it.name if it else "—")
		s["lv"].text = str(count) if it else ""
		s["cd"].visible = p.potion_cd > 0.0 or count == 0
		s["cdt"].text = "%.1f" % p.potion_cd if p.potion_cd > 0.0 else ("" if count > 0 else "0")
	# buffs
	for c in buffs_box.get_children():
		c.queue_free()
	for b in p.buffs:
		var l := UiKit.label("%s %.0fs" % [b.get("id", "buff"), float(b.get("remaining", 0))], 10, Color(0.8, 1, 0.8))
		buffs_box.add_child(l)
	for d in p.debuffs:
		var l := UiKit.label("%s %.0fs" % [d.get("kind", ""), float(d.get("remaining", 0))], 10, Color(1, 0.6, 0.6))
		buffs_box.add_child(l)

func _refresh_hotbar_names() -> void:
	var p: SimEntity = Sim.player
	if p == null:
		return
	for i in range(6):
		var s: Dictionary = skill_slots[i]
		if i < p.skills.size():
			s["name"].text = p.skills[i].name
			s["lv"].text = "M%d" % p.mastery_of(p.skills[i].id)

func _unhandled_input(event: InputEvent) -> void:
	if not root.visible or Sim.player == null:
		return
	if event.is_action_pressed("ui_chat") and not _chat_focus:
		chat_input.grab_focus()
		get_viewport().set_input_as_handled()
		return
	if event.is_action_pressed("ui_cancel"):
		if _chat_focus:
			chat_input.release_focus()
		elif npc_ui.is_open():
			npc_ui.close()
		else:
			windows_script.close_all()
		_update_blocking()
		return
	if _chat_focus:
		return
	if event.is_action_pressed("ui_inventory"): windows_script.toggle("inventory")
	elif event.is_action_pressed("ui_character"): windows_script.toggle("character")
	elif event.is_action_pressed("ui_skills"): windows_script.toggle("skills")
	elif event.is_action_pressed("ui_quests"): windows_script.toggle("quests")
	_update_blocking()

func _update_blocking() -> void:
	if main and main.controller:
		main.controller.ui_blocking = _chat_focus or npc_ui.is_open() or (death_panel != null) or (class_select != null)

# ---------------------------------------------------------------------------
func _notify(text: String) -> void:
	var l := UiKit.label(text, 16, Color(1, 0.95, 0.75))
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	notif_box.add_child(l)
	var tw := create_tween()
	tw.tween_interval(2.2)
	tw.tween_property(l, "modulate:a", 0.0, 0.6)
	tw.tween_callback(l.queue_free)
	if notif_box.get_child_count() > 5:
		notif_box.get_child(0).queue_free()

func _on_chat(sender: String, text: String, channel: String) -> void:
	var col := "#9ad0ff"
	if channel == "system":
		col = "#ffd966"
	elif Sim.player and sender == Sim.player.name:
		col = "#ffe9a8"
	chat_log.append_text("[color=%s][b]%s:[/b][/color] %s\n" % [col, sender, text.replace("[", "[lb]")])

func _on_chat_submit(text: String) -> void:
	chat_input.text = ""
	chat_input.release_focus()
	if text.strip_edges() == "" or Sim.player == null:
		return
	Events.chat_message.emit(Sim.player.name, text, "global")
	# bots "respondem" de vez em quando
	if randf() < 0.5:
		var bots: Array = []
		for e in Sim.entities.values():
			if e.kind == SimEntity.Kind.BOT:
				bots.append(e)
		if bots.size() > 0:
			var b: SimEntity = bots[randi() % bots.size()]
			var reply: String = ["oi %s" % Sim.player.name, "kkkk", "verdade", "bora?", "tb acho", "?", "gg", "qual seu lvl?", "to na campina se quiser vir"][randi() % 9]
			get_tree().create_timer(randf_range(1.5, 4.0)).timeout.connect(func(): Events.chat_message.emit(b.name, reply, "global"))

func refresh_quest_tracker() -> void:
	var p: SimEntity = Sim.player
	if p == null:
		return
	var t := "[b][color=#ffd966]Quests[/color][/b]\n"
	if p.quests_active.is_empty():
		t += "[color=#888]Nenhuma. Fale com NPCs [Quest].[/color]"
	for qid in p.quests_active:
		var q: QuestDef = GameData.quests[qid]
		var prog := QuestSystem.progress(p, q)
		var done := prog >= q.count
		t += "[color=%s]%s[/color]  %d/%d%s\n" % ["#9f9" if done else "#eee", q.title, prog, q.count, "  ✔ entregar" if done else ""]
		if not done:
			t += "   [color=#888]%s[/color]\n" % q.map_hint
	quest_tracker.text = t

# ---------------------------------------------------------------------------
func _on_dialog(npc_id: String) -> void:
	npc_ui.open(npc_id)
	_update_blocking()

func _on_died(id: int, _k: int) -> void:
	if Sim.player and id == Sim.player.id:
		death_panel = UiKit.panel(Color(0.2, 0.02, 0.04, 0.85), Color(0.8, 0.2, 0.2))
		death_panel.set_anchors_preset(Control.PRESET_CENTER)
		death_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
		death_panel.grow_vertical = Control.GROW_DIRECTION_BOTH
		var v := VBoxContainer.new()
		v.add_child(UiKit.label("Você morreu", 32, Color(1, 0.4, 0.4)))
		v.add_child(UiKit.label("Renascendo em Aldara... (-3% XP)", 14))
		death_panel.add_child(v)
		root.add_child(death_panel)
		_update_blocking()

func _on_respawned(id: int) -> void:
	if Sim.player and id == Sim.player.id and death_panel:
		death_panel.queue_free()
		death_panel = null
		_update_blocking()

func show_class_select(has_save: bool) -> void:
	class_select = load("res://game/ui/class_select.gd").new()
	class_select.hud = self
	class_select.has_save = has_save
	add_child(class_select)

func on_class_chosen(cls: ClassDef, char_name: String, load_save: bool) -> void:
	if class_select:
		class_select.queue_free()
		class_select = null
	main.start_game(cls, char_name, load_save)
	_update_blocking()
