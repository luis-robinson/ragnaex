extends Control
## Diálogo de NPC: falas, aceitar/entregar quests, loja (mercador) e crafting (ferreiro/alquimista).

var hud
var win: PanelContainer = null
var npc_id := ""
var npc: Dictionary = {}
var mode := "dialog"   # dialog | shop | craft

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	Events.item_gained.connect(func(_id, _i, _c): _refresh_if_open())
	Events.item_removed.connect(func(_id, _i, _c): _refresh_if_open())
	Events.quest_completed.connect(func(_id, _q): _refresh_if_open())

func is_open() -> bool:
	return win != null

func _refresh_if_open() -> void:
	if win and mode != "dialog":
		_rebuild()

func open(id: String) -> void:
	npc_id = id
	npc = {}
	for mid in GameData.maps:
		for n in GameData.maps[mid].npcs:
			if n["id"] == id:
				npc = n
	if npc.is_empty():
		return
	mode = "dialog"
	QuestSystem.on_talk(Sim.player, id)
	hud.windows_script.close_all()
	_rebuild()

func close() -> void:
	if win:
		win.queue_free()
		win = null
	hud._update_blocking()

func _rebuild() -> void:
	if win:
		win.queue_free()
	win = UiKit.panel()
	win.custom_minimum_size = Vector2(680, 320)
	add_child(win)
	var v := VBoxContainer.new()
	win.add_child(v)
	var header := HBoxContainer.new()
	v.add_child(header)
	var t := UiKit.title(npc.get("name", "NPC"))
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(t)
	header.add_child(UiKit.button("✕ (Esc)", close))
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.custom_minimum_size = Vector2(650, 340)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(scroll)
	var body := VBoxContainer.new()
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(body)
	match mode:
		"dialog": _dialog(body)
		"shop": _shop(body)
		"craft": _craft(body)
	win.reset_size()
	win.position = (get_viewport_rect().size - win.size) * 0.5

func _dialog(body: VBoxContainer) -> void:
	var p: SimEntity = Sim.player
	var role: String = npc.get("role", "")
	# quests para entregar
	var turnins := QuestSystem.turnins_at(p, npc_id)
	for q in turnins:
		var card := UiKit.panel(Color(0.12, 0.2, 0.12, 0.95), Color(0.5, 0.9, 0.5))
		body.add_child(card)
		var cv := VBoxContainer.new()
		card.add_child(cv)
		cv.add_child(UiKit.label("✔ %s" % q.title, 14, Color(0.6, 1, 0.6)))
		cv.add_child(UiKit.para('"%s"' % q.dialog_complete, 12))
		var rew := "Recompensa: %d XP, %d ouro" % [q.reward_xp, q.reward_gold]
		for iid in q.reward_items:
			var it: ItemDef = GameData.items.get(iid)
			rew += ", %s x%d" % [it.name if it else iid, int(q.reward_items[iid])]
		cv.add_child(UiKit.label(rew, 11, UiKit.MUTED))
		cv.add_child(UiKit.button("Entregar", func(): QuestSystem.complete(p, q, Sim); _rebuild(), 120))
	# quests em andamento com este NPC
	for qid in p.quests_active:
		var q: QuestDef = GameData.quests[qid]
		if (q.giver_npc == npc_id or q.turnin() == npc_id) and not QuestSystem.is_complete(p, q):
			var card := UiKit.panel(UiKit.BG_LIGHT, Color(0.3, 0.28, 0.35))
			body.add_child(card)
			var cv := VBoxContainer.new()
			card.add_child(cv)
			cv.add_child(UiKit.label("… %s (%d/%d)" % [q.title, QuestSystem.progress(p, q), q.count], 13, UiKit.GOLD))
			cv.add_child(UiKit.para('"%s"' % q.dialog_progress, 12))
	# quests disponíveis
	for q in QuestSystem.available_from_npc(p, npc_id):
		var card := UiKit.panel(Color(0.2, 0.18, 0.1, 0.95), UiKit.GOLD)
		body.add_child(card)
		var cv := VBoxContainer.new()
		card.add_child(cv)
		cv.add_child(UiKit.label("! %s  (Lv %d)" % [q.title, q.level_req], 14, UiKit.GOLD))
		cv.add_child(UiKit.para('"%s"' % q.dialog_offer, 12))
		cv.add_child(UiKit.para(q.description + "  —  " + q.map_hint, 11, UiKit.MUTED))
		cv.add_child(UiKit.button("Aceitar", func(): QuestSystem.accept(p, q); _rebuild(), 120))
	# falas
	var lines: Array = npc.get("dialog", [])
	if lines.size() > 0:
		body.add_child(UiKit.hsep())
		body.add_child(UiKit.para('"%s"' % lines[randi() % lines.size()], 13, Color(0.9, 0.9, 0.95)))
	# ações por papel
	body.add_child(UiKit.hsep())
	var actions := HBoxContainer.new()
	body.add_child(actions)
	match role:
		"merchant":
			actions.add_child(UiKit.button("Abrir loja", func(): mode = "shop"; _rebuild(), 140))
		"smith":
			actions.add_child(UiKit.button("Usar a forja", func(): mode = "craft"; _rebuild(), 140))
		"alchemy":
			actions.add_child(UiKit.button("Usar o caldeirão", func(): mode = "craft"; _rebuild(), 140))
		"board":
			body.add_child(UiKit.para("Campina (Lv 1-10): portal sul · Floresta (Lv 10-20): portal leste · Ruínas (Lv 20-30): portal oeste", 11, UiKit.MUTED))
	actions.add_child(UiKit.button("Fechar", close, 100))

func _shop(body: VBoxContainer) -> void:
	var p: SimEntity = Sim.player
	body.add_child(UiKit.label("Ouro: %d" % p.gold, 13, UiKit.GOLD))
	body.add_child(UiKit.label("Comprar:", 13))
	var grid := GridContainer.new()
	grid.columns = 2
	body.add_child(grid)
	for iid in npc.get("shop", []):
		var it: ItemDef = GameData.items.get(iid)
		if it == null:
			continue
		var h := HBoxContainer.new()
		h.add_child(UiKit.color_square(it.icon_color, 18))
		var b := UiKit.button("%s — %d ouro" % [it.name, it.price], func(): CraftSystem.buy(p, iid, 1), 220)
		b.disabled = p.gold < it.price
		b.mouse_entered.connect(func(): hud.windows_script._show_tip(UiKit.item_tooltip(it)))
		b.mouse_exited.connect(hud.windows_script._hide_tip)
		h.add_child(b)
		grid.add_child(h)
	body.add_child(UiKit.hsep())
	body.add_child(UiKit.label("Vender (50% do preço):", 13))
	var grid2 := GridContainer.new()
	grid2.columns = 2
	body.add_child(grid2)
	var ids := p.inventory.keys()
	ids.sort()
	for iid in ids:
		var it: ItemDef = GameData.items.get(iid)
		if it == null or it.type == ItemDef.Type.QUEST:
			continue
		var count := int(p.inventory[iid])
		var h := HBoxContainer.new()
		h.add_child(UiKit.color_square(it.icon_color, 18))
		h.add_child(UiKit.button("%s x%d → +%d" % [it.name, count, int(it.price * 0.5)], func(): CraftSystem.sell(p, iid, 1), 180))
		if count > 1:
			h.add_child(UiKit.button("todos", func(): CraftSystem.sell(p, iid, count), 60))
		grid2.add_child(h)
	body.add_child(UiKit.hsep())
	body.add_child(UiKit.button("← Voltar", func(): mode = "dialog"; _rebuild(), 100))

func _craft(body: VBoxContainer) -> void:
	var p: SimEntity = Sim.player
	var station: String = npc.get("role", "smith")
	body.add_child(UiKit.label("Ouro: %d   ·   Nível: %d" % [p.gold, p.level], 13, UiKit.GOLD))
	for r in CraftSystem.recipes_for_station(station):
		var it: ItemDef = GameData.items.get(r.result_item)
		var can := CraftSystem.can_craft(p, r)
		var card := UiKit.panel(UiKit.BG_LIGHT, Color(0.5, 0.9, 0.5) if can else Color(0.3, 0.28, 0.35))
		body.add_child(card)
		var h := HBoxContainer.new()
		card.add_child(h)
		h.add_child(UiKit.color_square(it.icon_color, 30))
		var v := VBoxContainer.new()
		v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		h.add_child(v)
		v.add_child(UiKit.label("%s x%d   (Lv %d%s)" % [it.name, r.result_count, r.level_req, (", %d ouro" % r.gold_cost) if r.gold_cost > 0 else ""], 13, UiKit.GOLD if can else UiKit.TEXT))
		var ing := ""
		for iid in r.ingredients:
			var ii: ItemDef = GameData.items.get(iid)
			var have := int(p.inventory.get(iid, 0))
			var need := int(r.ingredients[iid])
			ing += "[color=%s]%s %d/%d[/color]   " % ["#9f9" if have >= need else "#f88", ii.name if ii else iid, have, need]
		var rt := RichTextLabel.new()
		rt.bbcode_enabled = true
		rt.fit_content = true
		rt.text = ing
		rt.add_theme_font_size_override("normal_font_size", 11)
		rt.mouse_filter = Control.MOUSE_FILTER_IGNORE
		v.add_child(rt)
		var lbl := UiKit.para(it.description, 10, UiKit.MUTED)
		v.add_child(lbl)
		var b := UiKit.button("Criar", func(): CraftSystem.craft(p, r), 90)
		b.disabled = not can
		b.mouse_entered.connect(func(): hud.windows_script._show_tip(UiKit.item_tooltip(it)))
		b.mouse_exited.connect(hud.windows_script._hide_tip)
		h.add_child(b)
	body.add_child(UiKit.hsep())
	body.add_child(UiKit.button("← Voltar", func(): mode = "dialog"; _rebuild(), 100))
