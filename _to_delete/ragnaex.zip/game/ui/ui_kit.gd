class_name UiKit
extends RefCounted
## Helpers de UI: painéis, botões e barras com um visual consistente (escuro, bordas quentes).

const BG := Color(0.09, 0.08, 0.12, 0.92)
const BG_LIGHT := Color(0.16, 0.14, 0.2, 0.95)
const BORDER := Color(0.75, 0.62, 0.38)
const TEXT := Color(0.95, 0.93, 0.88)
const MUTED := Color(0.65, 0.62, 0.6)
const GOLD := Color(1.0, 0.85, 0.4)

static func panel_style(bg: Color = BG, border: Color = BORDER, radius: int = 6, border_w: int = 2) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(border_w)
	s.set_corner_radius_all(radius)
	s.set_content_margin_all(10)
	return s

static func panel(bg: Color = BG, border: Color = BORDER) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", panel_style(bg, border))
	return p

static func label(text: String, size: int = 14, color: Color = TEXT, outline: bool = true) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	if outline:
		l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
		l.add_theme_constant_override("outline_size", 3)
	return l

## Parágrafo com quebra de linha automática (para descrições dentro de janelas)
static func para(text: String, size: int = 12, color: Color = TEXT) -> Label:
	var l := label(text, size, color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l

static func title(text: String) -> Label:
	return label(text, 20, GOLD)

static func button(text: String, on_pressed: Callable = Callable(), min_w: int = 0) -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	var st := panel_style(BG_LIGHT, BORDER, 4, 1)
	st.set_content_margin_all(6)
	b.add_theme_stylebox_override("normal", st)
	var h := panel_style(Color(0.26, 0.22, 0.3, 1.0), GOLD, 4, 1)
	h.set_content_margin_all(6)
	b.add_theme_stylebox_override("hover", h)
	var pr := panel_style(Color(0.35, 0.28, 0.2, 1.0), GOLD, 4, 1)
	pr.set_content_margin_all(6)
	b.add_theme_stylebox_override("pressed", pr)
	var dis := panel_style(Color(0.12, 0.11, 0.14, 0.8), Color(0.3, 0.3, 0.3), 4, 1)
	dis.set_content_margin_all(6)
	b.add_theme_stylebox_override("disabled", dis)
	b.add_theme_color_override("font_color", TEXT)
	b.add_theme_color_override("font_hover_color", GOLD)
	b.add_theme_color_override("font_disabled_color", MUTED)
	b.add_theme_font_size_override("font_size", 14)
	if min_w > 0:
		b.custom_minimum_size.x = min_w
	if on_pressed.is_valid():
		b.pressed.connect(on_pressed)
	return b

static func bar(color: Color, height: int = 16) -> ProgressBar:
	var p := ProgressBar.new()
	p.show_percentage = false
	p.custom_minimum_size.y = height
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.05, 0.05, 0.08, 0.9)
	bg.set_corner_radius_all(3)
	bg.border_color = Color(0, 0, 0, 0.6)
	bg.set_border_width_all(1)
	var fill := StyleBoxFlat.new()
	fill.bg_color = color
	fill.set_corner_radius_all(3)
	p.add_theme_stylebox_override("background", bg)
	p.add_theme_stylebox_override("fill", fill)
	return p

static func color_square(color: Color, size: int = 40) -> ColorRect:
	var c := ColorRect.new()
	c.color = color
	c.custom_minimum_size = Vector2(size, size)
	return c

static func hsep(h: int = 6) -> Control:
	var c := Control.new()
	c.custom_minimum_size.y = h
	return c

static func attr_name(a: String) -> String:
	match a:
		"FOR": return "FOR (força)"
		"AGI": return "AGI (agilidade)"
		"VIT": return "VIT (vitalidade)"
		"WILL": return "WILL (vontade)"
		"INT": return "INT (inteligência)"
	return a

static func slot_name(slot: int) -> String:
	match slot:
		ItemDef.Slot.WEAPON: return "Arma"
		ItemDef.Slot.OFFHAND: return "Mão secundária"
		ItemDef.Slot.HEAD: return "Cabeça"
		ItemDef.Slot.BODY: return "Corpo"
		ItemDef.Slot.BOOTS: return "Botas"
		ItemDef.Slot.ACCESSORY: return "Acessório"
	return "-"

static func target_name(t: int) -> String:
	match t:
		SkillDef.Target.SELF: return "em si / área ao redor"
		SkillDef.Target.DIRECTION: return "direção do cursor"
		SkillDef.Target.GROUND: return "área no cursor"
		SkillDef.Target.CONE: return "cone à frente"
		SkillDef.Target.TARGET: return "alvo sob o cursor"
	return ""

static func item_tooltip(it: ItemDef) -> String:
	var t := "[b]%s[/b]\n%s" % [it.name, it.description]
	if it.is_equipment():
		t += "\n[color=#aaa]%s" % slot_name(it.slot)
		if it.weapon_type != "":
			t += " · " + it.weapon_type
		t += " · Lv %d[/color]" % it.level_req
		if it.atk > 0: t += "\nATK +%d" % it.atk
		if it.matk > 0: t += "\nMATK +%d" % it.matk
		if it.def > 0: t += "\nDEF +%d" % it.def
		if it.mdef > 0: t += "\nMDEF +%d" % it.mdef
		for a in it.attributes:
			if int(it.attributes[a]) != 0:
				t += "\n[color=#ffd966]%s +%d[/color]" % [a, int(it.attributes[a])]
	elif it.type == ItemDef.Type.CONSUMABLE:
		t += "\n[color=#aaa]Consumível · cooldown %.0fs[/color]" % it.consume_cooldown
	t += "\n[color=#888]Preço: %d ouro[/color]" % it.price
	return t
