extends Control
## Janelas: Bolsa (I), Personagem (C), Skills/Maestria (K), Quests (L).
## Reconstruídas ao abrir e a cada mudança relevante (simples e robusto).

var hud
var open_name := ""
var win: PanelContainer = null
var tooltip: PanelContainer
var tip_rtl: RichTextLabel

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	tooltip = UiKit.panel(Color(0.06, 0.05, 0.09, 0.96))
	tooltip.visible = false
	tooltip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tooltip.z_index = 50
	tip_rtl = RichTextLabel.new()
	tip_rtl.bbcode_enabled = true
	tip_rtl.fit_content = true
	tip_rtl.custom_minimum_size = Vector2(240, 10)
	tip_rtl.add_theme_font_size_override("normal_font_size", 12)
	tip_rtl.add_theme_font_size_override("bold_font_size", 13)
	tip_rtl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tooltip.add_child(tip_rtl)
	add_child(tooltip)
	Events.item_gained.connect(func(id, _i, _c): _maybe_refresh(id, ["inventory"]))
	Events.item_removed.connect(func(id, _i, _c): _maybe_refresh(id, ["inventory"]))
	Events.equipment_changed.connect(func(id): _maybe_refresh(id, ["inventory", "character"]))
	Events.mastery_changed.connect(func(id, _s, _l): _maybe_refresh(id, ["skills"]))
	Events.level_up.connect(func(id, _l): _maybe_refresh(id, ["skills", "character"]))
	Events.quest_accepted.connect(func(id, _q): _maybe_refresh(id, ["quests"]))
	Events.quest_completed.connect(func(id, _q): _maybe_refresh(id, ["quests"]))

func _maybe_refresh(entity_id: int, names: Array) -> void:
	if Sim.player and entity_id == Sim.player.id and open_name in names:
		_rebuild()

func _process(_delta: float) -> void:
	if tooltip.visible:
		var mp := get_viewport().get_mouse_position()
		var sz := get_viewport().get_visible_rect().size
		tooltip.position = Vector2(minf(mp.x + 16, sz.x - tooltip.size.x - 8), minf(mp.y + 16, sz.y - tooltip.size.y - 8))

func toggle(name: String) -> void:
	if open_name == name:
		close_all()
	else:
		open_name = name
		_rebuild()

func close_all() -> void:
	open_name = ""
	if win:
		win.queue_free()
		win = null
	tooltip.visible = false

func _rebuild() -> void:
	if win:
		win.queue_free()
		win = null
	tooltip.visible = false
	if open_name == "":
		return
	win = UiKit.panel()
	win.custom_minimum_size = Vector2(680, 440)
	add_child(win)
	var v := VBoxContainer.new()
	win.add_child(v)
	var header := HBoxContainer.new()
	v.add_child(header)
	var titles := {"inventory": "Bolsa (I)", "character": "Personagem (C)", "skills": "Skills & Maestria (K)", "quests": "Quests (L)"}
	var t := UiKit.title(titles.get(open_name, ""))
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(t)
	header.add_child(UiKit.button("✕", close_all))
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.custom_minimum_size = Vector2(650, 380)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(scroll)
	var body := VBoxContainer.new()
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(body)
	match open_name:
		"inventory": _inventory(body)
		"character": _character(body)
		"skills": _skills(body)
		"quests": _quests(body)
	win.reset_size()
	win.position = (get_viewport_rect().size - win.size) * 0.5

func _show_tip(text: String) -> void:
	tip_rtl.text = text
	tooltip.visible = true
	tooltip.reset_size()

func _hide_tip() -> void:
	tooltip.visible = false

# ---------------------------------------------------------------------------
func _inventory(body: VBoxContainer) -> void:
	var p: SimEntity = Sim.player
	body.add_child(UiKit.label("Ouro: %d   ·   itens: %d" % [p.gold, p.inventory_weight()], 13, UiKit.GOLD))
	body.add_child(UiKit.label("Equipado:", 13, UiKit.MUTED))
	var eqgrid := GridContainer.new()
	eqgrid.columns = 3
	body.add_child(eqgrid)
	for slot in [ItemDef.Slot.WEAPON, ItemDef.Slot.OFFHAND, ItemDef.Slot.HEAD, ItemDef.Slot.BODY, ItemDef.Slot.BOOTS, ItemDef.Slot.ACCESSORY]:
		var it: ItemDef = p.equipment.get(slot)
		var b := UiKit.button("%s: %s" % [UiKit.slot_name(slot), it.name if it else "—"], Callable(), 160)
		if it:
			b.pressed.connect(func(): Sim.unequip(p, slot))
			b.mouse_entered.connect(func(): _show_tip(UiKit.item_tooltip(it) + "\n[color=#9f9]Clique: desequipar[/color]"))
			b.mouse_exited.connect(_hide_tip)
		else:
			b.disabled = true
		eqgrid.add_child(b)
	body.add_child(UiKit.hsep())
	body.add_child(UiKit.para("Bolsa (clique: equipar/usar · Shift+clique: colocar em F1/F2/F3):", 13, UiKit.MUTED))
	var grid := GridContainer.new()
	grid.columns = 4
	body.add_child(grid)
	var ids := p.inventory.keys()
	ids.sort()
	for item_id in ids:
		var it: ItemDef = GameData.items.get(item_id)
		if it == null:
			continue
		var count := int(p.inventory[item_id])
		var h := HBoxContainer.new()
		h.add_child(UiKit.color_square(it.icon_color, 18))
		var b := UiKit.button("%s x%d" % [it.name, count], Callable(), 100)
		b.add_theme_font_size_override("font_size", 12)
		b.pressed.connect(func(): _on_item_click(it))
		b.mouse_entered.connect(func(): _show_tip(UiKit.item_tooltip(it)))
		b.mouse_exited.connect(_hide_tip)
		h.add_child(b)
		grid.add_child(h)
	body.add_child(UiKit.hsep())
	var potions := HBoxContainer.new()
	body.add_child(potions)
	for i in range(3):
		var iid: String = p.potion_slots[i]
		var it: ItemDef = GameData.items.get(iid) if iid != "" else null
		potions.add_child(UiKit.label("F%d: %s" % [i + 1, it.name if it else "—"], 12))

func _on_item_click(it: ItemDef) -> void:
	var p: SimEntity = Sim.player
	if Input.is_key_pressed(KEY_SHIFT) and it.type == ItemDef.Type.CONSUMABLE:
		# coloca no primeiro slot vazio (ou substitui o F1)
		var slot := 0
		for i in range(3):
			if p.potion_slots[i] == "" or p.potion_slots[i] == it.id:
				slot = i
				break
		Sim.set_potion_slot(p, slot, it.id)
		Events.notification.emit("%s → F%d" % [it.name, slot + 1])
		_rebuild()
		return
	if it.is_equipment():
		Sim.equip(p, it.id)
	elif it.type == ItemDef.Type.CONSUMABLE:
		for i in range(3):
			if p.potion_slots[i] == it.id:
				Sim.use_potion(p, i)
				return
		Sim.set_potion_slot(p, 2, it.id)
		Sim.use_potion(p, 2)

# ---------------------------------------------------------------------------
func _character(body: VBoxContainer) -> void:
	var p: SimEntity = Sim.player
	var s := p.stats
	body.add_child(UiKit.label("%s — %s Lv.%d  (%s)" % [p.name, p.class_def.name, p.level, p.class_def.role], 15, UiKit.GOLD))
	body.add_child(UiKit.para(p.class_def.description, 12, UiKit.MUTED))
	body.add_child(UiKit.hsep())
	body.add_child(UiKit.label("Atributos (vêm do equipamento):", 13))
	var g := GridContainer.new()
	g.columns = 2
	body.add_child(g)
	var desc := {
		"FOR": "+ATK físico · com escudo: +chance de bloqueio · bloqueio reduz mais dano",
		"AGI": "+dano de arco (muito) e adaga (um pouco) · +crit físico",
		"VIT": "+HP máximo · +DEF física",
		"WILL": "+cura · +MP máximo · +DEF mágica",
		"INT": "+dano mágico · +crit mágico",
	}
	for a in Balance.ATTRS:
		g.add_child(UiKit.label("%s: %d" % [UiKit.attr_name(a), s.attrs[a]], 13, UiKit.GOLD))
		g.add_child(UiKit.para(desc[a], 11, UiKit.MUTED))
	body.add_child(UiKit.hsep())
	var g2 := GridContainer.new()
	g2.columns = 2
	body.add_child(g2)
	var rows := [
		["HP", "%d / %d" % [int(p.hp), int(s.max_hp)]], ["MP", "%d / %d" % [int(p.mp), int(s.max_mp)]],
		["ATK físico", "%.0f" % s.patk], ["ATK mágico", "%.0f" % s.matk],
		["DEF física", "%.0f" % s.pdef], ["DEF mágica", "%.0f" % s.mdef],
		["Crítico físico", "%.1f%%" % s.crit_phys], ["Crítico mágico", "%.1f%%" % s.crit_mag],
		["Poder de cura", "x%.2f" % s.heal_power], ["Velocidade", "%.1f" % s.move_speed],
		["Bloqueio passivo", "%.1f%% (escudo)" % s.block_chance if s.has_shield else "— (sem escudo)"],
		["Redução ao bloquear", "%.0f%% (+%.0f%% segurando RMB)" % [s.block_reduction, Balance.GUARD_HOLD_REDUCTION_BONUS]],
		["Arma", s.weapon_type if s.weapon_type != "" else "—"], ["Pontos de maestria", str(p.mastery_points)],
	]
	for r in rows:
		g2.add_child(UiKit.label(r[0] + ":", 12, UiKit.MUTED))
		g2.add_child(UiKit.label(r[1], 12))
	body.add_child(UiKit.hsep())
	body.add_child(UiKit.label("Quests concluídas: %d" % p.quests_completed.size(), 12, UiKit.MUTED))

# ---------------------------------------------------------------------------
func _skills(body: VBoxContainer) -> void:
	var p: SimEntity = Sim.player
	body.add_child(UiKit.para("Pontos de maestria: %d   (ganha 1 por nível; +1 nos níveis 10/20/30; usar uma skill 30x também sobe)" % p.mastery_points, 12, UiKit.GOLD))
	body.add_child(UiKit.hsep())
	for i in range(p.skills.size()):
		var sk: SkillDef = p.skills[i]
		var lv := p.mastery_of(sk.id)
		var locked := p.level < sk.unlock_level
		var card := UiKit.panel(UiKit.BG_LIGHT, Color(0.3, 0.28, 0.35))
		body.add_child(card)
		var h := HBoxContainer.new()
		card.add_child(h)
		h.add_child(UiKit.color_square(sk.icon_color.darkened(0.6) if locked else sk.icon_color, 36))
		var v := VBoxContainer.new()
		v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		h.add_child(v)
		v.add_child(UiKit.label("[%d] %s   %s" % [i + 1, sk.name, ("(desbloqueia no Lv %d)" % sk.unlock_level) if locked else "Maestria %d/5" % lv], 14, UiKit.MUTED if locked else UiKit.GOLD))
		v.add_child(UiKit.para(sk.description, 11))
		var stats_txt := "Mira: %s · Poder %.0f%% · MP %.0f · CD %.1fs · Alcance %.1f" % [UiKit.target_name(sk.target), sk.power_at(lv) * 100.0, sk.mp_cost_at(lv), sk.cooldown_at(lv), sk.range if sk.target != SkillDef.Target.CONE else sk.radius]
		if lv < 5:
			stats_txt += "\nPróximo nível: Poder %.0f%% · MP %.0f · CD %.1fs" % [sk.power_at(lv + 1) * 100.0, sk.mp_cost_at(lv + 1), sk.cooldown_at(lv + 1)]
		v.add_child(UiKit.para(stats_txt, 11, UiKit.MUTED))
		var uses := int(p.skill_uses.get(sk.id, 0))
		v.add_child(UiKit.label("Usos até maestria grátis: %d/%d" % [uses, Balance.SKILL_USES_PER_FREE_MASTERY], 10, UiKit.MUTED))
		var cost := Balance.mastery_cost(lv)
		var b := UiKit.button("Melhorar (%d pt)" % cost if lv < 5 else "MÁX", Callable(), 120)
		b.disabled = locked or lv >= 5 or p.mastery_points < cost
		b.pressed.connect(func(): Sim.upgrade_mastery(p, sk.id))
		h.add_child(b)

# ---------------------------------------------------------------------------
func _quests(body: VBoxContainer) -> void:
	var p: SimEntity = Sim.player
	body.add_child(UiKit.label("Ativas:", 13, UiKit.GOLD))
	if p.quests_active.is_empty():
		body.add_child(UiKit.label("Nenhuma quest ativa. Procure NPCs marcados com [Quest].", 12, UiKit.MUTED))
	for qid in p.quests_active:
		var q: QuestDef = GameData.quests[qid]
		var prog := QuestSystem.progress(p, q)
		var card := UiKit.panel(UiKit.BG_LIGHT, Color(0.3, 0.28, 0.35))
		body.add_child(card)
		var v := VBoxContainer.new()
		card.add_child(v)
		v.add_child(UiKit.label("%s   %d/%d%s" % [q.title, prog, q.count, "  ✔" if prog >= q.count else ""], 14, Color(0.6, 1, 0.6) if prog >= q.count else UiKit.TEXT))
		v.add_child(UiKit.para(q.description, 11))
		v.add_child(UiKit.para("Onde: %s · Entregar para: %s · Recompensa: %d XP, %d ouro" % [q.map_hint, _npc_name(q.turnin()), q.reward_xp, q.reward_gold], 11, UiKit.MUTED))
	body.add_child(UiKit.hsep())
	body.add_child(UiKit.label("Concluídas: %d" % p.quests_completed.size(), 13, UiKit.MUTED))
	for qid in p.quests_completed:
		var q: QuestDef = GameData.quests.get(qid)
		if q:
			body.add_child(UiKit.label("✔ " + q.title, 11, UiKit.MUTED))

func _npc_name(npc_id: String) -> String:
	for mid in GameData.maps:
		for n in GameData.maps[mid].npcs:
			if n["id"] == npc_id:
				return n["name"]
	return npc_id
