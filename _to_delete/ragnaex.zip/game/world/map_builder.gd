class_name MapBuilder
extends RefCounted
## Constrói o visual de um MapDef: chão, obstáculos (blockout low-poly), decoração, portais, luz.
## Se existir assets/models/<map.model>.glb ele é carregado por cima do chão (os obstáculos
## continuam valendo para colisão, mas ficam invisíveis se o GLB existir).

static func build(def: MapDef) -> Node3D:
	var root := Node3D.new()
	root.name = "Map_" + def.id

	# --- luz e ambiente ---
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, 35, 0)
	sun.light_energy = def.sun_energy * 0.65
	sun.light_color = Color(1.0, 0.97, 0.9)
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 60.0
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	root.add_child(sun)
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = def.ambient.darkened(0.35)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = def.ambient
	e.ambient_light_energy = 0.3
	e.fog_enabled = true
	e.fog_light_color = def.ambient
	e.fog_density = 0.004
	e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	e.glow_enabled = false
	e.tonemap_exposure = 0.85
	env.environment = e
	root.add_child(env)

	# --- chão xadrez suave ---
	var ground := _ground(def)
	root.add_child(ground)

	var has_model := ResourceLoader.exists("res://assets/models/%s.glb" % def.model) if def.model != "" else false
	if has_model:
		var scene: PackedScene = load("res://assets/models/%s.glb" % def.model)
		root.add_child(scene.instantiate())
	else:
		var obs_nodes: Array = []
		for ob in def.obstacles:
			var n := _obstacle(ob)
			if n:
				root.add_child(n)
				var size: Vector3 = ob.get("size", Vector3.ONE)
				if size.y > 1.6:
					n.set_meta("occluder_h", size.y)
					obs_nodes.append(n)
		root.set_meta("occluders", obs_nodes)
	for d in def.decor:
		var n := _decor(d)
		if n:
			root.add_child(n)
	for p in def.portals:
		root.add_child(_portal(p))
	return root

static func _ground(def: MapDef) -> Node3D:
	var n := Node3D.new()
	n.name = "Ground"
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var h := def.half()
	var cell := 4.0
	var nx := int(ceil(def.size.x / cell))
	var nz := int(ceil(def.size.y / cell))
	var rng := RandomNumberGenerator.new()
	rng.seed = def.id.hash()
	for ix in range(nx):
		for iz in range(nz):
			var x0 := -h.x + ix * cell
			var z0 := -h.y + iz * cell
			var x1 := minf(x0 + cell, h.x)
			var z1 := minf(z0 + cell, h.y)
			var c := def.ground_color if (ix + iz) % 2 == 0 else def.ground_color_alt
			c = c.lerp(Color.WHITE, rng.randf_range(-0.03, 0.03))
			st.set_color(c)
			st.set_normal(Vector3.UP)
			st.set_uv(Vector2(0, 0)); st.add_vertex(Vector3(x0, 0, z0))
			st.set_uv(Vector2(1, 0)); st.add_vertex(Vector3(x1, 0, z0))
			st.set_uv(Vector2(1, 1)); st.add_vertex(Vector3(x1, 0, z1))
			st.set_uv(Vector2(0, 0)); st.add_vertex(Vector3(x0, 0, z0))
			st.set_uv(Vector2(1, 1)); st.add_vertex(Vector3(x1, 0, z1))
			st.set_uv(Vector2(0, 1)); st.add_vertex(Vector3(x0, 0, z1))
	var mesh := st.commit()
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = Materials.toon(Color.WHITE, false)
	n.add_child(mi)
	# borda escura fora do mapa
	var border := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = def.size + Vector2(80, 80)
	border.mesh = pm
	border.position.y = -0.05
	border.material_override = Materials.flat(def.ground_color.darkened(0.45))
	n.add_child(border)
	return n

static func _box(size: Vector3, color: Color) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = Materials.toon(color)
	return mi

static func _cyl(top: float, bottom: float, height: float, color: Color, sides: int = 8) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = top
	cm.bottom_radius = bottom
	cm.height = height
	cm.radial_segments = sides
	mi.mesh = cm
	mi.material_override = Materials.toon(color)
	return mi

static func _sphere(radius: float, color: Color, segments: int = 8) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = radius
	sm.height = radius * 2.0
	sm.radial_segments = segments
	sm.rings = max(4, segments / 2)
	mi.mesh = sm
	mi.material_override = Materials.toon(color)
	return mi

static var _prop_cache: Dictionary = {}

## Se existir assets/models/prop_<kind>.glb (gerado pelo Blender), usa ele escalado para o tamanho do obstáculo.
static func _prop_model(kind: String, size: Vector3) -> Node3D:
	var path := "res://assets/models/prop_%s.glb" % kind
	if not _prop_cache.has(kind):
		_prop_cache[kind] = load(path) if ResourceLoader.exists(path) else null
	var scene: PackedScene = _prop_cache[kind]
	if scene == null:
		return null
	var inst: Node3D = scene.instantiate()
	# AABB total para escalar ao tamanho do MapDef
	var aabb := AABB()
	var first := true
	for mi in inst.find_children("*", "MeshInstance3D", true, false):
		var b: AABB = (mi as MeshInstance3D).get_aabb()
		b = (mi as Node3D).transform * b
		aabb = b if first else aabb.merge(b)
		first = false
		var m := mi as MeshInstance3D
		for i in range(m.get_surface_override_material_count()):
			var base := m.get_active_material(i)
			var col: Color = base.albedo_color if base is BaseMaterial3D else Color(0.8, 0.8, 0.8)
			m.set_surface_override_material(i, Materials.toon(col, kind != "path"))
	if not first and aabb.size.x > 0.001 and aabb.size.y > 0.001 and aabb.size.z > 0.001:
		inst.scale = Vector3(size.x / aabb.size.x, size.y / aabb.size.y, size.z / aabb.size.z)
		if kind in ["tree", "rock", "pillar", "well", "fountain", "lamp", "statue"]:
			var u := maxf(size.x, size.z) / maxf(aabb.size.x, aabb.size.z)
			inst.scale = Vector3(u, size.y / aabb.size.y, u)
	return inst

static func _obstacle(ob: Dictionary) -> Node3D:
	var kind: String = ob.get("kind", "house")
	var pos: Vector3 = ob["pos"]
	var size: Vector3 = ob.get("size", Vector3.ONE)
	var color: Color = ob.get("color", Color.GRAY)
	var n := Node3D.new()
	n.position = pos
	n.rotation.y = deg_to_rad(float(ob.get("rot", 0.0)))
	var prop := _prop_model(kind, size)
	if prop:
		n.add_child(prop)
		return n
	match kind:
		"house":
			var body := _box(Vector3(size.x, size.y * 0.72, size.z), color)
			body.position.y = size.y * 0.36
			n.add_child(body)
			var roof := _cyl(0.0, maxf(size.x, size.z) * 0.72, size.y * 0.5, ob.get("roof", Color(0.8, 0.42, 0.34)), 4)
			roof.rotation.y = PI * 0.25
			roof.position.y = size.y * 0.72 + size.y * 0.25
			roof.scale = Vector3(size.x / maxf(size.x, size.z), 1.0, size.z / maxf(size.x, size.z)) * 1.02
			n.add_child(roof)
			var door := _box(Vector3(0.9, 1.5, 0.15), Color(0.4, 0.28, 0.18))
			door.position = Vector3(0, 0.75, size.z * 0.5 + 0.05)
			n.add_child(door)
			var win := _box(Vector3(0.7, 0.6, 0.12), Color(0.55, 0.75, 0.9))
			win.position = Vector3(size.x * 0.3, 1.6, size.z * 0.5 + 0.05)
			n.add_child(win)
		"tent":
			var t := _cyl(0.0, size.x * 0.7, size.y, color, 4)
			t.rotation.y = PI * 0.25
			t.position.y = size.y * 0.5
			n.add_child(t)
		"tree":
			var r := size.x * 0.5
			var trunk := _cyl(r * 0.22, r * 0.3, size.y * 0.45, Color(0.45, 0.32, 0.2), 6)
			trunk.position.y = size.y * 0.22
			n.add_child(trunk)
			var crown := _sphere(r * 1.15, color, 7)
			crown.position.y = size.y * 0.72
			crown.scale = Vector3(1.0, 1.15, 1.0)
			n.add_child(crown)
			var crown2 := _sphere(r * 0.8, color.lightened(0.12), 6)
			crown2.position = Vector3(r * 0.4, size.y * 0.9, r * 0.2)
			n.add_child(crown2)
		"rock":
			var rk := _sphere(size.x * 0.55, color, 5)
			rk.position.y = size.y * 0.35
			rk.scale = Vector3(1.0, size.y / size.x, size.z / size.x)
			n.add_child(rk)
		"pillar":
			var p := _cyl(size.x * 0.4, size.x * 0.5, size.y, color, 8)
			p.position.y = size.y * 0.5
			n.add_child(p)
			var cap := _box(Vector3(size.x * 1.1, 0.3, size.x * 1.1), color.lightened(0.1))
			cap.position.y = size.y + 0.15
			n.add_child(cap)
		"wall", "ruin", "fence":
			var w := _box(size, color)
			w.position.y = size.y * 0.5
			n.add_child(w)
			if kind == "wall":
				for i in range(int(size.x / 1.0)):
					var m := _box(Vector3(0.5, 0.5, size.z), color.lightened(0.08))
					m.position = Vector3(-size.x * 0.5 + 0.5 + i * 1.0, size.y + 0.25, 0)
					n.add_child(m)
		"well":
			var base := _cyl(size.x * 0.5, size.x * 0.55, size.y * 0.6, color, 8)
			base.position.y = size.y * 0.3
			n.add_child(base)
			var roof := _cyl(0.0, size.x * 0.7, 0.8, Color(0.6, 0.35, 0.3), 4)
			roof.position.y = size.y * 0.6 + 1.6
			n.add_child(roof)
		"fountain":
			var base := _cyl(size.x * 0.5, size.x * 0.55, 0.6, color, 10)
			base.position.y = 0.3
			n.add_child(base)
			var water := _cyl(size.x * 0.42, size.x * 0.42, 0.1, Color(0.5, 0.75, 0.95), 10)
			water.position.y = 0.62
			water.material_override = Materials.glow(Color(0.5, 0.75, 0.95, 0.9), 0.6)
			n.add_child(water)
			var col := _cyl(0.25, 0.35, 1.6, color, 8)
			col.position.y = 1.2
			n.add_child(col)
			var top := _sphere(0.45, Color(0.5, 0.75, 0.95), 8)
			top.position.y = 2.1
			n.add_child(top)
		"statue":
			var ped := _box(Vector3(size.x, size.y * 0.35, size.z), color)
			ped.position.y = size.y * 0.17
			n.add_child(ped)
			var fig := _sphere(size.x * 0.35, color.lightened(0.15), 6)
			fig.position.y = size.y * 0.7
			fig.scale = Vector3(0.8, 1.6, 0.8)
			n.add_child(fig)
		"lamp":
			var post := _cyl(0.06, 0.09, size.y, color, 6)
			post.position.y = size.y * 0.5
			n.add_child(post)
			var light := _sphere(0.22, Color(1, 0.85, 0.5), 6)
			light.position.y = size.y
			light.material_override = Materials.glow(Color(1, 0.85, 0.5), 2.0)
			n.add_child(light)
			var ol := OmniLight3D.new()
			ol.position.y = size.y
			ol.light_color = Color(1, 0.85, 0.5)
			ol.light_energy = 1.2
			ol.omni_range = 6.0
			n.add_child(ol)
		"stall", "crate", "bench":
			var b := _box(size, color)
			b.position.y = size.y * 0.5
			n.add_child(b)
			if kind == "stall":
				var canopy := _box(Vector3(size.x * 1.3, 0.12, size.z * 1.4), Color(0.85, 0.3, 0.3))
				canopy.position.y = size.y + 1.1
				n.add_child(canopy)
				for sx in [-1.0, 1.0]:
					var pole := _cyl(0.05, 0.05, size.y + 1.1, Color(0.4, 0.3, 0.2), 4)
					pole.position = Vector3(sx * size.x * 0.6, (size.y + 1.1) * 0.5, size.z * 0.6)
					n.add_child(pole)
		_:
			var b := _box(size, color)
			b.position.y = size.y * 0.5
			n.add_child(b)
	return n

static func _decor(d: Dictionary) -> Node3D:
	var kind: String = d.get("kind", "grass")
	var pos: Vector3 = d["pos"]
	var size: Vector3 = d.get("size", Vector3.ONE)
	var color: Color = d.get("color", Color.GREEN)
	var n := Node3D.new()
	n.position = pos
	match kind:
		"path":
			var b := _box(Vector3(size.x, 0.04, size.z), color)
			b.position.y = 0.02
			b.material_override = Materials.toon(color, false)
			n.add_child(b)
		"grass":
			for i in range(3):
				var blade := _cyl(0.0, 0.08, size.y, color, 3)
				blade.position = Vector3(randf_range(-0.3, 0.3), size.y * 0.5, randf_range(-0.3, 0.3))
				blade.rotation.z = randf_range(-0.3, 0.3)
				blade.material_override = Materials.toon(color, false)
				n.add_child(blade)
		"flower":
			var stem := _cyl(0.02, 0.03, 0.35, Color(0.4, 0.7, 0.35), 3)
			stem.position.y = 0.17
			stem.material_override = Materials.toon(Color(0.4, 0.7, 0.35), false)
			n.add_child(stem)
			var head := _sphere(0.12, color, 5)
			head.position.y = 0.38
			n.add_child(head)
		_:
			return null
	return n

static func _portal(p: Dictionary) -> Node3D:
	var n := Node3D.new()
	n.name = "Portal_" + p["id"]
	n.position = p["pos"]
	var r: float = p.get("radius", 1.8)
	var ring := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = r - 0.25
	tm.outer_radius = r
	tm.rings = 24
	tm.ring_segments = 6
	ring.mesh = tm
	ring.position.y = 0.08
	ring.material_override = Materials.glow(Color(0.5, 0.8, 1.0), 2.0)
	n.add_child(ring)
	var disc := _cyl(r - 0.3, r - 0.3, 0.05, Color(0.5, 0.8, 1.0), 16)
	disc.position.y = 0.04
	disc.material_override = Materials.glow(Color(0.5, 0.8, 1.0, 0.35), 0.8)
	n.add_child(disc)
	var arch := MeshInstance3D.new()
	var am := TorusMesh.new()
	am.inner_radius = r * 0.8
	am.outer_radius = r * 0.95
	arch.mesh = am
	arch.rotation.x = PI * 0.5
	arch.position.y = r * 0.9
	arch.material_override = Materials.toon(Color(0.85, 0.8, 0.68))
	n.add_child(arch)
	var label := Label3D.new()
	label.text = p.get("label", "")
	label.position.y = r * 1.9 + 0.3
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.font_size = 48
	label.pixel_size = 0.012
	label.outline_size = 12
	label.modulate = Color(0.8, 0.95, 1.0)
	n.add_child(label)
	var light := OmniLight3D.new()
	light.light_color = Color(0.5, 0.8, 1.0)
	light.light_energy = 2.0
	light.omni_range = 7.0
	light.position.y = 1.0
	n.add_child(light)
	return n
