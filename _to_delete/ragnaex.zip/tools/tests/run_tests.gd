extends Node
## Testes headless da simulação:
##   godot --headless --path . tools/tests/tests.tscn
## Cobre catálogo, fórmulas, bloqueio, XP, loot, quests, crafting, mira de skills e 3000 ticks de mundo com bots.

var fails := 0
var passes := 0

func check(cond: bool, msg: String) -> void:
	if cond:
		passes += 1
	else:
		fails += 1
		push_error("FAIL: " + msg)
		print("FAIL: " + msg)

func _ready() -> void:
	Sim.running = false
	run_all(GameData, Sim, Balance, SaveSystem)
	print("\n=== %d passed, %d failed ===" % [passes, fails])
	get_tree().quit(1 if fails > 0 else 0)

func run_all(gd, sim, balance, save) -> void:
	# ---- catálogo ----
	check(gd.classes.size() == 8, "8 classes")
	check(gd.skills.size() >= 48, "48+ skills (tem %d)" % gd.skills.size())
	for cid in gd.classes:
		var c = gd.classes[cid]
		check(c.skill_ids.size() == 6, "classe %s tem 6 skills" % cid)
		for sid in c.skill_ids:
			check(gd.skills.has(sid), "skill %s existe" % sid)
		for eid in c.starting_equipment:
			check(gd.items.has(eid), "item inicial %s existe" % eid)
	for mid in gd.monsters:
		var m = gd.monsters[mid]
		check(m.loot_table == "" or gd.loot_tables.has(m.loot_table), "loot table de %s" % mid)
		for sid in m.skill_ids:
			check(gd.skills.has(sid), "skill de monstro %s" % sid)
	for lid in gd.loot_tables:
		for e in gd.loot_tables[lid].entries:
			check(gd.items.has(e["item"]), "loot %s item %s" % [lid, e["item"]])
	for qid in gd.quests:
		var q = gd.quests[qid]
		if q.type == QuestDef.Type.KILL: check(gd.monsters.has(q.target_id), "quest %s alvo" % qid)
		if q.type == QuestDef.Type.COLLECT or q.type == QuestDef.Type.CRAFT: check(gd.items.has(q.target_id), "quest %s item" % qid)
		for iid in q.reward_items: check(gd.items.has(iid), "quest %s recompensa %s" % [qid, iid])
		if q.prereq_quest != "": check(gd.quests.has(q.prereq_quest), "quest %s prereq" % qid)
	for rid in gd.recipes:
		var r = gd.recipes[rid]
		check(gd.items.has(r.result_item), "receita %s resultado" % rid)
		for iid in r.ingredients: check(gd.items.has(iid), "receita %s ingrediente %s" % [rid, iid])
	for mid in gd.maps:
		var md = gd.maps[mid]
		for p in md.portals: check(gd.maps.has(p["target_map"]), "portal %s/%s" % [mid, p["id"]])
		for sp in md.spawners: check(gd.monsters.has(sp["monster_id"]), "spawner %s/%s" % [mid, sp["monster_id"]])
		for n in md.npcs:
			for iid in n.get("shop", []): check(gd.items.has(iid), "loja %s item %s" % [n["id"], iid])
	# NPCs referenciados por quests existem em algum mapa
	var npc_ids := {}
	for mid in gd.maps:
		for n in gd.maps[mid].npcs:
			npc_ids[n["id"]] = true
	for qid in gd.quests:
		var q = gd.quests[qid]
		check(npc_ids.has(q.giver_npc), "quest %s giver %s existe" % [qid, q.giver_npc])
		check(npc_ids.has(q.turnin()), "quest %s turnin existe" % qid)
		if q.type == QuestDef.Type.TALK: check(npc_ids.has(q.target_id), "quest %s talk npc" % qid)

	# ---- fórmulas ----
	var pal = gd.classes["paladin"]
	var eq := {}
	for iid in pal.starting_equipment:
		var it = gd.items[iid]
		eq[it.slot] = it
	var st = Stats.compute(pal, 1, eq, [])
	check(st.attrs["FOR"] == 4 and st.attrs["VIT"] == 5, "atributos do paladino vêm do equipamento (FOR=%d VIT=%d)" % [st.attrs["FOR"], st.attrs["VIT"]])
	check(st.has_shield and st.block_chance > 12.0, "escudo dá chance de bloqueio")
	check(st.max_hp == pal.base_hp + 5 * balance.HP_PER_VIT, "HP = base + VIT*12")
	var ran = gd.classes["ranger"]
	var eq2 := {}
	for iid in ran.starting_equipment:
		eq2[gd.items[iid].slot] = gd.items[iid]
	var st2 = Stats.compute(ran, 1, eq2, [])
	check(st2.is_ranged_weapon and st2.patk > 7.0, "arco usa AGI")
	check(balance.xp_for_level(1) == 60 and balance.xp_for_level(30) == 0, "curva de XP")

	# ---- mundo ----
	for mid in gd.maps:
		sim.load_map(gd.maps[mid])
	var p = sim.spawn_player(gd.classes["berserker"], "Tester", "city_aldara")
	check(p.skills.size() == 6 and p.basic_skill != null, "player criado com skills e ataque básico")
	var bot = sim.spawn_bot(gd.classes["bishop"], "Bot1", "city_aldara", Vector3(3, 0, 3), 5)
	check(bot.brain != null and bot.level == 5, "bot criado")
	# monstro de teste perto do player
	var slime = sim.spawn_monster(gd.monsters["slime"], "city_aldara", p.position + Vector3(0, 0, 1.5))
	var cmd := InputCommand.new()
	cmd.aim = slime.position
	cmd.attack = true
	sim.set_player_command(cmd)
	sim.running = true
	var hp0 = slime.hp
	for i in range(40):
		sim.tick(1.0 / 60.0)
		if i == 0:
			cmd = InputCommand.new(); cmd.aim = slime.position
			sim.set_player_command(cmd)
	check(slime.hp < hp0, "ataque básico causa dano (hp %d -> %d)" % [hp0, slime.hp])
	# skill em cone (ber_cleave) deve acertar
	var slime2 = sim.spawn_monster(gd.monsters["slime"], "city_aldara", p.position + Vector3(1.0, 0, 1.5))
	var hp2 = slime2.hp
	cmd = InputCommand.new(); cmd.aim = slime2.position; cmd.skill_slot = 0
	sim.set_player_command(cmd)
	for i in range(60):
		sim.tick(1.0 / 60.0)
		if i == 0:
			cmd = InputCommand.new(); cmd.aim = slime2.position; sim.set_player_command(cmd)
	check(slime2.hp < hp2, "skill 1 (cone) causa dano")
	check(p.cooldowns.get("ber_cleave", 0.0) > 0.0, "skill entrou em cooldown")
	# ground target fora do alcance é clampado
	var aim: Vector3 = p.position + Vector3(50, 0, 0)
	var c := Combat.clamp_aim(p, aim, 6.0)
	check(absf(c.distance_to(p.position) - 6.0) < 0.01, "clamp de mira no alcance")
	# bloqueio reduz dano
	var rng := RandomNumberGenerator.new(); rng.seed = 5
	var wolf = sim.spawn_monster(gd.monsters["wolf"], "city_aldara", p.position + Vector3(0, 0, 8))
	p.is_blocking = false
	var d_open := 0; var d_block := 0
	for i in range(200):
		d_open += Combat.calc_damage(wolf, p, 1.0, 0, rng)["amount"]
	p.is_blocking = true
	for i in range(200):
		d_block += Combat.calc_damage(wolf, p, 1.0, 0, rng)["amount"]
	p.is_blocking = false
	check(d_block < d_open * 0.7, "bloqueio ativo reduz dano (%d vs %d)" % [d_block, d_open])
	# XP e level
	var lv0 = p.level
	sim.gain_xp(p, 500)
	check(p.level > lv0 and p.mastery_points > 0, "XP sobe nível e dá maestria (lv %d, pts %d)" % [p.level, p.mastery_points])
	check(sim.upgrade_mastery(p, "ber_cleave") and p.mastery["ber_cleave"] == 1, "maestria sobe com pontos")
	# loot/quests/craft
	var elder_quests = QuestSystem.available_from_npc(p, "elder")
	check(elder_quests.size() >= 1, "ancião oferece quest")
	QuestSystem.accept(p, gd.quests["q01_welcome"])
	QuestSystem.on_talk(p, "captain")
	check(QuestSystem.is_complete(p, gd.quests["q01_welcome"]), "quest TALK completa")
	QuestSystem.complete(p, gd.quests["q01_welcome"], sim)
	check("q01_welcome" in p.quests_completed, "quest entregue")
	QuestSystem.accept(p, gd.quests["q02_slimes"])
	for i in range(6):
		QuestSystem.on_kill(p, "slime")
	check(QuestSystem.is_complete(p, gd.quests["q02_slimes"]), "quest KILL completa")
	p.add_item("herb_green", 1); p.add_item("slime_gel", 1)
	check(CraftSystem.craft(p, gd.recipes["rec_potion_hp_s"]), "craft de poção")
	check(p.has_item("potion_hp_s", 7), "poção craftada no inventário")
	var g0 = p.gold
	check(CraftSystem.buy(p, "potion_mp_s", 1) and p.gold == g0 - 18, "compra na loja")
	# equipar
	p.add_item("axe_iron", 1)
	p.level = 8
	check(sim.equip(p, "axe_iron") and p.equipment[ItemDef.Slot.WEAPON].id == "axe_iron", "equipar arma")
	check(p.has_item("axe_old"), "arma antiga volta pra bolsa")
	# poção
	p.hp = 10
	check(sim.use_potion(p, 0) and p.hp > 10, "poção F1 cura")
	# invocação do necro
	var nec = sim.spawn_bot(gd.classes["necromancer"], "Necro", "city_aldara", Vector3(-5, 0, -5), 10)
	nec.brain = null
	sim._apply_skill(nec, gd.skills["nec_raise"], sim.maps["city_aldara"])
	var summons := 0
	for e in sim.map_entities("city_aldara"):
		if e.kind == SimEntity.Kind.SUMMON and e.owner_id == nec.id:
			summons += 1
	check(summons == 2, "necro invoca 2 esqueletos (%d)" % summons)
	# ---- simulação longa com bots em todos os mapas ----
	var names: Array = gd.bot_names.duplicate()
	var classes: Array = gd.class_list()
	var k := 0
	for mid in gd.maps:
		var md = gd.maps[mid]
		for i in range(md.bot_population):
			var cls = classes[k % classes.size()]
			var lv := rng.randi_range(md.level_range.x, md.level_range.y)
			sim.spawn_bot(cls, names[k % names.size()], mid, sim.random_walkable(md, md.spawn_point, 6.0), lv)
			k += 1
	var cmd0 := InputCommand.new(); cmd0.aim = p.position + Vector3(0, 0, 1)
	sim.set_player_command(cmd0)
	var t0 := Time.get_ticks_msec()
	for i in range(3000):
		sim.tick(1.0 / 60.0)
	var ms := Time.get_ticks_msec() - t0
	print("3000 ticks com %d entidades em %d ms (%.2f ms/tick)" % [sim.entities.size(), ms, ms / 3000.0])
	check(ms < 20000, "performance da simulação")
	var alive_bots := 0
	for e in sim.entities.values():
		if e.kind == SimEntity.Kind.BOT:
			alive_bots += 1
	check(alive_bots == k + 2, "bots sobrevivem/renascem (%d de %d)" % [alive_bots, k + 2])
	# NaN check
	for e in sim.entities.values():
		check(is_finite(e.position.x) and is_finite(e.position.z) and is_finite(e.hp), "posição/hp finitos em %s" % e.name)
	# save/load
	save.save_player(p)
	var d = save.load_data()
	check(d.get("class", "") == "berserker" and int(d.get("level", 0)) == 8, "save/load")
	save.delete_save()
